<?php

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../close/constants.php";                   //константы
require_once CLOSE . "URLListener.php";                     //подключаем класс по работе с роутингом
require_once WWW . "vendor/autoload.php";                   //загружаем библиотеки
include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "modals.php";                          //функции для работы с модалками
include_once CLOSE . "users.php";                           //функции для работы с юзерами

//запрашиваемый адрес
$path = $_SERVER[ "REQUEST_URI" ];

//слушатель адресов
$urlListener = new URLListener([
    "cache" => ROOT . "temp"
]);

//ТУТ добавление адресов роутинга, определение модели
include_once "start_listeners.php";

//обрабатываем запрашиваемый путь
$urlListener->workPath( $path );// test change
