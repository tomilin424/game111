<?php

try {
    //Конфиги системы
    $allConf = new xmlConfigs();

    //конфиги системы
    $xmlConf = $allConf->getSystemConfigs();

    if (is_null($xmlConf)) {
        throw new Exception("Конфигурация системы не загружена");
    }

    //Информация о системе
    $systemInfo = $allConf->getInformationConfigs();

    if ( is_null($systemInfo) ) {
        throw new Exception("Не получена информация о системе");
    }

    //Места поиска шаблонов
    $environments = [
        [MODULES],
        [MODULES_GAME, "pc"],
        [MODULES_MOBILE, "mobile"]
    ];
    //пользовательские константы
    $constants = [];
    //слушатель адресов
    $urlListener = new URLListener();

    //перебираем константы
    foreach (get_defined_constants(true)["user"] as $key => $value) {
        //Если константа это слушатель
        if (get_class($urlListener) == $key) {
            continue;
        }

        //записываем константу
        $constants[$key] = $value;
    }

    // Элемент для работы с юзерами
    $users = new users();

    // кука с хэшем
    $hashCookie = isset( $_COOKIE[ "hash" ] ) ? $_COOKIE[ "hash" ] : null;

    // данные валидной сессии
    $sessionData = $users->checkSession( null, $hashCookie );

    // Если сессия валидная
    if ( $sessionData[ "status" ] == "ok" && $sessionData[ "isActiveSession" ] === true ) {
        // Получаем данные пользователя
        $userData = $users->getData( null, $sessionData[ "data" ][ "user_hash" ] );

        if ( $userData[ "status" ] != "ok" ) {
            throw new Exception("Ошибка получения данных пользователя");
        }

        // Записываем хэш пользователя
        $sessionData[ "hash" ] = $sessionData[ "data" ][ "user_hash" ];
        // Записываем данные пользователя
        $sessionData[ "data" ] = $userData[ "data" ];
    }

    //доступные модалки
    $modals = [
        //название модалки => [
        // request => ajax=mod_req - название модалки в запросе
        // path => mod_path - путь до модалки
        //]
        //"request" => "modal_path/modal_name.html"
    ];

    $modalsPath = MODULES . "modals";

    //получаем общие модалки из структуры папок
    $modals = getFolderModals( $modalsPath, "", "@modals/" );

    //записываем модалки в глобальный массив
    $GLOBALS[ "modals" ] = $modals;

    //конфигурация чисто для web-а
    $webConfigs = [
        "version" => $systemInfo["version"],
    ];

    //переменные контекста (модель)
    $context = [
        "sessionData" => $sessionData,
        "constants" => $constants,
        "configs" => [
            "system" => $xmlConf,
            "information" => $systemInfo,
            "web" => $webConfigs
        ],
        "modals" => $modals
    ];
    //конфиги twig-а
    $twig = [
        "environments" => $environments,
        "configs" => [],
        "context" => $context
    ];

    //обработчики адресов
    $workers = [
        /*[
            "path" => "/||",
            "worker" => "@mobile/pages/main/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/auth/||/auth",
            "worker" => "@mobile/pages/auth/auth.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/lk/||/lk",
            "worker" => "@mobile/pages/lk/lk.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/about/||/about",
            "worker" => "@mobile/pages/about/about.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/transaction/||/transaction",
            "worker" => "@mobile/pages/transaction/transaction.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/help/||/help",
            "worker" => "@mobile/pages/help/help.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],

        [
            "path" => "/by_crypto/||/by_crypto",
            "worker" => "@mobile/pages/by_crypto/by_crypto.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],

        [
            "path" => "/contacts/||/contacts",
            "worker" => "@mobile/pages/contacts/contacts.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ]*/
    ];

    //если ошибка при добавлении обработчиков в слушатель
    if ( !$urlListener->addListeners( $workers ) ) {
        echo "ошибка";

        exit(1);
    }
}
catch ( Exception $err ) {
    echo json_encode([
        "status" => "error",
        "text" => $err->getMessage()
    ]);
}
