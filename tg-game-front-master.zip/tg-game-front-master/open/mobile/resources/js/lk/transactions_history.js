let transactionsHistory = transactionsHistoryFunc();

function transactionsHistoryFunc () {
  //данные транзакций
  let transactionsItems = [];

  function init() {
    try {
      // Добавляем события
      addEvents();

      // Запускаем загрузку транзакций
      startLoadTransactions ();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //успешная загрузка данных транзакций
      $( document ).on( "transactionItemsLoadSuccess", buildLoadTransactions );
    }
    catch (e) {
      console.log(e);
    }
  }

  //Запуск загрузки транзакций
  function startLoadTransactions( ) {
    try {
      transactions.loadTransactions();
    }
    catch (e) {
      console.log(e);
    }
  }
  //Построение транзакций после загрузки
  function buildLoadTransactions( ev ) {
    try {
      //транзакциий
      transactionsItems = transactions.getTransactions();
      //элементы тразнакций
      let elems = $( '<div></div>' );
      let elemIndex = -1;

      //перебираем элементы
      transactionsItems.forEach( (item) => {
        elemIndex++;

        let elem = $( '<div>' +
            '<div class="cTItem smallRadiusBorder">' +
            '            <div class="cTILabel">' +
            '                <div class="cTILLeft">' +
            '                    <div class="cTILLHead">' +
            '                        <div>' +
            '                            <span class="grayFont varyLargFontSize" data-number></span>' +
            '                        </div>' +
            '' +
            '                        <div>' +
            '                            <span class="orangeFont varyLargFontSize" data-status></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div class="cTILLLData">' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" data-date></span>' +
            '                        </div>' +
            '' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" data-to></span>' +
            '                        </div>' +
            '' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" data-sum></span>' +
            '                        </div>' +
            '                    </div>' +
            '                </div>' +
            '                <div class="cTILRight">' +
            '                    <div id="cTILRRepeat" class="btn">' +
            '                        <span class="varyLargFontSize">Повторить</span>' +
            '                    </div>' +
            '                </div>' +
            '                <div class="cTILLeft">' +
            '                    <div class="cTILLLDetailShow">' +
            '                        <span class="grayFont largerFontSize">Детали операции</span>' +
            '                    </div>' +
            '                </div>' +
            '            </div>' +
            '' +
            '            <div class="cTIContent">' +
            '                <div class="cTICData">' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Направление перевода:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Номер получателя:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" tr-data="toData.tel"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Курс 1 USD =&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" tr-data="course"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Отправитель:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" tr-data="-implode" tr-data-implode="fromData.secondName|fromData.name|fromData.threeName" tr-data-implode-symbol=" "></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Услуга отправки предоставлена:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" ></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Номер транзакции:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize" tr-data="token"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Способ оплаты:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Номер терминала:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Код авторизации:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Списание средств:&nbsp;</span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '' +
            '                    <div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize">Место выдачи: </span>' +
            '                        </div>' +
            '                        <div>' +
            '                            <span class="grayFont largerFontSize"></span>' +
            '                        </div>' +
            '                    </div>' +
            '                </div>' +
            '' +
            '                <div class="cTICDetailHide">' +
            '                    <span class="grayFont largerFontSize">Скрыть детали операции</span>' +
            '                </div>' +
            '            </div>' +
            '        </div>' +
            '</div>' );

        //перебираем элементы, в которые надо вывести значение
        $( "[tr-data]", elem ).each( function (index) {
          let needKey = $(this).attr("tr-data");

          //Если ключ не задан или нет ключа в элементе И не спец. значение
          if (needKey !== "-implode" && (needKey === "" || !item.hasOwnProperty(needKey))) {
            return true;
          }

          let value = "";

          //Если не спец. значение
          if (needKey !== "-implode") {
            value = item[needKey];
          }
          else {
            //Если объединение
            if ( needKey === "-implode" ) {
              //пути в элементе
              let implodePaths = $( this ).attr( "tr-data-implode" ).split("|");
              //разделитель
              let delimiter = $( this ).attr( "tr-data-implode-symbol" );

              value = [];

              //перебираем пути
              for ( let path of implodePaths ) {
                value.push( getPathValue( item, path ) );
              }

              //собираем все значения
              value = value.join( delimiter );
            }
          }

          //заменить потом на код валюты
          if ( needKey === "course" ) {
            value += " RUB";
          }

          $( this ).html( value );
        });

        //записываем параметры
        $( "> .cTItem", elem ).attr({
          "uuid" : item.uuid,
          "index" : elemIndex
        });

        //дата создания транзакции
        let dateCreate = new Date( item.dateCreate.replace(/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})$/, '$1T$2') );

        //выводим значения
        $( "[data-number]", elem ).html( "№" + ("000000000" + item.number).slice(-9) );
        $( "[data-to]", elem ).html( "Получатель: " + item.toData.secondName + " " + item.toData.name );
        //ЗАМЕНИТЬ ПОТОМ НА ВАЛЮТУ ИЗ БАЗЫ
        $( "[data-sum]", elem ).html( "Сумма перевода: " + item.sum + " USD" );
        $( "[data-date]", elem ).html( ("00" + dateCreate.getDate()).slice(-2) + " " +
            dateCreate.toLocaleString("default", {month: "long"}) + " " +
            dateCreate.getFullYear() + " " + ("00" + dateCreate.getHours()).slice(-2) + ":" +
            ("00" + dateCreate.getMinutes()).slice(-2) + " (МСК)");

        //Если статус - создан
        if ( item.status === 0 ) {
          $( "[data-status]", elem ).html( "СОЗДАН" );
        }

        //добавляем события
        $( ".cTILLLDetailShow, .cTICDetailHide", elem ).on( "click", detailClick );

        //добавляем элемент к другим
        elems.append( elem.contents() );
      });

      $( "#cTransactions" ).html( elems.contents() );
    }
    catch (e) {
      console.log(e);
    }
  }


  //клик на детали операции
  function detailClick( e ) {
    try {
      let parent = $( $(e.currentTarget).parents( ".cTItem" )[0] );
      let isShow = $( ".cTIContent", parent ).hasClass( "cTIContentShow" );

      //Показываем/Скрываем содержимое транзакции
      showHideContentTransaction( parent.attr("uuid"), !isShow );
    }
    catch (e) {
      console.log(e);
    }
  }

  //Показ/Скрытие содержимого транзакции
  function showHideContentTransaction( uuid, isShow ) {
    try {
      if ( isShow ) {
        $( "[uuid=\"" + uuid + "\"] * .cTILLLDetailShow" ).addClass( "cTILLLDetailShowHideHide" );
        $( "[uuid=\"" + uuid + "\"] > .cTIContent" ).addClass( "cTIContentShow" );
      }
      else {
        $( "[uuid=\"" + uuid + "\"] * .cTILLLDetailShow" ).removeClass( "cTILLLDetailShowHideHide" );
        $( "[uuid=\"" + uuid + "\"] > .cTIContent" ).removeClass( "cTIContentShow" );
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  return {
    init: function() {
      init();
    }
  }
}
