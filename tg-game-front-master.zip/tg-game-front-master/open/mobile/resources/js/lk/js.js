let lk = lkFunc();

function lkFunc () {
  let isShowCountrys = false;
  let isSaveNewData = false;
  let isStart = false;                        //индикатор того, что модуль можно стартовать

  let queue = new queueFunc();

  function init() {
    try {
      queue.setNeedStartIndicator( 3 );
      queue.setQueueAction([
        [buildCountrys, []],
        [loadUserData, []]
      ]);

      addEvents();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //успешная загрузка данных системы
      $( document ).on( "loadSystemDataSuccess", function() {setStart();} );
      //ввод номера телефона
      $( "#full_number" ).on( "input", phoneInput );
      //клик на кнопку Сохранить
      $( "#cFSave" ).on( "click", saveClick );
      //клик на кнопку Редактировать
      $( "#cFtoUpdate" ).on( "click", editClick );
      //успешная загрузка данных стран и валют
      $( document ).on( "countryLoadSuccess currencyLoadSuccess", function () {
        queue.startQueue();
      });
      //успешная загрузка данных сессии
      $( document ).on( "checkSessionEnd", loadSessionData );
      //успешная загрузка данных юзера
      $( document ).on( "loadUserDataSuccess", loadUserData );

      //клик на картинку страны или стрелку
      $( "#cTLFDIImg, #cTLFDIArrow, #country" ).on( "click", showHideCountrys );
      //обработка клика по документу
      $(document).on("click", documentClick);
    }
    catch (e) {
      console.log(e);
    }
  }

  //ввод номера телефона
  function phoneInput( ev ) {
    try {
      let phone = $(ev.currentTarget).val();

      phone = phone.replace(/[^\d]/g, '');

      if ( phone.length > 11 ) {
        phone = phone.slice(0, -1);
      }

      $(ev.currentTarget).val( phone );
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик по документу
  function documentClick( ev ) {
    try {
      if ( isShowCountrys ) {
        if ( $(ev.target).closest("#cTLFDIImg, #countrys, #cTLFDICenter, #cTLFDIArrow").length === 0 ) {
          showHideCountrys();
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //построение стран
  function buildCountrys( ev ) {
    try {
      console.log("Строим страны");

      // Загружаем данные транзакций
      transactionsHistory.init();

      let countrys = transactions.getCountrys();

      if ( countrys === null ) {
        throw "Страны не получены";
      }

      let elements = $( '<div></div>' );

      countrys.forEach( item => {
        let elem = $('<div>' +
            '<div>' +
            '                                <div>' +
            '                                    <img src="https://' + system.getSystemData().domain + '/resources/img/country/kz.svg" />' +
            '                                </div>' +
            '                                <div>' +
            '                                    <span class="blackFont largFontSize"></span>' +
            '                                </div>' +
            '                            </div>' +
            '</div>');

        $( "* img", elem ).attr({
          "src" : "https://" + system.getSystemData().domain + "/resources/img/country/" + item.flag
        });
        $( "* span", elem ).html( item.name );

        $( "> div", elem ).attr({
          "data-id" : item.id
        });

        //добавляем события
        addDelCountyEvents( elem, true );

        elements.append( elem.contents() );
      } )

      let list = $( "#countrys" );

      //добавляем страны на страницу
      list.append( elements.contents() );

      //грузим данные юзера
      user.loadUserData();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление/удаление событие со страны
  function addDelCountyEvents( elem, isAdd ) {
    try {
      if ( isAdd === true ) {
        $("> [data-id]", elem ).on( "click", countryClick );                  //клик на страну в списке
      }
      else {
        $( "> [data-id]", elem ).off( "click", countryClick );                  //клик на страну в списке
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на страну в списке
  function countryClick( ev ) {
    try {
      let countryID = parseInt( $(ev.currentTarget).attr("data-id") );
      let countryData = transactions.getCountryByID( countryID );

      if ( countryData === null ) {
        throw "Данных страны " + countryID + " нет";
      }

      //меняем страну на другую
      changeCountry( countryData );

      if ( isShowCountrys ) {
        //Скрываем страны
        showHideCountrys();
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //Смена страны
  function changeCountry( newCountryData ) {
    try {
      $( "#cTLFDIImg > img" ).attr("src", "https://" + system.getSystemData().domain + "/resources/img/country/" + newCountryData.flag);
      $( "#country" ).html( newCountryData.name );

      let uD = user.getUserData();

      uD.citizenship = parseInt( newCountryData.id );

      user.setUserData( uD );
    }
    catch (e) {
      console.log(e);
    }
  }

  //скрытие|показ стран
  function showHideCountrys() {
    try {
      if ( isShowCountrys ) {
        $( "#countrys" ).removeClass( "countrysShow" );
        $( "#cTLFDIArrow" ).removeClass( "cTLFDIArrowScale" );
      }
      else {
        $( "#countrys" ).addClass( "countrysShow" );
        $( "#cTLFDIArrow" ).addClass( "cTLFDIArrowScale" );
      }

      isShowCountrys = !isShowCountrys;
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на кнопку Сохранить
  function saveClick( e ) {
    try {
      if ( isSaveNewData ) {
        return;
      }

      isSaveNewData = true;

      let errors = 0;
      let oldUserData = user.getUserData();
      let sendData = {};

      console.log( oldUserData );
      $( ".cForm * input" ).each(function( ) {
        let elem = $( this );

        console.log(elem.attr("id"), elem.attr("not-require"));

        let elemData = {
          "id" : elem.attr("id"),
          "value" : elem.val()
        };

        if ( elem.attr('not-require') !== "1" && (elemData.value === undefined || elemData.value === null || elemData.value === "") ) {
          elem.parents( ".cFItem" ).addClass( "cFItemError" );

          errors++;
        }

        sendData[ elemData.id ] = elemData.value;
      });

      let countryText = $('#country').text();
      let countrData = transactions.getCountryByName( countryText );

      if ( countrData === null ) {
        sendData["citizenship"] = 0;
      }
      else {
        sendData["citizenship"] = countrData.id;
      }

      if ( errors > 0 ) {
        isSaveNewData = false;

        alert( "Проверьте выделенные поля" );

        return;
      }

      //console.log(user.getUserData(), Object.keys(user.getUserData()).length);

      fetch('/apprin/v1/user/' + (user.getUserData().hasOwnProperty("isExistPersonal") && user.getUserData().isExistPersonal === true ? 'update_data' : 'input_data' ) + '/', {
        method: 'POST',
        body: JSON.stringify(sendData)
      })
          .then(response => response.json())
          .then(response => {
            if ( response.status === "ok" ) {
              window.location.href = "/lk";
            }
            else {
              console.log("Ошибка сохранения новых данных: " + response.text);
            }
          }).finally(() => isSaveNewData = false);
    }
    catch (e) {
      console.log(e);
    }
  }

  //успешная загрузка данных сессии
  function loadSessionData() {
    try {
      let sess = session.getSession();

      if ( !sess.isActiveSession ) {
        window.location.href = "/auth";

        return;
      }

      queue.startQueue();

      //грузим страны
      transactions.loadCountrys();

      //грузим валюты
      transactions.loadCurrencys();
    }
    catch (e) {
      console.log(e);
    }
  }

  //успешная загрузка данных юзера
  function loadUserData() {
    try {
      let userData = user.getUserData();

      console.log(userData);

      for ( let key in userData ) {
        user_data[ key ] = userData[key];

        //Если гражданство
        if ( key === "citizenship" ) {
          //кликаем на нужную страну
          $( "#countrys > [data-id=\"" + userData[ key ] + "\"]" ).trigger("click");

          //операторы ниже пропускаем
          continue;
        }

        let elem = $( "#" + key );

        console.log( "#" + key );

        if ( elem.length !== 1 ) {
          continue;
        }
        //elem.attr("readOnly", true);
        elem.val( userData[key] );
      }
	  
	  if (userData.surname) {
		$( "#cTLFDIImg, #cTLFDIArrow, #country" ).off( "click", showHideCountrys );
		$(".cForm :input").prop("readonly", true);
		$('#cFSave').hide();
		$('#cFtoUpdate').css('display', 'flex');
	  }
	  SaveData();

      isStart = true;
    }
    catch (e) {
      console.log(e);
    }
  }

  function editClick() {
    $("#cTLFDIImg, #cTLFDIArrow, #country").on("click", showHideCountrys);
    $(".cForm :input").prop("readonly", false);
    $('#cFSave').css('display', 'flex');
    $('#cFtoUpdate').css('display', 'none');
  }

  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию
$( lk.init );
