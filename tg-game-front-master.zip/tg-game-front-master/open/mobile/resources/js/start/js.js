let mainPage = new mainPageFunc();

function mainPageFunc () {
    let isShowCountrys = false;

    let queue = new queueFunc();

    function init() {
        try {
            session.checkSession();
			
			addEvents();

            queue.setNeedStartIndicator( 2 );
            queue.setQueueAction([
                [ startTransactionsHistory, [] ]
            ]);

            transactions.loadCountrys();
            transactions.loadCurrency();
            transactions.loadCurrencys();

            nav.setNeedBackground( false );
            nav.setFixed( false );
        }
        catch (e) {
            console.log(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            //клик на кнопку Отправить
            $("#cTLFSend").on("click", sendClick);
            //событие загрузки курса
            $(document).on("currencyLoadSuccess", buildCurrency);
            //клик на картинку страны или стрелку
            $("#cTLFDIImg, #cTLFDIArrow, #country").on("click", showHideCountrys);
            //обработка клика по документу
            $(document).on("click", documentClick);
            //ввод суммы перевода
            $("#summ").on("input", inputSumm);

            //Клик на поиск перевода
            $( "#PaymentVerif" ).on( "click", searchTransactionClick );
            //Построение модалки
            $( "document" ).on( "modalBuild", addModalEvents );

            //успешная загрузка данных стран и валют
            $( document ).on( "countryLoadSuccess currencyLoadSuccess", function () {
                queue.startQueue();
            });
        }
        catch (e) {
            console.log(e);
        }
    }

    // Запуск работы с историей транзакций
    function startTransactionsHistory() {
        try {
            // Запускаем элемент для работы с хронологией отправки
            transactionsHistory.init();
        }
        catch (e) {
            console.log(e);
        }
    }

    //Добавление событий модалке
    function addModalEvents ( e ) {
        try {
            modal.showModal( null, "", {modal : "check_transaction_status"} );
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на поиск перевода
    function searchTransactionClick( e ) {
        try {
            modal.showModal( null, "", {modal : "check_transaction_status"}, {
                "ok" : {
                    "label" : "Найти",
                    "callback" : searchClick
                }
            });
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на кнопку найти
    function searchClick( ev ) {
        try {
            let token = $( "[name=\"token\"]" ).val();

            if ( token.length <= 5 ) {
                alert( "Номер должен содержать больше символов" );

                return;
            }

            $.ajax({
                url : "/apprin/v1/transaction/search/",
                type : "POST",
                data : "token=" + token,
                success : function ( responce ) {
                    console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status === "ok" ) {
                            let transData = resp.data;

                            //перебираем элементы, в которые надо вывести значение
                            $( ".modalContent > .searchInfo * [tr-data]" ).each( function (index) {
                                let needKey = $(this).attr("tr-data");

                                //Если ключ не задан или нет ключа в элементе И не спец. значение
                                if (needKey !== "-implode" && (needKey === "" || !transData.hasOwnProperty(needKey))) {
                                    return true;
                                }

                                let value = "";

                                //Если не спец. значение
                                if (needKey !== "-implode") {
                                    value = transData[needKey];
                                }
                                else {
                                    //Если объединение
                                    if ( needKey === "-implode" ) {
                                        //пути в элементе
                                        let implodePaths = $( this ).attr( "tr-data-implode" ).split("|");
                                        //разделитель
                                        let delimiter = $( this ).attr( "tr-data-implode-symbol" );

                                        value = [];

                                        //перебираем пути
                                        for ( let path of implodePaths ) {
                                            value.push( getPathValue( transData, path ) );
                                        }

                                        //собираем все значения
                                        value = value.join( delimiter );
                                    }
                                }

                                //заменить потом на код валюты
                                if ( needKey === "course" ) {
                                    value += " RUB";
                                }

                                $( this ).html( value );
                            });

                            //дата создания транзакции
                            let dateCreate = new Date( transData.dateCreate.replace(/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})$/, '$1T$2') );

                            //выводим значения
                            $( ".modalContent > .searchInfo * [data-number]" ).html( "№" + ("000000000" + transData.number).slice(-9) );
                            $( ".modalContent > .searchInfo * [data-to]" ).html( "Получатель: " + transData.toData.secondName + " " + transData.toData.name );
                            //ЗАМЕНИТЬ ПОТОМ НА ВАЛЮТУ ИЗ БАЗЫ
                            $( ".modalContent > .searchInfo * [data-sum]" ).html( "Сумма перевода: " + transData.sum + " USD" );
                            $( ".modalContent > .searchInfo * [data-date]" ).html( ("00" + dateCreate.getDate()).slice(-2) + " " +
                                dateCreate.toLocaleString("default", {month: "long"}) + " " +
                                dateCreate.getFullYear() + " " + ("00" + dateCreate.getHours()).slice(-2) + ":" +
                                ("00" + dateCreate.getMinutes()).slice(-2) + " (МСК)");

                            //Если статус - создан
                            if ( transData.status === 0 ) {
                                $( ".modalContent > .searchInfo * [data-status]" ).html( "СОЗДАН" );
                            }

                            //показываем данные транзакции
                            $( ".modalContent > .searchInfo" ).addClass( "searchInfoShow" );
                        }
                        else {
                            alert( "Перевод не найден" );
                        }
                    }
                    catch ( err ) {
                        console.log( err );
                    }
                },
                error : function ( err ) {
                    console.log( err );
                }
            });
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на кнопку Отправить
    function sendClick( ev ) {
        try {
            let sendSumm = parseFloat( $("#summ").val() );

            if ( isNaN(sendSumm) || sendSumm <= 0 ) {
                alert("Введите сумму перевода");

                return;
            }

            user_data.SummUSD = sendSumm;

            SaveData();

            window.location = '/transaction';
        }
        catch (e) {
            console.log(e);
        }
    }

    //ввод суммы перевода
    function inputSumm( ev ) {
        try {
            let amountInput = $(ev.currentTarget)[0];
            let value = amountInput.value;

            if (!/^(\d+(\.\d{0,2})?)?$/.test(value)) {
                amountInput.value = value.slice(0, -1);
            }

            if (parseFloat(value) > 5000) {
                amountInput.value = value.slice(0, -1);
            }

            calcSendSumm( amountInput.value );
        }
        catch (e) {
            console.log(e);
        }
    }

    //расчёт суммы перевода
    function calcSendSumm ( inputSumm ) {
        let SummUSD = parseFloat( inputSumm );

        if (!SummUSD) {
            SummUSD = 0;
        }

        let SummRUB = SummUSD * transactions.getCurrency();

        user_data.SummUSD = SummUSD;
        user_data.SummRUB = SummRUB;

        //выводим курс на страницу
        $( "#cTLFCourse > :first-child" ).html( "Сумма перевода: " + SummRUB.toLocaleString('ru-RU', {minimumFractionDigits: 2}) + " RUB" );
    }

    //клик по документу
    function documentClick( ev ) {
        try {
            if ( isShowCountrys ) {
                if ( $(event.target).closest("#cTLFDIImg, #countrys, #cTLFDICenter, #cTLFDIArrow").length === 0 ) {
                    showHideCountrys();
                }
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //построение курса
    function buildCurrency( ev ) {
        try {
            //выводим курс на страницу
            $( "#cTLFCourse > :last-child" ).html( "Курс: " + transactions.getCurrency() + " RUB" );
        }
        catch (e) {
            console.log(e);
        }
    }

    //добавление/удаление событие со страны
    function addDelCountyEvents( elem, isAdd ) {
        try {
            if ( isAdd === true ) {
                $("> [data-id]", elem ).on( "click", countryClick );                  //клик на страну в списке
            }
            else {
                $( "> [data-id]", elem ).off( "click", countryClick );                  //клик на страну в списке
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на страну в списке
    function countryClick( ev ) {
        try {
            let countryID = parseInt( $(ev.currentTarget).attr("data-id") );
            let countryData = transactions.getCountryByID( countryID );

            if ( countryData === null ) {
                throw "Данных страны " + countryID + " нет";
            }

            //меняем страну на другую
            changeCountry( countryData );

            if ( isShowCountrys ) {
                //Скрываем страны
                showHideCountrys();
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //Смена страны
    function changeCountry( newCountryData ) {
        try {
            $( "#cTLFDIImg > img" ).attr("src", "https://" + system.getSystemData().domain + "/resources/img/country/" + newCountryData.img);
            $( "#country" ).html( newCountryData.name );

            user_data.CountryTo = newCountryData.symbol;

            //ПОТОМ УДАЛИТЬ ЭТО (не мой код)
            SaveData();
        }
        catch (e) {
            console.log(e);
        }
    }

    //скрытие|показ стран
    function showHideCountrys() {
        try {
            if ( isShowCountrys ) {
                $( "#countrys" ).removeClass( "countrysShow" );
                $( "#cTLFDIArrow" ).removeClass( "cTLFDIArrowScale" );
            }
            else {
                $( "#countrys" ).addClass( "countrysShow" );
                $( "#cTLFDIArrow" ).addClass( "cTLFDIArrowScale" );
            }

            isShowCountrys = !isShowCountrys;
        }
        catch (e) {
            console.log(e);
        }
    }

    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию скрипта главной страницы
$( mainPage.init );
