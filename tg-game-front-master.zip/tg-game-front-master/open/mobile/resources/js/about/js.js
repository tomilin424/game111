let about = aboutFunc();

function aboutFunc () {

  function init() {
    try {
      addEvents();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {

    }
    catch (e) {
      console.log(e);
    }
  }


  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию
$( about.init );
