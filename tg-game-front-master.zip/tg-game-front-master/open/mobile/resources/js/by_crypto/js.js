let byCryptoPage = byCryptoPageFunc();

function byCryptoPageFunc () {
  let isShow = {
    "bank" : false,
    "date" : false,
    "time" : false
  };
  let cryptoCurrencies = [];                                    // Криптовалюты
  let byData = {
    "selectCurrency" : {
      "count" : 0,
      "valueRub" : 0
    },
    "department" : {
      "date" : "",
      "time" : {
        "from" : "",
        "to" : ""
      }
    },
    "payType" : 1
  };                                              // Данные о покупаемой крипте
  let isSaveNewData = false;
  let step = 0;

  function init() {
    try {
      addEvents();

      // инициализируем селект
      select.init();

      //грузим криптовалюты
      loadCryptoCurrencies();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //успешная загрузка данных криптобиржи
      $( document ).on( "cryptoCurrenciesLoadSuccess", start );
      //клик на нкопку назад
      $( ".cFBBack" ).on( "click", backStep );
      //клик на нкопку далее
      $( ".cFBNext" ).on( "click", nextStep );
    }
    catch (e) {
      console.log(e);
    }
  }

  // Загружаем данные криптобиржи
  function loadCryptoCurrencies ( ) {
    try {
      $.ajax({
        url : "/apprin/v1/crypto/get/",
        type : "GET",
        success : function ( responce ) {
          console.log( responce );

          try {
            let resp = JSON.parse( responce ); //парсим ответ сервера

            // Если успешный ответ
            if ( resp.status === "ok" ) {
              // Берём данные биржи
              cryptoCurrencies = resp.data;

              // Триггерим событие
              $( document ).trigger( "cryptoCurrenciesLoadSuccess" );
            }
          }
          catch ( err ) {
            console.log( err );
          }
        },
        error : function ( err ) {
          console.log( err );
        }
      });
    }
    catch (e) {
      console.log(e);
    }
  }

  // Запуск формы
  function start( ev ) {
    try {
      // запускаем постройку этапа
      nextStep( null );
    }
    catch (e) {
      console.log(e);
    }
  }

  // Добавление/Удаление событий этапов
  function addDelStepEvents ( needStep, isAdd ) {
    try {
      // Если добавление
      if ( isAdd ) {
        // Если первый этап
        if ( needStep === 1 ) {
          $( "#currencies > .currItem" ).on( "click", step1CryptClick );                 // клик на крипту
        }

        // Если второй этап
        if ( needStep === 2 ) {
          $( "#payType > .currItemPayType" ).on( "click", step2PayTypeClick );           // клик на способ оплаты
          $( "#departments > :nth-child( 2 )" ).on( "changeSelectItem", step2ChangeDate );  // выбор даты
          $( "#departments > :last-child" ).on( "changeSelectItem", step2ChangeTime );  // выбор времени
        }
      }
      else {
        // Если первый этап
        if ( needStep === 1 ) {
          $( "#currencies > .currItem" ).off( "click", step1CryptClick );                 // клик на крипту
          $( "#currencieCount > .currCountItem" ).off( "click", step1DefaultValueClick ); // Клик на заранее определённое значение
        }

        // Если второй этап
        if ( needStep === 2 ) {
          $( "#payType > .currItemPayType" ).off( "click", step2PayTypeClick );           // клик на способ оплаты
          $( "#departments > :nth-child( 2 )" ).off( "changeSelectItem", step2ChangeDate );  // выбор даты
          $( "#departments > :last-child" ).off( "changeSelectItem", step2ChangeTime );  // выбор времени
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //---- 2-ой этап.
  // Клик на способ оплаты
  function step2PayTypeClick( ev ) {
    try {
      // Новый способ оплаты
      let newPayType = parseInt( $( ev.currentTarget ).attr( "data-val" ) );

      // Скрываем прошлый выбранный способ, кроме нового
      $( "#payType > .selectItem:not( [data-val=\"" + newPayType + "\"] )" ).removeClass( "selectItem" );
      // Показываем новый выбранный способ
      $( "#payType > .currItemPayType[data-val=\"" + newPayType + "\"]" ).addClass( "selectItem" );

      // записываем выбранный способ
      byData[ "payType" ] = newPayType;

      // показываем связанные динамические элементы оплаты
      step2ChangePayType( newPayType );
    }
    catch (e) {
      console.log(e);
    }
  }
  // Смена способа оплаты
  function step2ChangePayType( needPayType ) {
    try {
      // Скрываем связанные элементы с прошлым способом оплаты, кроме нового
      $( "#dynamicData > .dynamicDataShow:not( [data-paytype-dynamic=\"" + needPayType + "\"] )" ).removeClass( "dynamicDataShow" );
      // Показываем связанные элементы с новым способом оплаты
      $( "#dynamicData > [data-paytype-dynamic=\"" + needPayType + "\"]" ).addClass( "dynamicDataShow" );

      // Если картой ИЛИ по счёту
      if ( needPayType === 1 || needPayType === 2 ) {
        $( "[form-step=\"2\"] * .cFBNext > span" ).html( "Заплатить" );
      }

      // Если Наличными
      if ( needPayType === 3 ) {
        $( "[form-step=\"2\"] * .cFBNext > span" ).html( "Запланировать визит" );
      }
    }
    catch (e) {
      console.log(e);
    }
  }
  // Показ успешного слоя после оплаты
  function showSuccess( payType ) {
    try {
      let newStep = step + 1;
      let dynamicPartNumber = "1,2";
      // Выбранная монета покупки
      let selectCryptBy = byData[ "cryptBy" ];
      // данные курса в рублях
      let courseDataRub = cryptoCurrencies[ selectCryptBy ][ "rub" ];
      // сумма к оплате
      let sum = (byData.selectCurrency.count * courseDataRub.value).toFixed( 2 );

      // Если карта или по счёту
      if ( payType === 1 || payType === 2 ) {
        // пишем данные
        $( "[form-step=\"3\"] [step-data=\"sum\"]" ).html( sum + " ₽" );
      }

      // Если наличными
      if ( payType === 3 ) {
        // меняем номер динамической части
        dynamicPartNumber = "3";

        // пишем данные
        $( "[form-step=\"3\"] [step-data=\"sum\"]" ).html( sum + " ₽" );
        $( "[form-step=\"3\"] [step-data=\"timeFrom\"]" ).html( byData.department.time.from );
        $( "[form-step=\"3\"] [step-data=\"timeTo\"]" ).html( byData.department.time.to );
      }

      // показываем динамическую часть формы
      $( "[form-step=\"3\"] > [data-complete-dynamic=\"" + dynamicPartNumber + "\"]" ).addClass( "dynamicDataShow" );
      //скрываем прошлую форму
      $( "[form-step=\"" + step + "\"]" ).removeClass("formStepShow");
      //показываем новую форму
      $( "[form-step=\"" + newStep + "\"]" ).addClass( "formStepShow" );
    }
    catch (e) {
      console.log(e);
    }
  }
  // Выбор даты
  function step2ChangeDate( ev ) {
    try {
      // новое значение элемента
      let newValue = select.getValueByID( parseInt( $( ev.currentTarget ).attr( "select-id" ) ) );

      // записываем выбранные данные
      byData.department.date = newValue;
    }
    catch (e) {
      console.log(e);
    }
  }
  // Выбор времени
  function step2ChangeTime( ev ) {
    try {
      // новое значение элемента
      let newValue = select.getValueByID( parseInt( $( ev.currentTarget ).attr( "select-id" ) ) ).split( "|" );

      console.log( ev );

      // записываем выбранные данные
      byData.department.time.from = newValue[ 0 ];
      byData.department.time.to = newValue[ 1 ];
    }
    catch (e) {
      console.log(e);
    }
  }

  //---- 1-ый этап.
  //клик на крипту
  function step1CryptClick( ev ) {
    try {
      // Новая крипта
      let newCrypt = $( ev.currentTarget ).attr( "crypto-by" );

      // Скрываем прошлую выбранную крипту, кроме новой
      $( "#currencies > .selectItem:not( [crypto-by=\"" + newCrypt + "\"] )" ).removeClass( "selectItem" );
      // Показываем новую крипту
      $( "#currencies > .currItem[crypto-by=\"" + newCrypt + "\"]" ).addClass( "selectItem" );

      // размеры крипты на выбор
      let itemsValue = $( '<div></div>' );
      // суммы количества крипты в рублевом эквиваленте
      let itemsValueRub = [100, 500, 1000, 5000, 10000, 100000, 1000000, 10000000];
      // по дефолту выбираемое значение
      let defaultValue = 500;

      // Если в сохранённых данных есть нужная валюта И для неё значение
      if ( byData.hasOwnProperty( "selectCurrency" ) && byData.selectCurrency.hasOwnProperty( "valueRub" ) && byData.selectCurrency.valueRub > 0 ) {
        // переопределяем дефолтное значение
        defaultValue = byData.selectCurrency.valueRub;
      }

      // перебираем криптовалюты покупки
      for ( let cryptoBy in cryptoCurrencies ) {
        // перебираем криптовалюты продажи
        for ( let cryptoSell in cryptoCurrencies[ cryptoBy ] ) {
          // данные курса
          let coursData = cryptoCurrencies[ cryptoBy ][ cryptoSell ];

          // Если валюта продажи не рубль ИЛИ покупаемая валюта не равна нужной
          if ( cryptoSell.toLowerCase() !== "rub" || newCrypt !== cryptoBy.toLowerCase() ) {
            continue;
          }

          // перебираем рублевой эквивалент
          for ( let itemValueRub of itemsValueRub ) {
            // количество крипты
            let cryptValue = parseFloat( 1.0 * itemValueRub / coursData.value );

            cryptValue = cryptValue > 1 ? cryptValue.toFixed( 2 ) : cryptValue.toFixed( 7 );

            let valueRubElement = $( '<div>' +
                '<div class="currCountItem smallRadiusBorder transparentShadow">' +
                '                            <div>' +
                '                                <span class="boldFont darkFont largFontSize">' + cryptValue + ' ' + cryptoBy.toUpperCase() + '</span>' +
                '                            </div>' +
                '                        </div>' +
                '</div>' );

            // пишем параметры
            $( "> div", valueRubElement ).attr({
              "crypto-by" : cryptoBy,
              "crypto-sell" : cryptoSell,
              "crypto-value" : cryptValue,
              "crypto-value-rub" : itemValueRub
            });

            // добавляем событие элементу
            $( "> div", valueRubElement ).on( "click", step1DefaultValueClick );              // Клик на заранее определённое значение

            // добавляем элемент к другим
            itemsValue.append( valueRubElement.contents() );
          }
        }
      }

      // выводим элементы выбора на сайт
      $( "#currencieCount" ).html( itemsValue.contents() );

      // кликаем на дефолтное значение
      $( ".currCountItem[crypto-value-rub=\"" + defaultValue + "\"]" ).trigger( "click" );

      // записываем выбранную монету
      byData[ "cryptBy" ] = newCrypt;
      byData[ "cryptSell" ] = $( ev.currentTarget ).attr( "crypto-sell" );

      // Обновляем данные информации
      step1UpdateInfo ();
    }
    catch (e) {
      console.log(e);
    }
  }
  //клик на дефолтное значение крипты
  function step1DefaultValueClick( ev ) {
    try {
      // Новое значение
      let newRubValue = parseInt( $( ev.currentTarget ).attr( "crypto-value-rub" ) );
      // Новое количество
      let newCount = parseFloat( $( ev.currentTarget ).attr( "crypto-value" ) );

      // Скрываем прошлое выбранное значение, кроме нового
      $( "#currencieCount > .currCountItem:not( [crypto-value-rub=\"" + newRubValue + "\"] )" ).removeClass( "selectItem" );
      // Показываем новое значение
      $( "#currencieCount > .currCountItem[crypto-value-rub=\"" + newRubValue + "\"]" ).addClass( "selectItem" );

      // Записываем новое значение в рублях
      byData.selectCurrency[ "valueRub" ] = newRubValue;
      // Записываем новое количество
      byData.selectCurrency[ "count" ] = newCount;

      // Обновляем данные информации
      step1UpdateInfo ();
    }
    catch (e) {
      console.log(e);
    }
  }
  //перестроение информации справа
  function step1UpdateInfo( ) {
    try {
      // Выбранная монета покупки
      let selectCryptBy = byData[ "cryptBy" ];
      // Выбранная монета продажи
      let selectCryptSell = byData[ "cryptSell" ];
      // данные курса
      let courseData = cryptoCurrencies[ selectCryptBy ][ selectCryptSell ];
      // данные курса в рублях
      let courseDataRub = cryptoCurrencies[ selectCryptBy ][ "rub" ];

      if ( courseData === undefined || courseData === null ||
          courseDataRub === undefined || courseDataRub === null) {
        throw "Не найден курс";
      }

      // Родительская форма
      let parentForm = $( '[form-step="1"]' );

      // Меняем данные
      $( "[step-info=\"by\"]", parentForm ).html( courseData.by.toUpperCase() );
      $( "[step-info=\"byFull\"]", parentForm ).html( courseData.byFull );
      $( "[step-info=\"cours_usd\"]", parentForm ).html( "1 " + courseData.by.toUpperCase() + " = " + courseData.value.toFixed( 2 ) + " $" );
      $( "[step-info=\"cours_rub\"]", parentForm ).html( "1 " + courseData.by.toUpperCase() + " = " + courseDataRub.value.toFixed( 2 ) + " ₽" );
      $( "[step-info=\"count\"]", parentForm ).html( byData.selectCurrency.count + " " + courseData.by.toUpperCase() );
      $( "[step-info=\"sum\"]", parentForm ).html( (byData.selectCurrency.count * courseDataRub.value).toFixed( 2 ) + " ₽" );
    }
    catch (e) {
      console.log(e);
    }
  }

  //переход к следующему этапу
  function nextStep( ev ) {
    try {
      let newStep = step + 1;

      if ( newStep > 2 ) {
        //сохраняем данные перевода
        saveClick( null );

        return;
      }

      // удаляем события прошлого этапа
      addDelStepEvents( step, false );

      // Если первый этап
      if ( newStep === 1 ) {
        // криптовалюты, доступные для выбора
        let items = $( '<div></div>' );
        // размеры крипты на выбор
        let itemsValue = $( '<div></div>' );
        // суммы количества крипты в рублевом эквиваленте
        let itemsValueRub = [100, 500, 1000, 5000, 10000, 100000, 1000000, 10000000];
        // выбираемая по дефолту монета
        let defaultCrypt = "btc";

        // Если в сохранённых данных есть выбранная монета
        if ( byData.hasOwnProperty( "cryptBy" ) ) {
          // переопределяем дефолтное значение
          defaultCrypt = byData[ "cryptBy" ];
        }

        // перебираем криптовалюты покупки
        for ( let cryptoBy in cryptoCurrencies ) {
          // перебираем криптовалюты продажи
          for ( let cryptoSell in cryptoCurrencies[ cryptoBy ] ) {
            // данные курса
            let coursData = cryptoCurrencies[ cryptoBy ][ cryptoSell ];

            //console.log(coursData);

            // Если валюта продажи не доллар
            if ( cryptoSell.toLowerCase() !== "usd" ) {
              continue;
            }

            let element = $( '<div>' +
                '<div class="currItem smallRadiusBorder transparentShadow">' +
                '                            <div class="currIHead">' +
                '                                <div class="currIHLeft">' +
                '                                    <div>' +
                '                                        <span class="boldFont darkFont largFontSize">' + cryptoBy.toUpperCase() + '</span>' +
                '                                    </div>' +
                '' +
                '                                    <div>' +
                '                                        <span class="grayFont largFontSize">' + coursData.byFull + '</span>' +
                '                                    </div>' +
                '                                </div>' +
                '' +
                '                                <div class="currIHRight">' +
                '                                    <img src="' + mainDomain + '/resources/img/cryptocurrencies/' + cryptoBy.toLowerCase()+ '.png" alt="' + cryptoBy.toLowerCase() + '" />' +
                '                                </div>' +
                '                            </div>' +
                '' +
                '                            <div class="currICourse">' +
                '                                <span class="darkFont boldFont largFontSize">' + coursData.value + ' $</span>' +
                '                            </div>' +
                '                        </div>' +
                '</div>' );

            // Пишем атрибуты
            $( "> div", element ).attr({
              "crypto-by" : cryptoBy,
              "crypto-sell" : cryptoSell,
              "crypto-value" : coursData.value
            });

            // Добавляем монету
            items.append( element.contents() );
          }
        }

        // выводим крипту на сайт
        $( "#currencies" ).html( items.contents() );
        // выводим элементы выбора на сайт
        $( "#currencieCount" ).html( itemsValue.contents() );

        // добавляем события нового этапа
        addDelStepEvents( newStep, true );

        // кликаем на нужную монету
        $( "#currencies > .currItem[crypto-by=\"" + defaultCrypt + "\"]" ).trigger( "click" );
      }

      // Если второй этап
      if ( newStep === 2 ) {
        // тип оплаты по дефолту
        let defaultPayType = 1;

        // Если есть по дефолту тип оплаты
        if ( byData.hasOwnProperty( "payType" ) && byData.payType > 0 ) {
          defaultPayType = byData.payType;
        }

        // Выбранная монета покупки
        let selectCryptBy = byData[ "cryptBy" ];
        // данные курса в рублях
        let courseDataRub = cryptoCurrencies[ selectCryptBy ][ "rub" ];
        // сумма к оплате
        let sum = (byData.selectCurrency.count * courseDataRub.value).toFixed( 2 );

        // выводим сумму к оплате
        $( "[form-step=\"2\"] * .cFFLToPay > :last-child > span" ).html( sum + " ₽" );


        // элементы на выбор
        let selectItems = [
          {
            id : 1,
            value : 1,
            text : "г. Новосибирск, ул. Карла Маркса, д. 13",
            isDefault : false
          }
        ];

        // Добавляем селект отделения банка
        select.add( $( "#departments > :first-child" ), {
          items : selectItems,
          label : "ОТДЕЛЕНИЕ БАНКА"
        } );

        let nowDate = new Date();

        // элементы на выбор
        selectItems = [];
        let days = [ "Понедельник", "Вторник", "Среда", "Четверг", "Пятница" ]

        // перебираем дни от завтрашнего до недели
        for ( let day = 1; day <= 7; day++ ) {
          //добавляем к дате дни
          nowDate.setDate( nowDate.getDate() + 1 );

          if ( nowDate.getDay() === 5 || nowDate.getDay( ) === 6 ) {
            continue;
          }

          selectItems.push({
            id : day,
            value : day,
            text : days[ nowDate.getDay() ] + ", " + ("00" + nowDate.getDate()).slice( -2 ) + " " + nowDate.toLocaleString( "default", {
              month : "long"
            } ) + " " + nowDate.getFullYear() + " г.",
            isDefault : false
          });
        }

        // Добавляем селект даты визита
        select.add( $( "#departments > :nth-child( 2 )" ), {
          items : selectItems,
          label : "ДАТА ВИЗИТА"
        } );

        // элементы на выбор
        selectItems = [];
        nowDate = new Date();

        nowDate.setHours( 9 );
        nowDate.setMinutes( 0 );
        nowDate.setSeconds( 0 );
        nowDate.setMinutes( nowDate.getMinutes() + 30 );

        // количество минут
        let minutes = nowDate.getMinutes();

        if ( minutes < 30 ) {
          minutes = 30;
        }
        else {
          minutes = minutes + ( 60 - minutes );
        }

        nowDate.setMinutes( minutes );

        // перебираем время с начала рабочего до завершения времени работы. Кратно 30 минут
        while ( nowDate.getHours() <= 20 ) {
          let endDate = new Date( nowDate );

          endDate.setMinutes( endDate.getMinutes() + 29 );

          selectItems.push({
            id : nowDate.getHours() + nowDate.getMinutes(),
            value : ( "00" + nowDate.getHours() ).slice( -2 ) + ":" + ( "00" + nowDate.getMinutes() ).slice( -2 ) + "|" +
                ( "00" + endDate.getHours() ).slice( -2 ) + ":" + ( "00" + endDate.getMinutes() ).slice( -2 ),
            text : "c " + ( "00" + nowDate.getHours() ).slice( -2 ) + ":" + ( "00" + nowDate.getMinutes() ).slice( -2 ) + " по " +
                ( "00" + endDate.getHours() ).slice( -2 ) + ":" + ( "00" + endDate.getMinutes() ).slice( -2 ),
            isDefault : false
          });

          //добавляем к дате 30 минут
          nowDate.setMinutes( nowDate.getMinutes() + 30 );
        }

        // Добавляем селект времени визита
        select.add( $( "#departments > :last-child" ), {
          items : selectItems,
          label : "ВРЕМЯ ВИЗИТА"
        } );


        // добавляем события нового этапа
        addDelStepEvents( newStep, true );

        // кликаем на дефолтный тип оплаты
        $( "#payType > .currItemPayType[data-val=\"" + defaultPayType + "\"]" ).trigger( "click" );
      }

      //скрываем прошлую форму
      $( "[form-step=\"" + step + "\"]" ).removeClass("formStepShow");
      //показываем новую форму
      $( "[form-step=\"" + newStep + "\"]" ).addClass( "formStepShow" );

      step = newStep;
    }
    catch (e) {
      console.log(e);
    }
  }

  //переход к прошлому этапу
  function backStep( ev ) {
    try {
      let newStep = step - 2;

      if ( newStep < 0 ) {
        newStep = 0;
      }

      // удаляем события текущего этапа
      addDelStepEvents( step, false );

      //скрываем текущую форму
      $( "[form-step=\"" + step + "\"]" ).removeClass( "formStepShow" );

      step = newStep;

      // Строим этап
      nextStep( null );
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на кнопку Сохранить
  function saveClick( e ) {
    try {
      if ( isSaveNewData ) {
        return;
      }

      isSaveNewData = true;

      // Если оплата картой
      if ( byData[ "payType" ] === 1 ) {
        // Если не заполнены поля
        if ( $( "[name=\"fio\"]" ).val().length === 0 || $( "[name=\"email\"]" ).val().length === 0 ) {
          alert( "Необходимо заполнить данные для оплаты" );

          throw "Необходимо заполнить данные для оплаты";
        }
      }

      // Если оплата по реквизитам
      if ( byData[ "payType" ] === 2 ) {
        // Если не заполнены поля
        if ( $( "[name=\"inn\"]" ).val().length === 0 || $( "[name=\"corporate_bill\"]" ).val().length === 0 ||
            $( "[name=\"kpp\"]" ).val().length === 0 || $( "[name=\"bill\"]" ).val().length === 0 ||
            $( "[name=\"bik\"]" ).val().length === 0 ) {
          alert( "Необходимо заполнить данные для оплаты" );

          throw "Необходимо заполнить данные для оплаты";
        }
      }

      // Если оплата наличными
      if ( byData[ "payType" ] === 3 ) {
        // Если не заполнены поля
        if ( byData.department.time.from.toString().length <= 1 ||
            byData.department.time.to.toString().length <= 1 ||
            byData.department.date === "" ) {
          alert( "Необходимо выбрать отделение, дату и время" );

          throw "Необходимо выбрать отделение, дату и время";
        }
      }

      // Показываем слой с успешным завершением покупки
      showSuccess( byData[ "payType" ] );

      /*let errors = 0;
      let oldUserData = user.getUserData();
      let sendData = {};

      console.log( oldUserData );
      $( ".cForm * input" ).each(function( ) {
        let elem = $( this );

        console.log(elem.attr("id"));

        let elemData = {
          "id" : elem.attr("send-key") !== undefined && elem.attr("send-key") !== null ? elem.attr("send-key") : elem.attr("id"),
          "value" : elem.val()
        };

        if ( elemData.value === undefined || elemData.value === null ||
            elem.attr("id") !== "toOtchestvo" && elem.attr("id") !== "three_name" && elem.attr("id") !== "promo" && elemData.value === "" ) {
          elem.parents( ".cFItem" ).addClass( "cFItemError" );

          errors++;
        }

        sendData[ elemData.id ] = elemData.value;
      });

      //Добавляем данные отправителя
      sendData[ "fromTel" ] = user_data.full_number;

      //Добавляем данные стран
      sendData[ "fromCountryID" ] = parseInt( $("[data-show=\"from\"][select-id]").attr("select-id") );
      sendData[ "toCountryID" ] = parseInt( $("[data-show=\"to\"][select-id]").attr("select-id") );

      //Добавляем курс и валюту
      sendData[ "course" ] = user_data.currency;
      sendData[ "currency" ] = 5;

      if ( errors > 0 ) {
        isSaveNewData = false;

        alert( "Проверьте выделенные поля" );

        return;
      }

      fetch('/apprin/v1/transaction/new/', {
        method: 'POST',
        body: JSON.stringify(sendData)
      })
          .then(response => response.json())
          .then(response => {
            if ( response.status === "ok" ) {
              window.location.href = "/lk";
            }
            else {
              console.log("Ошибка сохранения новых данных: " + response.text);

              alert( "Ошибка сохранения новых данных: " + response.text );
            }
          }).finally(() => isSaveNewData = false);*/
    }
    catch (e) {
      console.log(e);

      isSaveNewData = false;
    }
  }

  return {
    init: function() {
      init();
    }
  }
}

let select = selectFunc();

function selectFunc () {
  // элементы
  let items = [];

  // Инициализация элемента
  function init (  ) {
    try {
      addEvents();                          // Добавляем события
    }
    catch (e) {
      console.log(e);
    }
  }

  // Добавление событий
  function addEvents (  ) {
    try {
      $( document ).on( "click", documentClick );                               // клик на документе
    }
    catch (e) {
      console.log(e);
    }
  }

  // Добавление нового селекта
  /*
  * settings : {
  *   items : [
  *     {
  *       id : 1,               // уникальный ИД элемента на выбор (только число)
  *       text : "dfdfdf",      // выводимый текст
  *       value : "33"          // значение, которое будет возвращаться (может быть что угодно)
  *     }
  *   ],
  *   label : "Заголовок"
  * }
  * */
  function add ( elementParent, settings = {} ) {
    try {
      // получаем свободный ИД
      let freeID = getFreeID();

      if ( freeID === null || freeID <= 0 ) {
        throw "Не удалось получить свободный ИД";
      }

      // контент элемента
      let elementContent = $( '<div>' +
          '<div class="select-item">' +
          '                                        <div class="select-item-center">' +
          '                                            <div class="select-label">' +
          '                                                <span class="lightBlackFont"></span>' +
          '                                            </div>' +
          '' +
          '                                            <div>' +
          '                                                <span class="blackFont largFontSize selectText">&nbsp;</span>' +
          '                                            </div>' +
          '                                        </div>' +
          '' +
          '                                        <div class="select-item-arrow">' +
          '                                            <img src="' + mainDomain + '/resources/img/start/arrow.svg">' +
          '                                        </div>' +
          '                                    </div>' +
          '' +
          '                                    <div class="select-items"></div>' +
          '</div>' );

      //элементы для вставки
      let selectItems = $( '<div></div>' );

      //ID выбранного по дефолту элемента
      let defaultSelectItemID = 0;

      // Если заданы элементы
      if ( settings.hasOwnProperty( "items" ) ) {
        // перебираем элементы на выбор
        for ( let setItem of settings.items ) {
          let selectItem = $( '<div>' +
              '<div>' +
              '     <div>' +
              '         <span class="blackFont largFontSize"></span>' +
              '     </div>' +
              '</div>' +
              '</div>' );

          // Пишем данные
          $( "span", selectItem ).html( setItem.hasOwnProperty( "text" ) ? setItem.text : "" );

          // Пишем атрибуты
          $( "> div", selectItem ).attr({
            "data-id" : setItem.id
          });

          // Клик на элемент на выбор
          $( "> div", selectItem ).on( "click", selectItemClick );

          // Если элемент надо выбрать и ещё не отмечен элемент на выбор
          if ( defaultSelectItemID === 0 && setItem.hasOwnProperty( "isDefault" ) && setItem.isDefault ) {
            defaultSelectItemID = setItem.id;
          }

          // Добавляем элемент на выбор к другим
          selectItems.append( selectItem.contents() );
        }
      }

      // Если задан заголовок
      if ( settings.hasOwnProperty( "label" ) ) {
        $( ".select-label > span", elementContent ).html( settings.label );
      }

      // Добавляем элементы на выбор
      $( ".select-items", elementContent ).html( selectItems.contents() );


      // Добавляем контент в элемент
      elementParent.html( elementContent.contents() );

      // Добавляем атрибуты и классы в родительский элемент
      $( elementParent ).attr({
        "select-id" : freeID,
        "select-item-id" : defaultSelectItemID > 0 ? defaultSelectItemID : "",
        "select-show" : "0"
      }).addClass( "select" );

      // Добавляем событие клика по элементу
      $( elementParent ).on( "click", elementClick );


      // данные элемента
      let elementData = {
        "element" : elementParent,
        "settings" : settings,
        "id" : freeID
      };

      // добавляем данные элемента к другим
      items.push( elementData );

      // Если выбран элемент на выбор по дефолту
      if ( defaultSelectItemID > 0 ) {
        // меняем выбранный элемент без триггера события
        changeSelectItem( freeID, defaultSelectItemID, false );
      }
    }
    catch ( e ) {
      console.log( e );

      return null;
    }
  }

  //клик по документу
  function documentClick( ev ) {
    try {
      console.log( ev );

      // Если в родителях есть селект или текущий элемент это селект
      if ( $( ev.target ).parents( "[select-id]" ).length > 0 || parseInt( $( ev.target ).attr( "select-id" ) ) > 0 ) {
        return;
      }

      // перебираем элементы
      for ( let elementData of items ) {
        // Если элементы на выбор отображаются
        if ( parseInt( $( elementData.element ).attr( "select-show" ) ) === 1 ) {
          // скрываем
          showHideSelectItems( parseInt( $( elementData.element ).attr( "select-id" ) ), false );
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на элемент
  function elementClick( ev ) {
    try {
      // ID элемента
      let elementID = parseInt( $( ev.currentTarget ).attr("select-id") );
      // 0 - скрыты элементы на выбор, 1 - показаны
      let isShow = parseInt( $( ev.currentTarget ).attr( "select-show" ) );

      console.log( elementID, isShow );

      // показываем/скрываем элементы на выбор
      showHideSelectItems( elementID, isShow !== 1 );
    }
    catch (e) {
      console.log(e);
    }
  }

  //показ/скрытие элементов на выбор
  function showHideSelectItems( elementID, isShow = true ) {
    try {
      // данные элемента
      let elementData = getElementByID( elementID, true );

      if ( elementData === null ) {
        throw "Не найден родительский элемент";
      }

      // меняем данные в элементе
      $( elementData.element ).attr({
        "select-show" : isShow ? 1 : 0
      });

      // Если надо показать
      if ( isShow ) {
        $( ".select-items", elementData.element ).addClass( "select-items-show" );
      }
      else {
        $( ".select-items", elementData.element ).removeClass( "select-items-show" );
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  // Получение свободного ИД
  function getFreeID ( ) {
    try {
      let freeID = 0;

      // Перебираем ИД
      while ( freeID <= 10000 ) {
        freeID++;

        // получаем элемент по ИД
        let element = getElementByID( freeID );

        // Если элемента нет
        if ( element === null ) {
          // выходим из цикла перебора
          break;
        }
      }

      return freeID;
    }
    catch ( e ) {
      console.log( e );

      return null;
    }
  }

  // Получение элемента по ИД
  function getElementByID ( id, allData = false ) {
    try {
      // перебираем элементы
      for ( let item of items ) {
        // Если ИД равны
        if ( item.id === id ) {
          return !allData ? item.element : item;
        }
      }

      return null;
    }
    catch ( e ) {
      console.log( e );

      return null;
    }
  }

  // Получение значения по ИД элемента
  function getValueByID ( id ) {
    try {
      // получаем данные элемента
      let elementData = getElementByID( id, true );

      if ( elementData === null ) {
        throw "Не найдены данные элемента по ИД " + id;
      }

      // выбранный ИД элемента
      let selectID = elementData.element.attr( "select-item-id" );

      // Если ничего не выбрано
      if ( selectID === undefined || selectID === null || selectID === "" ) {
        return false;
      }

      // перебираем элементы на выбор
      for ( let selItem of elementData.settings.items ) {
        // Если ИД равны
        if ( parseInt( selItem.id ) === parseInt( selectID ) ) {
          // возвращаем выбранное значение
          return selItem.value;
        }
      }

      return null;
    }
    catch ( e ) {
      console.log( e );

      return null;
    }
  }

  // Получение элемента на выбор
  function getSelectItem ( selectID, selectItemID ) {
    try {
      // получаем данные элемента
      let elementData = getElementByID( selectID, true );

      // перебираем элементы на выбор
      for ( let selItem of elementData.settings.items ) {
        // Если ИД равны
        if ( parseInt( selItem.id ) === parseInt( selectItemID ) ) {
          // возвращаем данные
          return selItem;
        }
      }

      return null;
    }
    catch ( e ) {
      console.log( e );

      return null;
    }
  }

  // Клик на элемент на выбор
  function selectItemClick ( ev ) {
    try {
      // новое выбранное ИД
      let newSelectItemID = parseInt( $( ev.currentTarget ).attr( "data-id" ) );

      if ( isNaN(newSelectItemID) ) {
        throw "Недопустимый ИД элемента на выбор";
      }

      // ID родителя
      let parentID = parseInt( $( $( ev.currentTarget ).parents( "[select-id]" )[ 0 ] ).attr( "select-id" ) );

      if ( isNaN(parentID) || parentID <= 0 ) {
        throw "Недопустимый ИД элемента";
      }

      // меняем выбранный элемент на нужный
      changeSelectItem( parentID, newSelectItemID );
    }
    catch ( e ) {
      console.log( e );
    }
  }

  // Смена выбранного элемента
  function changeSelectItem ( selectID, selectItemID, isTrigger = true ) {
    try {
      // Получаем данные элемента
      let elemData = getElementByID( selectID, true );
      // Получаем данные элемента на выбор
      let selectItemData = getSelectItem( selectID, selectItemID );

      if ( elemData === null ) {
        throw "Не получены данные элемента";
      }

      if ( selectItemData === null ) {
        throw "Не получены данные элемента на выбор";
      }

      // Выводим новый выбранный текст
      $( ".selectText", elemData.element ).html( selectItemData.text );
      // В параметрах записываем новый выбранный элемент на выбор
      $( elemData.element ).attr({
        "select-item-id" : selectItemID
      })

      // Если надо триггерить событие
      if ( isTrigger ) {
        // триггерим событие
        elemData.element.trigger( "changeSelectItem" );
      }
    }
    catch ( e ) {
      console.log( e );
    }
  }

  return {
    init : function ( ) {
      init();
    },
    add : function ( element, settings ) {
      return add ( element, settings );
    },
    getValueByID : function ( id ) {
      return getValueByID ( id );
    }
  }
}

// запускаем инициализацию
$( byCryptoPage.init );