let help = helpFunc();

function helpFunc () {
  let items = [];               //элементы для FAQ-а

  function init() {
    try {
      addInitEvents();

      $.ajax({
        url : "/apprin/v1/help/get_data/",
        type : "POST",
        success : function ( responce ) {
          console.log( responce );

          try {
            let resp = JSON.parse( responce ); //парсим ответ сервера

            if ( resp.status === "ok" ) {
              items = resp.data;

              $( document ).trigger( "helpLoadSuccess" );
            }
          }
          catch ( err ) {
            console.log( err );
          }
        },
        error : function ( err ) {
          console.log( err );
        }
      });
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событий инициализации
  function addInitEvents() {
    try {
      //успешная загрузка данных помощи
      $( document ).on( "helpLoadSuccess", buildItems );
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //клик на запись
      $( ".iLabel" ).on( "click", itemCLick );
      //клик на ссылки
      $( "[data-link-key]" ).on( "click", linkClick );
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на ссылки
  function linkClick ( e ) {
    try {
      let needKey = $(e.currentTarget).attr( "data-link-key" );
      let needElem = $( "[data-key=\"" + needKey + "\"]" );

      //разворачиваем раздел
      needElem.attr( "data-active", "1" );

      //перематываем до нужного раздела
      $( "html" ).animate({
        scrollTop: needElem.offset().top - 150
      }, 300);
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на запись
  function itemCLick ( e ) {
    try {
      let parent = $( $(e.currentTarget).parent() );
      let isShow = parseInt( parent.attr("data-active") ) === 1;

      parent.attr({
        "data-active" : + !isShow
      });
    }
    catch (e) {
      console.log(e);
    }
  }

  //построение элементов FAQ-а
  function buildItems( ev ) {
    try {
      let elements = $( '<div></div>' );

      items.forEach( item => {
        let elem = $('<div>' +
            '<div class="item smallRadiusBorder whiteBackground normalShadow" data-key="" data-active="0">' +
            '            <div class="iLabel">' +
            '                <div>' +
            '                    <span class="darkFont boldFont largerFontSize"></span>' +
            '                </div>' +
            '' +
            '                <img src="' + mainDomain  + '/resources/img/help/arrow.svg" />' +
            '            </div>' +
            '' +
            '            <div class="iContent grayFont largerFontSize">' +
            '            </div>' +
            '        </div>' +
            '</div>');

        $( "* .iLabel > :first-child() > span", elem ).html( item.label );

        let text = item.text;

        //меняем переносы на html-овские
        text = text.replace( /\n/g, "<br />" );

        let regexp = /(::.+?::)/gm;
        //вставки в код
        let matches = [ ...text.matchAll( regexp ) ];

        console.log( matches[0] );

        matches.forEach( match => {
          try {
            let matchItem = match[0];
            let matchItems = matchItem.split( "::" )[ 1 ].split( "||" );
            let key = matchItems[ 0 ];
            let linkText = matchItems[ 1 ];

            let link = '<span class="iLink blueFont underlineFont" data-link-key="' + key + '">' + linkText + '</span>';

            //заменяем кусок ссылкой
            text = text.replace( matchItem, link );
          }
          catch ( err ) {
            console.log( err );
          }
        });

        $( "* .iContent", elem ).html( text );

        $( "> div", elem ).attr({
          "data-key" : item.key
        });

        elements.append( elem.contents() );
      });

      //добавляем страны на страницу
      $( "#items" ).html( elements.contents() );

      //вешаем события
      addEvents();
    }
    catch (e) {
      console.log(e);
    }
  }


  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию
$( help.init );
