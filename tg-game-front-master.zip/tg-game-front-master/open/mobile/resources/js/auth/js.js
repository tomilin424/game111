let auth = authFunc();

function authFunc () {
  let isShowCountrys = false;               // 0 - страны не отображаются, 1 - отображаются
  let timer = null;
  let lostTime = 30;
  let isActive = false;                     //1 - идёт авторизация, 0 - не идёт

  function init() {
    try {
      addEvents();

      //грузим страны
      transactions.loadCountrys();
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //наличие валидной сессии
      $( document ).on( "checkSessionValid", ev => {window.location.href = "/lk"} )
          .on( "authError", (ev, errData) => {alert(errData.error);} )
          .on ( "authEnd", ev => {isActive = false;} );
      //клик на кнопку Войти
      $( "#cFSendCode" ).on( "click", enterStart );
      //клик на кнопку Получить код
      $( "#cFGetCode" ).on( "click", getCodeStart );
      //ввод номера телефона
      $('#cFNumber').on('input', inputPhoneNumber);
      //ввод кода
      $('#cFCode').on('input', inputCode);

      //успешная загрузка данных стран
      $( document ).on( "countryLoadSuccess", buildCountrys );
      //обработка клика по документу
      $(document).on("click", documentClick);
      //клик на элемент страны
      $( "#countryContainer" ).on( "click", showHideCountrys );

    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на кнопку Войти
  function enterStart( ev ) {
    try {
      if ( isActive ) {
        return;
      }

      isActive = true;

      var num = $( "#cFCode" ).val();
      var Fnumber = user_data.number;

      //Пробуем авторизоваться
      session.auth( Fnumber, 1, {"code" : num} );
    }
    catch (e) {
      console.log(e);

      isActive = true;
    }
  }

  //ввод номера телефона
  function inputPhoneNumber( ev ) {
    try {
      ev.currentTarget.value = ev.currentTarget.value.replace(/[^0-9]/g, '');
    }
    catch (e) {
      console.log(e);
    }
  }
  //ввод кода
  function inputCode( ev ) {
    try {
      ev.currentTarget.value = ev.currentTarget.value.replace(/[^0-9]/g, '');
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на кнопку Получить код
  function getCodeStart( ev ) {
    try {
      if ( isActive ) {
        return;
      }

      isActive = true;

      // Код страны
      let phoneCountryCode = transactions.getCountryByID( parseInt( $( "#countryContainer" ).attr( "select-id" ) ) );

      // Если не получены данные страны
      if ( phoneCountryCode === null || phoneCountryCode === false ) {
        alert('Необходимо выбрать страну');

        return;
      }

      // берём код страны
      phoneCountryCode = phoneCountryCode.phoneCode;

      //номер телефона (только цифры)
      let Fnumber = $( "#cFNumber" ).val().replace( /[^\d]/g, "" );

      if (Fnumber === '') {
        alert('Заполните номер телефона!');

        return;
      }

      /*if (Fnumber.length !== 11) {
        alert( "Номер телефона заполнен некорректно!" );

        return;
      }*/

      user_data.number = phoneCountryCode + Fnumber;

      SaveData();

      fetch('/apprin/v1/auth/start/', {
        method: 'POST',
        body: JSON.stringify({'Full_Number' : phoneCountryCode + Fnumber,'authType' : 1, 'authData' : {}})
      })
          .then(response => response.json())
          .then(response => {
            try {
              //Если ошибка
              if (response["status"] != "ok") {
                throw response["text"];
              }

              //выключаем кнопку
              onOffGetCodeBtn(false);


              lostTime = 30;

              //запускаем таймер
              timerStart();
              //показываем блок ввода кода
              showHideCodeBlock(true);
            }
            catch (err) {
              alert(err);
            }
          }).finally(() => {
        isActive = false;
      });
    }
    catch (e) {
      console.log(e);

      isActive = false;
    }
  }

  //Вкл/Выкл кнопки Получить код
  function onOffGetCodeBtn( isOn  ) {
    try {
      if ( isOn === true ) {
        $( "#cFGetCode" ).removeClass( "cFGetCodeDisable" );
      }
      else {
        $( "#cFGetCode" ).addClass( "cFGetCodeDisable" );
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //Запуск таймера
  function timerStart( ) {
    try {
      //выводим время
      timerShowTime();

      timer = setTimeout(timerContinue, 1000);
    }
    catch (e) {
      console.log(e);
    }
  }

  //Продолжение таймера
  function timerContinue( ) {
    try {
      lostTime--;

      clearTimeout( timer );

      timer = null;

      if ( lostTime <= 0 ) {
        //включаем кнопку
        onOffGetCodeBtn( true );

        $( "#cFGetCode > span" ).html( "Получить код" );

        return;
      }

      //выводим время
      timerShowTime();

      timer = setTimeout(timerContinue, 1000);
    }
    catch (e) {
      console.log(e);
    }
  }

  //Вывод таймера
  function timerShowTime( ) {
    try {
      $( "#cFGetCode > span" ).html( "Получить код через " + lostTime + " с." );
    }
    catch (e) {
      console.log(e);
    }
  }

  //скрытие|показ блока ввода кода
  function showHideCodeBlock( isShow ) {
    try {
      let elem = $( "#cFormCode" );

      if ( isShow === true ) {
        elem.addClass( "cFormCodeShow" );
      }
      else {
        elem.removeClass( "cFormCodeShow" );
      }
    }
    catch (e) {
      console.log(e);
    }
  }


  //клик по документу
  function documentClick( ev ) {
    try {
      if ( isShowCountrys ) {
        if ( $(ev.target).closest("#countryContainer").length === 0 ) {
          ev.currentTarget = $( "#countryContainer" );

          console.log( "auth.js, doc click", $(ev.target), $(ev.target).attr( "id" ) );

          showHideCountrys( ev );
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //построение стран
  function buildCountrys( ev ) {
    try {
      let countrys = transactions.getCountrys();

      if ( countrys === null ) {
        throw "Страны не получены";
      }

      let elements = $( '<div></div>' );

      countrys.forEach( item => {
        let elem = $('<div>' +
            '<div>' +
            '                                <div>' +
            '                                    <img src="" />' +
            '                                </div>' +
            '                                <div>' +
            '                                    <span class="blackFont largerFontSize"></span>' +
            '                                </div>' +
            '                            </div>' +
            '</div>');

        $( "* img", elem ).attr({
          "src" : "https://" + system.getSystemData().domain + "/resources/img/country/" + item.flag
        });
        $( "* span", elem ).html( "+" + item.phoneCode + ", " + item.name );

        $( "> div", elem ).attr({
          "data-id" : item.id
        });

        //добавляем события
        addDelCountyEvents( elem, true );

        elements.append( elem.contents() );
      } )

      //добавляем страны на страницу
      $( "#countrys" ).append( elements.contents() );

      $("#countrys > [data-id=\"185\"]").trigger("click");
      $( document ).trigger( "click" );
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление/удаление событие со страны
  function addDelCountyEvents( elem, isAdd ) {
    try {
      if ( isAdd === true ) {
        $("> [data-id]", elem ).on( "click", countryClick );                  //клик на страну в списке
      }
      else {
        $( "> [data-id]", elem ).off( "click", countryClick );                  //клик на страну в списке
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на страну в списке
  function countryClick( ev ) {
    try {
      let countryID = parseInt( $(ev.currentTarget).attr("data-id") );
      let countryData = transactions.getCountryByID( countryID );

      if ( countryData === null ) {
        throw "Данных страны " + countryID + " нет";
      }

      let parentShow = $(ev.currentTarget).parents( "#countryContainer" );

      //меняем страну на другую
      changeCountry( parentShow, countryData );

      if ( isShowCountrys ) {
        //Скрываем страны
        showHideCountrys( ev );
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //Смена страны
  function changeCountry( parentShow, newCountryData ) {
    try {
      parentShow.attr("select-id", newCountryData.id);

      $( ".cTLFDIImg > img", parentShow ).attr("src", "https://" + system.getSystemData().domain + "/resources/img/country/" + newCountryData.flag);
      $( ".country", parentShow ).html( "+" + newCountryData.phoneCode + ", " + newCountryData.name );
    }
    catch (e) {
      console.log(e);
    }
  }

  //скрытие|показ стран
  function showHideCountrys( ev ) {
    try {
      let parentShow = $(ev.currentTarget);

      if ( isShowCountrys ) {
        $( ".countrys", parentShow ).removeClass( "countrysShow" );
        $( ".cTLFDIArrow", parentShow ).removeClass( "cTLFDIArrowScale" );
      }
      else {
        $( ".countrys", parentShow ).addClass( "countrysShow" );
        $( ".cTLFDIArrow", parentShow ).addClass( "cTLFDIArrowScale" );
      }

      isShowCountrys = !isShowCountrys;
    }
    catch (e) {
      console.log(e);
    }
  }

  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию скрипта страницы авторизации
$( auth.init );
