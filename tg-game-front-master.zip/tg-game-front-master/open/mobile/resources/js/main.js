/* Mooving between pages */
function SentPage1() {
    SaveData();
    mooveToSent();
}


function SentPage2() {
    if (document.getElementById('CountryTo').innerHTML == "Кыргызстан") {
		user_data.CountryTo = "KG";
	}
	SaveData();
	if ( document.getElementById('Summ').value != '' ) {
		mooveToSent2();
	}
}

function SentPage3() {
    SaveData();
	if ( document.getElementById('reciever_name').value != '' && document.getElementById('reciever_surname').value != '' && document.getElementById('reciever_number').value != '') {
		mooveToSent3();
	}
}

async function LoadSent1() {
    UploadData();
    var SummUSD = user_data.SummUSD;
    var SummRUB = user_data.SummRUB;

	get_currency();
	
    if (SummRUB != '' && SummUSD != '') {
        document.getElementById('Summ').value = SummUSD;
        PostRUBval(SummRUB);
    }
}

async function LoadSent2() {
    UploadData();

    var SummRUB = user_data.SummRUB;
    var rn = user_data.reciever_name;
    var rs = user_data.reciever_surname;
    var rp = user_data.reciever_patrynomic;
    var rf = user_data.reciever_phone;
    var promo = user_data.promo;
	
	if (user_data.CountryTo != '') {
        if (user_data.CountryTo == "KZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Казахстан';
		}
        if (user_data.CountryTo == "TR") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Турция';
		}
        if (user_data.CountryTo == "AZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Азербайджан';
		}
        if (user_data.CountryTo == "KG") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Кыргызстан';
		}
        if (user_data.CountryTo == "UZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Узбекистан';
		}
    }
    if (SummRUB != '') {
        PostRUBval(SummRUB);
    }
    if (rn != '') {
        document.getElementById('reciever_name').value = rn;
    }
    if (rs != '') {
        document.getElementById('reciever_surname').value = rs;
    }
    if (rp != '') {
        document.getElementById('reciever_patrynomic').value = rp;
    }
    if (rf != '') {
        document.getElementById('reciever_number').value = rf;
    }
    if (promo != '0') {
        document.getElementById('Promo').value = promo;
    }
}

async function LoadSend3() {
    UploadData();

    var SummRUB = user_data.SummRUB;
    var surname = user_data.surname;
    var name = user_data.name;
    var birthday = user_data.birthday;
    var IDs = user_data.id_card_series;
    var IDn = user_data.id_card_number;
    var code = user_data.code;
    var date = user_data.date_of_issue;
    var addr = user_data.residence_address;
    var Rs = user_data.reciever_surname;
    var Rn = user_data.reciever_name;
    var Rf = user_data.reciever_phone;


	if (user_data.CountryTo != '') {
        if (user_data.CountryTo == "KZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Казахстан';
		}
        if (user_data.CountryTo == "TR") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Турция';
		}
        if (user_data.CountryTo == "AZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Азербайджан';
		}
        if (user_data.CountryTo == "KG") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Кыргызстан';
		}
        if (user_data.CountryTo == "UZ") {
			document.getElementById('RecieverCountry').innerText = 'Куда отправить: Узбекистан';
		}
    }
    if (SummRUB != '') {
        PostRUBval(SummRUB);
    }
    if (Rs != '' && Rn != '') {
        PostReciever(Rn, Rs);
    }
    if (Rf != '') {
        PostNumber(Rf);
    }
    if (surname != '') {
        document.getElementById('surname').value = surname;
    }
    if (name != '') {
        document.getElementById('name').value = name;
    }
    if (birthday != '') {
        document.getElementById('birthday').value = surname;
    }
    if (IDs != '') {
        document.getElementById('id_card_series').value = IDs;
    }
    if (IDn != '') {
        document.getElementById('id_card_number').value = IDn;
    }
    if (code != '') {
        document.getElementById('code').value = code;
    }
    if (date != '') {
        document.getElementById('date_of_issue').value = date;
    }
    if (addr != '') {
        document.getElementById('residence_address').value = addr;
    }

}


/* Validate Fields */
function ValidateNumber(Targ) {
    var value = Targ.value;
    if (!value) {
        value ='0';
    }
    if (!/^(\d+(\.\d{0,2})?)?$/.test(value)) {
        Targ.value = value.slice(0, -1);
    }
    if (parseFloat(value) > 5000) {
        Targ.value = value.slice(0, -1);
    }
    if ((value.match(/\./g) || []).length > 1) {
        Targ.value = value.replace(/\.(?=.*\.)/g, '');
    }
}

function ValidateRecSurname() {
    var targ = document.getElementById('reciever_surname').value;

    user_data.reciever_surname = targ;
}

function ValidateRecName() {
    var targ = document.getElementById('reciever_name').value;

    user_data.reciever_name = targ;
}

function ValidateRecPatrynomic() {
    var targ = document.getElementById('reciever_patrynomic').value;

    user_data.reciever_patrynomic = targ;
}

function ValidateRecPhone() {
    var targ = document.getElementById("reciever_number").value;

    user_data.reciever_phone = targ;
}

function ValidatePromo() {
    var targ = document.getElementById('Promo').value;

    user_data.promo = targ;
}

function ValidateSurname() {
    var targ = document.getElementById('surname').value;

    user_data.surname = targ;
}

function ValidateName() {
    var targ = document.getElementById('name').value;

    user_data.name = targ;
}

function ValidatePatrynomic() {
    var targ = document.getElementById('bithday').value;

    user_data.birthday = targ;
}

function ValidateBirthday() {
    var targ = document.getElementById('birthday').value;

    user_data.birthday = targ;
}

function ValidatePhone() {
    var targ = document.getElementById("number").value;

    user_data.number = targ;
}

function ValidateIDcardSeries() {
    var targ = document.getElementById('id_card_series').value;

    user_data.id_card_series = targ;
}

function ValidateIDcardNumber() {
    var targ = document.getElementById('id_card_number').value;

    user_data.id_card_number = targ;
}

function ValidateCode() {
    var targ = document.getElementById('code').value;

    user_data.code = targ;
}

function ValidateDateOfIssue() {
    var targ = document.getElementById('date_of_issue').value;

    user_data.date_of_issue = targ;
}


/* Transfering important data between pages */
var user_data = {
    'currency' : '',
	'SummUSD' : '',
    'SummRUB' : '',
    'CountryTo' : '',
    'CountryFrom' : 'Russia',
    'reciever_surname' : '',
    'reciever_name' : '',
    'reciever_patrynomic' : '',
    'reciever_phone' : '',
    'promo' : '0',
    'surname' : '',
    'name' : '',
    'number' : '',
    'birthday' : '',
    'id_card_series' : '',
	'id_card_number' : '',
    'code' : '',
    'date_of_issue' : '',
    'residence_address' : '',
}

function SaveData() {
    /* Just prechecking in order not to miss the values */
    var cop = JSON.parse(sessionStorage.getItem('user_data'));
    if (cop === null) {
        sessionStorage.setItem('user_data', JSON.stringify(user_data));
        return;
    }

    for (var key in cop) {
        if (user_data[key] == '' || user_data[key] == '0') {
            user_data[key] = cop[key];
        }
    }

    sessionStorage.setItem('user_data', JSON.stringify(user_data));
}

function UploadData() {
    var cop = JSON.parse(sessionStorage.getItem('user_data'));

    for (var key in cop) {
        if (cop[key] != '' && cop[key] != '0') {
            user_data[key] = cop[key];
        }
    }
}

/* Some Money */
function GetRUB(SummUSD) {
    var SummRUB = SummUSD * user_data.currency;
    
    return SummRUB;
}

function PostRUBval(val) {
    document.getElementById("SummToLab").firstChild.data = val.toLocaleString('ru-RU', {minimumFractionDigits: 2}) + ' RUB';
}

function PostNumber(val) {
    document.getElementById('NumToLab').firstChild.data = 'Номер получателя: +' + val;
}

function PostReciever(name, surname) {
    document.getElementById('RecieverLab').firstChild.data = 'Получатель: ' + surname + ' ' + name;
}

function PostWhere(cont) {
    document.getElementById('WhereLab').firstChild.data = 'Куда отправить: ' + cont;
}

function CalculateMobile(Targ) {
    ValidateNumber(Targ);
    var SummUSD = parseFloat(Targ.value);
    if (!SummUSD) {
        SummUSD = 0;
    }
    var SummRUB = GetRUB(SummUSD);
    user_data.SummUSD = SummUSD;
    user_data.SummRUB = SummRUB;

    PostRUBval(SummRUB);
}
