let nav = new navFunc();

function navFunc () {
    let currentIsShow = false;
    let isStart = false;                        //индикатор того, что модуль можно стартовать
    let queueActions = [];                      //массив выполняемых запросов после того как модель можно стартовать

    function init() {
        try {
            //загружаем данные сессии
            session.checkSession();

            setFixed( true );

            addEvents();
        }
        catch (e) {
            console.log(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            //успешная загрузка данных системы
            $( document ).on( "loadSystemDataSuccess", function() {setStart();} );
            //клик на иконку меню
            $( "#nMIcon" ).on( "click", iconClick );
			$( ".nRightExit" ).on( "click", iconClick );
            //клик на документ
            $( document ).on( "click", docClick );
            //клик на иконку Войти/Выйти
            $( "#nEnterExit" ).on( "click", enterExitClick );
        }
        catch (e) {
            console.log(e);
        }
    }

    //установка стартового индикатора
    function setStart ( newStart = true, isDoActions = true ) {
        try {
            isStart = newStart;

            if ( isStart && isDoActions ) {
                //перебираем действия для запуска
                queueActions.forEach( (elem) => {
                    //Если есть параметры
                    if ( elem.hasOwnProperty("params") ) {
                        elem.func( [...elem.params] );
                    }
                    else {
                        //выполняем функцию
                        elem.func();
                    }
                } );
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на иконку Войти/Выйти
    function enterExitClick( e ) {
        try {
            let isAuth = $(e.currentTarget).attr("data") === "auth";

            if ( isAuth ) {
                window.location.href = "/auth";
            }
            else {
                if ( !isStart ) {
                    queueActions.push( {
                        "func" : enterExitClick,
                        "params" : [e]
                    } );

                    return;
                }

                $.ajax({
                    url : "/apprin/v1/user/log_out/",
                    type : "POST",
                    success : function ( responce ) {
                        console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status === "ok" ) {
                                window.location = "/";
                            }
                        }
                        catch ( err ) {
                            console.log( err );
                        }
                    },
                    error : function ( err ) {
                        console.log( err );
                    }
                });
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на документ
    function docClick( e ) {
        try {
            console.log("doc click");

            if ( !currentIsShow ) {
                return;
            }

            let target = $(e.target);

            console.log(e);
            console.log(target.attr('id'), target.parents("#nMItems").length);

            //Если клик на блок элементов
            if ( target.attr('id') === "nMItems" || target.parents("#nMItems").length === 1 ||
                target.attr('id') === "nMIcon" || target.parents("#nMIcon").length === 1 ) {
                return;
            }

            //показываем/скрываем элементы меню
            showHideItems( !currentIsShow );
        }
        catch (e) {
            console.log(e);
        }
    }

    //клик на иконку меню
    function iconClick( e ) {
        try {
            console.log("icon click");

            //показываем/скрываем элементы меню
            showHideItems( !currentIsShow );
        }
        catch (e) {
            console.log(e);
        }
    }

    //показ/скрытие элементов меню
    function showHideItems( isShow ) {
        try {
            console.log(isShow);

            if ( isShow && !currentIsShow ) {
                $( "#nMItems" ).addClass( "nMItemsShow" );
            }
            else if ( !isShow && currentIsShow ) {
                $( "#nMItems" ).removeClass( "nMItemsShow" );
            }

            currentIsShow = isShow;
        }
        catch (e) {
            console.log(e);
        }
    }

    //показ/скрытие фона меню
    function setNeedBackground( isNeedBackground ) {
        try {
            if ( isNeedBackground ) {
                $( "nav" ).removeClass( "bckgOff" );
            }
            else {
                $( "nav" ).addClass( "bckgOff" );
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    //установка закрепления меню
    function setFixed( isFixed ) {
        try {
            if ( isFixed ) {
                $( "nav" ).removeClass( "navUnfix" );

                $( "body" ).css({
                    "margin-top" : $('nav').outerHeight(true) + "px"
                });
            }
            else {
                $( "nav" ).addClass( "navUnfix" );

                $( "body" ).css({
                    "margin-top" : "0em"
                });
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    return {
        init: function () {
            init();
        },
        setNeedBackground: function ( isNeedBackground = true ) {
            setNeedBackground( isNeedBackground );
        },
        setFixed: function ( isFixed = true ) {
            setFixed( isFixed );
        }
    }
}

$( nav.init );
