let contacts = contactsFunc();

function contactsFunc () {

  function init() {
    try {

    }
    catch (e) {
      console.log(e);
    }
  }

  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию
$( contacts.init );
