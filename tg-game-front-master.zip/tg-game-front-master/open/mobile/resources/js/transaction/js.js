let transactionPage = transactionPageFunc();

function transactionPageFunc () {
  let isShowCountrys = {
    "from" : false,
    "to" : false
  };
  let isSaveNewData = false;
  let step = 1;

  function init() {
    try {
      addEvents();

      //грузим страны
      transactions.loadCountrys();

      //грузим валюты
      transactions.loadCurrencys();

      console.log( user_data );

      if ( !user_data.hasOwnProperty("currency") || user_data.currency === "" ) {
        transactions.loadCurrency();
      }
      else {
        $( ".cFFRTop > span:first-child" ).html( "Курс 1 USD = " + user_data.currency + " RUB" );
      }

      UploadData();

      console.log(user_data);

      //выводим данные которые уже есть
      if ( user_data.hasOwnProperty( "SummUSD" ) ) {
        $("#summ").val(user_data.SummUSD).trigger("input");
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      //клик на кнопку Сохранить
      $( "#cFSave" ).on( "click", saveClick );
      //успешная загрузка данных курса
      $( document ).on( "currencyLoadSuccess", loadCoursData );
      //успешная загрузка данных юзера
      $( document ).on( "loadUserDataSuccess", loadUserData );
      //успешная загрузка данных стран
      $( document ).on( "countryLoadSuccess", buildCountrys );
      //клик на картинку страны или стрелку
      $( "[data-show=\"from\"], [data-show=\"to\"]" ).on( "click", showHideCountrys );
      //обработка клика по документу
      $(document).on("click", documentClick);
      //клик на нкопку назад
      $( ".cFBBack" ).on( "click", backStep );
      //клик на нкопку далее
      $( ".cFBNext" ).on( "click", nextStep );
      //ввод суммы перевода
      $( "#summ" ).on( "input", inputSumm );
      //ввод данных получателя: имя, фамилия
      $( "#toSecondname, #toName" ).on( "input", inputToFIO );
      //ввод данных получателя: телефон
      $( "#toPhone" ).on( "input", inputToTel );
    }
    catch (e) {
      console.log(e);
    }
  }

  //успешная загрузка данных курса
  function loadCoursData( ev ) {
    try {
      user_data[ "currency" ] = transactions.getCurrency();

      SaveData();

      $( ".cFFRTop > span:first-child" ).html( "Курс 1 USD = " + user_data.currency + " RUB" );
    }
    catch (e) {
      console.log(e);
    }
  }

  //ввод данных получателя: имя, фамилия
  function inputToFIO( ev ) {
    try {
      $( ".cFFRTop > span:nth-child(3)" ).html( "Получатель: " + $("#toName").val() + " " + $("#toSecondname").val() );
    }
    catch (e) {
      console.log(e);
    }
  }

  //ввод данных получателя: телефон
  function inputToTel( ev ) {
    try {
      ev.currentTarget.value = ev.currentTarget.value.replace(/[^0-9]/g, '');
	  $( ".cFFRTop > span:nth-child(4)" ).html( "Номер получателя: " + $("#toPhone").val() );
    }
    catch (e) {
      console.log(e);
    }
  }

  //ввод суммы перевода
  function inputSumm( ev ) {
    try {
      let SummUSD = $( ev.currentTarget ).val();
      let cur = user_data.currency;

      console.log( SummUSD );

      if ( SummUSD === "" ) {
        SummUSD = "0";
      }

      if (!/^(\d+(\.\d{0,2})?)?$/.test(SummUSD)) {
        SummUSD = SummUSD.slice(0, -1);
      }

      if (parseFloat(SummUSD) > 5000) {
        SummUSD = SummUSD.slice(0, -1);
      }

      SummUSD = parseFloat( SummUSD );

      console.log( SummUSD );

      if (isNaN(SummUSD)) {
        SummUSD = 0;
      }

      console.log( user_data.currency );

      var SummRUB = SummUSD * user_data.currency;

      user_data.SummUSD = SummUSD;
      user_data.SummRUB = SummRUB;

      $( ev.currentTarget ).val( SummUSD );
      $( ".cFFRBRub" ).html( SummRUB.toLocaleString('ru-RU', {minimumFractionDigits: 2}) + " RUB" );
      $( ".cFFRTop > span:first-child" ).html( "Курс 1 USD = " + cur + " RUB" );
    }
    catch (e) {
      console.log(e);
    }
  }

  //переход к следующему этапу
  function nextStep( ev ) {
    try {
      let newStep = step + 1;

      if ( newStep > 3 ) {
        //сохраняем данные перевода
        saveClick( null );

        return;
      }

      if ( step === 1 ) {
        let fromID = parseInt( $("[data-show=\"from\"][select-id]").attr("select-id") );

        console.log(fromID);

        if ( isNaN(fromID) || fromID <= 0 ) {
          alert("Необходимо выбрать страну, из которой осуществляется перевод");

          return;
        }

        let toID = parseInt( $("[data-show=\"to\"][select-id]").attr("select-id") );

        console.log(toID);

        if ( isNaN(toID) || toID <= 0 ) {
          alert("Необходимо выбрать страну, в которую осуществляется перевод");

          return;
        }

        let summ = parseFloat( $("#summ").val() );

        if ( isNaN(summ) || summ > 5000 || summ <= 0 ) {
          alert( "Необходимо задать сумму перевода" );

          return;
        }
      }

      if ( step === 2 ) {
        if ( $("#toSecondname").val().length <= 2) {
          alert( "Необходимо заполнить поле \"Фамилия получателя\"" );

          return;
        }

        if ( $("#toName").val().length <= 2 ) {
          alert( "Необходимо заполнить поле \"Имя получателя\"" );

          return;
        }

        if ( $("#toPhone").val().length <= 2 ) {
          alert( "Необходимо заполнить поле \"Номер получателя\"" );

          return;
        }
      }

      if ( newStep === 3 ) {
        let success = 0;

        //перебираем ключи юзера
        for ( let key in user_data ) {
          let elem = $( "input#" + key );

          if ( elem.length !== 1 ) {
            continue;
          }

          if ( user_data[key] === "" || key === "promo" || key === "three_name" ) {
            continue;
          }

          console.log( "Успешно " + key );

          elem.val( user_data[key] );
          elem.trigger("input");

          success++;
        }

        console.log("Успешно " + success);

        if ( success !== 8 ) {
          alert( "Перед созданием перевода необходимо ввести все ваши данные!" );

          window.location.href = "/lk";
        }
      }

      //скрываем прошлую форму
      $( "[form-step=\"" + step + "\"]" ).addClass( "formStepHideRight" ).removeClass("formStepShow");
      //показываем новую форму
      $( "[form-step=\"" + newStep + "\"]" ).addClass( "formStepShow" );

      step = newStep;
    }
    catch (e) {
      console.log(e);
    }
  }

  //переход к прошлому этапу
  function backStep( ev ) {
    try {
      let newStep = step - 1;

      if ( newStep <= 0 ) {
        return;
      }

      //скрываем текущую форму
      $( "[form-step=\"" + step + "\"]" ).removeClass( "formStepShow formStepHideRight" );
      //показываем новую форму
      $( "[form-step=\"" + newStep + "\"]" ).addClass( "formStepShow" ).removeClass("formStepHideRight");

      step = newStep;
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик по документу
  function documentClick( ev ) {
    try {
      if ( isShowCountrys.to || isShowCountrys.from ) {
        if ( $(ev.target).closest("[data-show=\"from\"], [data-show=\"to\"]").length === 0 ) {
          if ( isShowCountrys.to ) {
            ev.currentTarget = $( "[data-show=\"to\"]" );

            showHideCountrys( ev );
          }

          if ( isShowCountrys.from ) {
            ev.currentTarget = $( "[data-show=\"from\"]" );

            showHideCountrys( ev );
          }
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //построение стран
  function buildCountrys( ev ) {
    try {
      let countrys = transactions.getCountrys();

      if ( countrys === null ) {
        throw "Страны не получены";
      }

      let elementsFrom = $( '<div></div>' );

      countrys.forEach( item => {
        //Если из страны нельзя делать переводы
        if ( item.availableTransactions.length === 0 ) {
          return true;
        }

        let elem = $('<div>' +
            '<div>' +
            '                                <div>' +
            '                                    <img src="" />' +
            '                                </div>' +
            '                                <div>' +
            '                                    <span class="blackFont largerFontSize"></span>' +
            '                                </div>' +
            '                            </div>' +
            '</div>');

        $( "* img", elem ).attr({
          "src" : "https://" + system.getSystemData().domain + "/resources/img/country/" + item.flag
        });
        $( "* span", elem ).html( item.name );

        $( "> div", elem ).attr({
          "data-id" : item.id
        });

        //добавляем события
        addDelCountyEvents( elem, true );

        elementsFrom.append( elem.contents() );
      } )

      //добавляем страны на страницу
      $( "#countrysFrom" ).append( elementsFrom.contents() );

      //грузим данные юзера
      user.loadUserData();

      $("#countrysFrom > [data-id=\"185\"]").trigger("click");
      $( document ).trigger( "click" );

      if ( user_data.hasOwnProperty( "CountryTo" ) ) {
        let cD = transactions.getCountryBySymbol(user_data.CountryTo);

        if ( cD !== null ) {
          $("#countrysTo > [data-id=\"" + cD.id + "\"]").trigger("click");
          $( document ).trigger( "click" );
        }
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //построение стран (куда отправить перевод)
  function buildCountrysTo( fromCountryID ) {
    try {
      let country = transactions.getCountryByID( fromCountryID );

      //удаляем прошлые значения
      $( "#countrysTo > *" ).remove();

      if ( country === null ) {
        throw "Страны не получены";
      }

      if ( country.availableTransactions.length === 0 ) {
        throw "Переводы из страны невозможны";
      }

      let elementsTo= $( '<div></div>' );

      let toCountrys = transactions.getAvailableTransactionCountrys( fromCountryID );

      //перебираем страны
      for ( toCountry of toCountrys ) {
        let elem = $('<div>' +
            '<div>' +
            '                                <div>' +
            '                                    <img src="" />' +
            '                                </div>' +
            '                                <div>' +
            '                                    <span class="blackFont largFontSize"></span>' +
            '                                </div>' +
            '                            </div>' +
            '</div>');

        $( "* img", elem ).attr({
          "src" : "https://" + system.getSystemData().domain + "/resources/img/country/" + toCountry.flag
        });
        $( "* span", elem ).html( toCountry.name );

        $( "> div", elem ).attr({
          "data-id" : toCountry.id
        });

        //добавляем события
        addDelCountyEvents( elem, true );

        elementsTo.append( elem.contents() );
      }

      //добавляем страны на страницу
      $( "#countrysTo" ).append( elementsTo.contents() );
    }
    catch (e) {
      console.log(e);

      alert(e);
    }
  }

  //добавление/удаление событие со страны
  function addDelCountyEvents( elem, isAdd ) {
    try {
      if ( isAdd === true ) {
        $("> [data-id]", elem ).on( "click", countryClick );                  //клик на страну в списке
      }
      else {
        $( "> [data-id]", elem ).off( "click", countryClick );                  //клик на страну в списке
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на страну в списке
  function countryClick( ev ) {
    try {
      let countryID = parseInt( $(ev.currentTarget).attr("data-id") );
      let countryData = transactions.getCountryByID( countryID );

      if ( countryData === null ) {
        throw "Данных страны " + countryID + " нет";
      }

      let parentShow = $(ev.currentTarget).parents( "[data-show]" );
      let vector = parentShow.attr("data-show");

      //меняем страну на другую
      changeCountry( parentShow, countryData );

      //Если направление Куда
      if ( vector === "to" ) {
        $( ".cFFRTop > span:nth-child(2)" ).html( "Куда отправить: " + countryData.name );
      }
      else {
        //строим доступные страны для перевода
        buildCountrysTo( countryID );
      }

      if ( isShowCountrys[vector] ) {
        //Скрываем страны
        showHideCountrys( ev );
      }
    }
    catch (e) {
      console.log(e);
    }
  }

  //Смена страны
  function changeCountry( parentShow, newCountryData ) {
    try {
      parentShow.attr("select-id", newCountryData.id);


      $( ".cTLFDIImg > img", parentShow ).attr("src", "https://" + system.getSystemData().domain + "/resources/img/country/" + newCountryData.flag);
      $( ".country", parentShow ).html( newCountryData.name );
    }
    catch (e) {
      console.log(e);
    }
  }

  //скрытие|показ стран
  function showHideCountrys( ev ) {
    try {
      let parentShow = $(ev.currentTarget);
      let isShow = parentShow.attr("data-show");

      if ( isShowCountrys[ isShow ] ) {
        $( ".countrys", parentShow ).removeClass( "countrysShow" );
        $( ".cTLFDIArrow", parentShow ).removeClass( "cTLFDIArrowScale" );
      }
      else {
        $( ".countrys", parentShow ).addClass( "countrysShow" );
        $( ".cTLFDIArrow", parentShow ).addClass( "cTLFDIArrowScale" );
      }

      isShowCountrys[ isShow ] = !isShowCountrys[ isShow ];
    }
    catch (e) {
      console.log(e);
    }
  }

  //клик на кнопку Сохранить
  function saveClick( e ) {
    try {
      if ( isSaveNewData ) {
        return;
      }

      isSaveNewData = true;

      let errors = 0;
      let oldUserData = user.getUserData();
      let sendData = {};

      console.log( oldUserData );
      $( ".cForm * input" ).each(function( ) {
        let elem = $( this );

        console.log(elem.attr("id"));

        let elemData = {
          "id" : elem.attr("send-key") !== undefined && elem.attr("send-key") !== null ? elem.attr("send-key") : elem.attr("id"),
          "value" : elem.val()
        };

        if ( elemData.value === undefined || elemData.value === null ||
            elem.attr("id") !== "toOtchestvo" && elem.attr("id") !== "three_name" && elem.attr("id") !== "promo" && elemData.value === "" ) {
          elem.parents( ".cFItem" ).addClass( "cFItemError" );

          errors++;
        }

        sendData[ elemData.id ] = elemData.value;
      });

      //Добавляем данные отправителя
      sendData[ "fromTel" ] = user_data.full_number;

      //Добавляем данные стран
      sendData[ "fromCountryID" ] = parseInt( $("[data-show=\"from\"][select-id]").attr("select-id") );
      sendData[ "toCountryID" ] = parseInt( $("[data-show=\"to\"][select-id]").attr("select-id") );

      //Добавляем курс и валюту
      sendData[ "course" ] = user_data.currency;
      sendData[ "currency" ] = 5;

      if ( errors > 0 ) {
        isSaveNewData = false;

        alert( "Проверьте выделенные поля" );

        return;
      }

      fetch('/apprin/v1/transaction/new/', {
        method: 'POST',
        body: JSON.stringify(sendData)
      })
          .then(response => response.json())
          .then(response => {
            if ( response.status === "ok" ) {
              window.location.href = "/lk";
            }
            else {
              console.log("Ошибка сохранения новых данных: " + response.text);

              alert( "Ошибка сохранения новых данных: " + response.text );
            }
          }).finally(() => isSaveNewData = false);
    }
    catch (e) {
      console.log(e);
    }
  }

  //успешная загрузка данных юзера
  function loadUserData() {
    try {
      let userData = user.getUserData();

      console.log(userData);

      for ( let key in userData ) {
        user_data[ key ] = userData[key];

        //Если гражданство
        if ( key === "citizenship" ) {
          //кликаем на нужную страну
          $( "#countrys > [data-id=\"" + userData[ key ] + "\"]" ).trigger("click");

          //операторы ниже пропускаем
          continue;
        }

        let elem = $( "#" + key );

        console.log( "#" + key );

        if ( elem.length !== 1 ) {
          continue;
        }

        elem.attr("readOnly", true);
        elem.val( userData[key] );
      }

      SaveData();
    }
    catch (e) {
      console.log(e);
    }
  }


  return {
    init: function() {
      init();
    }
  }
}

// запускаем инициализацию
$( transactionPage.init );
