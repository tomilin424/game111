<?php

try {
    //Конфиги системы
    $xmlConf = new xmlConfigs();

    //конфиги системы
    $xmlConf = $xmlConf->getSystemConfigs();

    if (is_null($xmlConf)) {
        throw new Exception("Конфигурация системы не загружена");
    }

    //Если нет файла с api
    if ( !file_exists( CLOSE . "APIv" . $xmlConf["currentApiVersion"] . ".php" ) ) {
        throw new Exception( "Нет класса-обработчика нужной версии API" );
    }

    include_once CLOSE . "APIv" . $xmlConf["currentApiVersion"] . ".php";//подключаем нужный API

    //Места поиска шаблонов
    $environments = [
        [MODULES],
        [MODULES_MODALS, "modals"],
        [MODULES_GAME, "game"],
        [MODULES_MOBILE, "mobile"]
    ];
    //пользовательские константы
    $constants = [];
    //слушатель адресов
    $urlListener = new URLListener();

    //перебираем константы
    foreach (get_defined_constants(true)["user"] as $key => $value) {
        //Если константа это слушатель
        if (get_class($urlListener) == $key) {
            continue;
        }

        //записываем константу
        $constants[$key] = $value;
    }

    //доступные модалки
    $modals = [
        //название модалки => [
        // request => ajax=mod_req - название модалки в запросе
        // path => mod_path - путь до модалки
        //]
        //"request" => "modal_path/modal_name.html"
    ];

    $modalsPath = MODULES . "modals";

    //получаем общие модалки из структуры папок
    $modals = getFolderModals( $modalsPath, "", "@modals/" );

    //записываем модалки в глобальный массив
    $GLOBALS[ "modals" ] = $modals;

    //переменные контекста
    $context = [
        "constants" => $constants,
        "configs" => [
            "system" => $xmlConf
        ],
        "modals" => $modals
    ];
     //конфиги twig-а
    $twig = [
        "environments" => $environments,
        "configs" => [],
        "context" => $context
    ];

    //записываем конфиги twig в глобальный объект
    $GLOBALS[ "twig" ] = $twig;

    //Рутовый адрес API
    $API = $xmlConf["mainApiUrl"];
    //класс-обработчик запросов API
    $apiClass = "APIv" . $xmlConf["currentApiVersion"];


    //обработчики адресов
    $workers = [
        // API для рефоводов
        [
            "path" => $API . "/refovods/removeLink/||" . $API . "/refovods/removeLink",
            "worker" => $apiClass,
            "method" => "RefovodsRemoveLink",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/refovods/getLinks/||" . $API . "/refovods/getLinks",
            "worker" => $apiClass,
            "method" => "RefovodsGetLinks",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/refovods/genLink/||" . $API . "/refovods/genLink",
            "worker" => $apiClass,
            "method" => "RefovodsGenLink",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/refovods/auth/||" . $API . "/refovods/auth",
            "worker" => $apiClass,
            "method" => "RefovodsAuth",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/refovods/exit/||" . $API . "/refovods/exit",
            "worker" => $apiClass,
            "method" => "RefovodsExit",
            "type" => URLListener::TYPE_METHOD
        ],


        // API для работы с предзагрузкой
        [
            "path" => $API . "/preload/get_background/||" . $API . "/preload/get_background",
            "worker" => $apiClass,
            "method" => "PreloadGetBackground",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с настройками
        [
            "path" => $API . "/settings/loadData/||" . $API . "/settings/loadData",
            "worker" => $apiClass,
            "method" => "SettingsLoadData",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/settings/setLang/||" . $API . "/settings/setLang",
            "worker" => $apiClass,
            "method" => "SettingsSetLang",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/settings/setAll/||" . $API . "/settings/setAll",
            "worker" => $apiClass,
            "method" => "SettingsSetAll",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/settings/setAllFirst/||" . $API . "/settings/setAllFirst",
            "worker" => $apiClass,
            "method" => "SettingsSetAllFirst",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с юзером
        [
            "path" => $API . "/user/loadNoPayCryptOrders/||" . $API . "/user/loadNoPayCryptOrders",
            "worker" => $apiClass,
            "method" => "UserLoadNoPayCryptOrders",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/loadNotifOrders/||" . $API . "/user/loadNotifOrders",
            "worker" => $apiClass,
            "method" => "UserLoadNotifOrders",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byLoadAssistents/||" . $API . "/user/byLoadAssistents",
            "worker" => $apiClass,
            "method" => "UserByLoadAssistents",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byLoadItems/||" . $API . "/user/byLoadItems",
            "worker" => $apiClass,
            "method" => "UserByLoadItems",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/by/||" . $API . "/user/by",
            "worker" => $apiClass,
            "method" => "UserBy",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byCheck/||" . $API . "/user/byCheck",
            "worker" => $apiClass,
            "method" => "UserByCheck",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byOrderHash/||" . $API . "/user/byOrderHash",
            "worker" => $apiClass,
            "method" => "UserByOrderHash",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byAssist/||" . $API . "/user/byAssist",
            "worker" => $apiClass,
            "method" => "UserByAssist",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/byCheckAssist/||" . $API . "/user/byCheckAssist",
            "worker" => $apiClass,
            "method" => "UserByCheckAssist",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/time/||" . $API . "/user/time",
            "worker" => $apiClass,
            "method" => "UserNotifActive",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/load_main_data/||" . $API . "/user/load_main_data",
            "worker" => $apiClass,
            "method" => "UserLoadMainData",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/load_referals_data/||" . $API . "/user/load_referals_data",
            "worker" => $apiClass,
            "method" => "UserLoadReferalsData",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/get_available_tasks/||" . $API . "/user/get_available_tasks",
            "worker" => $apiClass,
            "method" => "UserGetAvailableTasks",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/set_end_task/||" . $API . "/user/set_end_task",
            "worker" => $apiClass,
            "method" => "UserSetEndTask",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/get_uuid/||" . $API . "/user/get_uuid",
            "worker" => $apiClass,
            "method" => "UserGetUUID",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/user/move_balance_to_real/||" . $API . "/user/move_balance_to_real",
            "worker" => $apiClass,
            "method" => "UserMoveBalanceToReal",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с Space
        [
            "path" => $API . "/space/load_cards_users/||" . $API . "/space/load_cards_users",
            "worker" => $apiClass,
            "method" => "SpaceCardsUsersLoad",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/space/by_card/||" . $API . "/space/by_card",
            "worker" => $apiClass,
            "method" => "SpaceCardsBy",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с Life
        [
            "path" => $API . "/life/load_cards_users/||" . $API . "/life/load_cards_users",
            "worker" => $apiClass,
            "method" => "LifeCardsFromByLoad",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/life/by_card/||" . $API . "/life/by_card",
            "worker" => $apiClass,
            "method" => "LifeCardBy",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/life/load_cards/||" . $API . "/life/load_cards",
            "worker" => $apiClass,
            "method" => "LifeCardsLoad",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с ежедневным квиз-ом
        [
            "path" => $API . "/quiz/byCheck/||" . $API . "/quiz/byCheck",
            "worker" => $apiClass,
            "method" => "QuizByCheck",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/by/||" . $API . "/quiz/by",
            "worker" => $apiClass,
            "method" => "QuizByStart",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/load_daily/||" . $API . "/quiz/load_daily",
            "worker" => $apiClass,
            "method" => "QuizLoadDaily",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/start_daily/||" . $API . "/quiz/start_daily",
            "worker" => $apiClass,
            "method" => "QuizStartDaily",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/end_daily/||" . $API . "/quiz/end_daily",
            "worker" => $apiClass,
            "method" => "QuizEndDaily",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/check_daily/||" . $API . "/quiz/check_daily",
            "worker" => $apiClass,
            "method" => "QuizCheckDaily",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/start_answer/||" . $API . "/quiz/start_answer",
            "worker" => $apiClass,
            "method" => "QuizSetStartAnswerDaily",
            "type" => URLListener::TYPE_METHOD
        ],
        [
            "path" => $API . "/quiz/change_quest/||" . $API . "/quiz/change_quest",
            "worker" => $apiClass,
            "method" => "QuizChangeQuestDaily",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с рейтингом
        [
            "path" => $API . "/rating/load_data/||" . $API . "/rating/load_data",
            "worker" => $apiClass,
            "method" => "RatingLoadData",
            "type" => URLListener::TYPE_METHOD
        ],

        // API для работы с рефералами
        [
            "path" => $API . "/friends/load_referals_pay_data/||" . $API . "/friends/load_referals_pay_data",
            "worker" => $apiClass,
            "method" => "FriendsLoadReferalsPayData",
            "type" => URLListener::TYPE_METHOD
        ],

        // Запросы модалок
        [
            "path" => $API . "/modal/.*||" . $API . "/modal.*",
            "worker" => $apiClass,
            "method" => "GetModal",
            "type" => URLListener::TYPE_METHOD
        ]
    ];

    //если ошибка при добавлении обработчиков в слушатель
    if ( !$urlListener->addListeners( $workers ) ) {
        echo "ошибка";

        exit(1);
    }
}
catch ( Exception $err ) {
    echo json_encode([
        "status" => "error",
        "text" => $err->getMessage()
    ]);
}