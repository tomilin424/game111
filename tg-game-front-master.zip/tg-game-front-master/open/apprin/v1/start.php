<?php

require_once "../../../close/constants.php";                //константы
require_once CLOSE . "URLListener.php";              //подключаем класс по работе с роутингом
require_once WWW . "vendor/autoload.php";                   //загружаем библиотеки
include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "modals.php";                                      //функции для работы с модалками

//запрашиваемый адрес
$path = $_SERVER[ "REQUEST_URI" ];

//слушатель адресов
$urlListener = new URLListener([
    "cache" => ROOT . "temp"
]);

//ТУТ добавление адресов роутинга, определение модели
include_once "start_listeners.php";

//обрабатываем запрашиваемый путь
$urlListener->workPath( $path );
