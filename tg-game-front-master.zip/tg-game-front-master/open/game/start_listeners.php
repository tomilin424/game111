<?php

try {
    //Конфиги системы
    $allConf = new xmlConfigs();

    //конфиги системы
    $xmlConf = $allConf->getSystemConfigs();

    if (is_null($xmlConf)) {
        throw new Exception("Конфигурация системы не загружена");
    }

    //Информация о системе
    $systemInfo = $allConf->getInformationConfigs();

    if ( is_null($systemInfo) ) {
        throw new Exception("Не получена информация о системе");
    }

    //Места поиска шаблонов
    $environments = [
        [MODULES],
        [MODULES_GAME, "game"],
        [MODULES_MOBILE, "mobile"]
    ];
    //пользовательские константы
    $constants = [];
    //слушатель адресов
    $urlListener = new URLListener();

    //перебираем константы
    foreach (get_defined_constants(true)["user"] as $key => $value) {
        //Если константа это слушатель
        if (get_class($urlListener) == $key) {
            continue;
        }

        //записываем константу
        $constants[$key] = $value;
    }

    // Элемент для работы с юзерами
    $users = new users();

    //uuid
    $uuid = isset($_GET[ "id" ]) ? $_GET[ "id" ] : null;

    // кука с хэшем
    $hashCookie = isset( $_COOKIE[ "hash" ] ) ? $_COOKIE[ "hash" ] : null;

    //доступные модалки (можно добавить вручную, плюс модалки автоматически подгружаются)
    $modals = [
        //название модалки => [
        // request => ajax=mod_req - название модалки в запросе
        // path => mod_path - путь до модалки
        //]
        //"request" => "modal_path/modal_name.html"
    ];

    $modalsPath = MODULES . "modals";

    //получаем общие модалки из структуры папок
    $modals = getFolderModals( $modalsPath, "", "@modals/" );

    //записываем модалки в глобальный массив
    $GLOBALS[ "modals" ] = $modals;

    //конфигурация чисто для web-а
    $webConfigs = [
        "version" => $systemInfo["version"],
    ];

    //переменные контекста
    $context = [
        "constants" => $constants,
        "configs" => [
            "system" => $xmlConf,
            "information" => $systemInfo,
            "web" => $webConfigs
        ],
        "modals" => $modals,
        "userObjects" => [],
        "isStart" => isset( $_GET[ "is" ] ) && $_GET[ "is" ] == "1"
    ];

    session_start();

    // Если в сессии нет индикатора того, что игра была запущена И есть UUID юзера
    if ( (!isset( $_SESSION[ "isStart" ] ) || !$_SESSION[ "isStart" ]) && !is_null($uuid) ) {
        // Если успешно поставили индикатор запуска игры
        if ( $users->setStartGame( $uuid, $db, false ) == true ) {
            // Ставим индикатор запуска игры
            $_SESSION[ "isStart" ] = true;
        }
    }

    session_write_close();
    session_commit();


    class Resources {
        private $resourcesPath = RESOURCES;
        private $items = [
            "start" => [],              // картинки при загрузке подгружаемые
            "all" => []                 // все картинки для предзагрузки в фоне
        ];

        // Функция для получения всех ресурсов для предзагрузки
        public function getResources ( $key = "start" ) {
            $this->getItems( $this->resourcesPath );

            return $this->items[ $key ];
        }

        private function getItems ( $dir ) {
            // Перебираем папку
            foreach( scandir( $dir ) as $key => $value ) {
                $path = realpath($dir . DIRECTORY_SEPARATOR . $value );

                if ( !is_dir( $path ) ) {
                    $urlPath = "/resources/" . substr( $path, strlen( $this->resourcesPath ) );
                    $imgKey = "all";

                    // Если картинка
                    if ( stripos( $value, ".svg" ) !== false || stripos( $value, ".png" ) !== false ||
                        stripos( $value, ".jpg" ) !== false || stripos( $value, ".gif" ) !== false ) {

                        $tag = '<img src="' . $urlPath . '" />';

                        // Если картинка для старта
                        if ( strpos( $urlPath, "leagues" ) !== false ) {
                            $imgKey = "start";
                        }
                        else {
                            $imgKey = "all";
                        }
                    }
                    else {
                        continue;
                    }

                    if ( !is_null( $tag ) ) {
                        $this->items[ $imgKey ][] = $tag;
                    }
                }
                else if ( $value != "." && $value != ".." ) {
                    $this->getItems( $path );
                }
            }
        }
    }

    $resItem = new Resources();

    $lang = new lang();
    $userData = $users->getMainData( $uuid, $db, false );

    if ( $userData[ "status" ] == "ok" ) {
        $userData = $userData[ "data" ];
    }

    $char = $users->getLangChar( $uuid, $db, false );

    // Добавляем язык в данные пользователя
    $userData[ "char" ] = $char;

    // Добавляем объект для работы с ресурсами фронта (подгрузка)
    $context[ "userObjects" ][ "resources" ] = $resItem;
    $context[ "userObjects" ][ "userData" ] = $userData;
    $context[ "lang" ] = $lang;
    $context[ "db" ] = $db;

    //конфиги twig-а
    $twig = [
        "environments" => $environments,
        "configs" => [],
        "context" => $context,
        "functions" => []
    ];

    //обработчики адресов
    $workers = [
        // Рефоводы
        [
            "path" => "/ref_adm||/ref_adm/",
            "worker" => "@game/pages/refovods/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/ref_adm/auth||/ref_adm/auth/",
            "worker" => "@game/pages/refovods/auth.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],

        // Игра
        [
            "path" => "/||/?id=.*",
            "worker" => "@game/pages/main/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/earn||/earn/?id=.*",
            "worker" => "@game/pages/earn/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/friends||/friends/?id=.*",
            "worker" => "@game/pages/friends/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/tasks||/tasks/?id=.*",
            "worker" => "@game/pages/tasks/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/shop||/shop/?id=.*",
            "worker" => "@game/pages/shop/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/rating||/rating/?id=.*",
            "worker" => "@game/pages/rating/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/settings||/settings/?id=.*",
            "worker" => "@game/pages/settings/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/life||/life/?id=.*",
            "worker" => "@game/pages/life/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],
        [
            "path" => "/space||/space/?id=.*",
            "worker" => "@game/pages/space/main.html",
            "type" => URLListener::TYPE_PAGE,
            "twig" => $twig
        ],



        [
            "path" => "/ntcn/||/ntcn",
            "worker" => OPEN . "pc/ntcn.php",
            "type" => URLListener::TYPE_PAGE
        ]
    ];

    //если ошибка при добавлении обработчиков в слушатель
    if ( !$urlListener->addListeners( $workers ) ) {
        echo "ошибка";

        exit(1);
    }
}
catch ( Exception $err ) {
    echo json_encode([
        "status" => "error",
        "text" => $err->getMessage()
    ]);
}
