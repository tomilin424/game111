<?php

require_once "../../close/constants.php";                   //константы
require_once CLOSE . "URLListener.php";                     //подключаем класс по работе с роутингом
require_once WWW . "vendor/autoload.php";                   //загружаем библиотеки
include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "modals.php";                          //функции для работы с модалками
include_once CLOSE . "lang.php";                           //функции для работы с языком
include_once CLOSE . "db.php";                           //функции для работы с базой
include_once CLOSE . "users.php";                           //функции для работы с юзерами


//запрашиваемый адрес
$path = $_SERVER[ "REQUEST_URI" ];

//слушатель адресов
$urlListener = new URLListener([
    "cache" => ROOT . "temp"
]);

$db = null;

try {
    $db = new db();

    if ($db->connect() !== true) {
        throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
    }

    //ТУТ добавление адресов роутинга, определение модели
    include_once "start_listeners.php";

    //обрабатываем запрашиваемый путь
    $urlListener->workPath( $path );
}
catch ( Exception $err ) {
    echo json_encode([
        "status" => "error",
        "text" => $err->getMessage()
    ]);
}
finally {
    if (!is_null($db)) {
        if ($db != null) try {
            $db->close();
        } catch (Exception $e) {
        }
    }
}
