<?php

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once "../../close/constants.php";                //константы
require_once CLOSE . "actions.php";
require_once WWW . "vendor/autoload.php";                   //загружаем библиотеки

echo "ntcn";

actions::addActionFromDirectRequest(1, 1, ["data" => 454]);