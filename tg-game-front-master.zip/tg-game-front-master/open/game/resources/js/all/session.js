let session = new sessionFunc();

function sessionFunc () {
    let sessionData = null;                        //данные сессии
    let isStart = false;                        //индикатор того, что модуль можно стартовать

    function init () {
        try {
            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событий
    function addEvents () {
        try {
        }
        catch (e) {
            console.error(e);
        }
    }

    // загрузка данных сессии
    function checkSession() {
        try {
            // console.log("начинаем");

            let appData = window.Telegram.WebApp;

            // console.log( appData );

            /*$.ajax({
                url : "/apprin/v1/user/check_session/",
                type : "POST",
                success : function ( responce ) {
                    console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status === "ok" && resp.isActiveSession ) {
                            changeElemData ();

                            $( document ).trigger( "checkSessionValid" );

                        }
                        else {
                            changeElemData ( false );

                            $( document ).trigger( "checkSessionInvalid" );
                        }

                        delete resp.status;

                        sessionData = resp;
                    }
                    catch ( err ) {
                        console.error(err);

                        $( document ).trigger( "checkSessionInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "checkSessionEnd" );
                }
            });*/
        }
        catch (e) {
            console.error(e);
        }
    }

    // получение данных сессии
    function getSession() {
        try {
            return sessionData;
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    // авторизация
    function auth( number, authType, authData, isRedirect ) {
        try {
            $.ajax({
                url : "/apprin/v1/auth/do/",
                type : "POST",
                data : JSON.stringify({'Full_Number' : number,
                    'authType' : authType, 'authData' : authData}),
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            throw "Ошибка " + resp.text;
                        }

                        if ( isRedirect ) {
                            window.location.href = "/";
                        }

                        $( document ).trigger( "authSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);

                        $( document ).trigger( "authError", [{"error" : err}] );
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    $( document ).trigger( "authError", [{"error" : err}] );
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "authEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function () {
            init();
        },
        checkSession: function () {
            checkSession();
        },
        getSession: function () {
            return getSession();
        },
        auth: function ( number, authType = 1, authData = null, isRedirect = true ) {
            auth( number, authType, authData, isRedirect );
        }
    }
}

$( window ).on( "load", session.init );
