let lang = new langPage();

function langPage () {

    function init ( ) {
        try {
            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событий
    function addEvents () {
        try {

        }
        catch (e) {
            console.error(e);
        }
    }


    // получение текста по ключу
    function getText( key = null ) {
        try {
            // console.log( "Весь текст", loadText, key, loadText[ key ] );

            const text = loadText.hasOwnProperty( key ) ? loadText[ key ] : null;

            if (text) {
                return text.replaceAll('&lt;', '<').replaceAll('&gt;', '>');
            }
        }
        catch (e) {
            console.error(e);
        }

        return null;
    }

    return {
        init: function () {
            init();
        },

        getText: function ( key = null ) {
            return getText( key );
        }
    }
}

$( window ).on( "load", lang.init );
