let modal = new modalFunc();


function modalFunc () {
    let modalDataDefault = {
        "parent" : null,
        "modalData" : null,
        "ajax" : null,
        "configs" : null
    };                                    //дефолтные данные окна
    let modalData = {
        "parent" : null,
        "modalData" : null,
        "ajax" : null,
        "configs" : null
    };                                    //данные окна

    function init() {
        try {

        }
        catch (e) {
            console.error(e);
        }
    }

    // показ окна
    function showModal ( _parent = $("body"), _modalData = "", _ajax = null, _configs = {} ) {
        try {
            _parent = _parent === null || _parent === undefined ? $( "body" ) : _parent;

            modalData.parent = _parent;
            modalData.modalData = _modalData;
            modalData.ajax = _ajax;
            modalData.configs = _configs;

            //Если не задан ajax
            if ( modalData.ajax === null || modalData.ajax === undefined ) {
                return;
            }

            //элемент с данными запрашиваемой модалки
            let modalMetaElement = $( "meta[name=\"modal|" + modalData.ajax.modal + "\"]" );

            if ( modalMetaElement.length !== 1 ) {
                throw "Модального окна нет";
            }

            //переписываем параметры
            modalData.ajax[ "url" ] = "/apprin/v1/modal?ajax=" + modalData.ajax.modal + "&request=" + modalMetaElement.attr("request");
            modalData.ajax[ "type" ] = "GET";
            modalData.ajax[ "dataType" ] = "json";

            //переписываем методы
            modalData.ajax[ "success" ] = function ( responce ) {
                // console.log( responce );

                try {
                    let resp = responce;

                    if ( resp.status === "ok" ) {
                        let htmlData = $( resp.data );

                        //Если задавался контент, то пишем его
                        $( ".modalContent", htmlData ).append( modalData.modalData );

                        //Если заданы конфиги
                        if ( Object.keys(modalData.configs).length > 0 ) {
                            //Если заданы конфиги кнопки ОК
                            if ( modalData.configs.hasOwnProperty( "ok" ) ) {
                                //Если задана надпись
                                if ( modalData.configs.ok.hasOwnProperty("label") ) {
                                    $( ".btnOk > span", htmlData ).html( modalData.configs.ok.label );
                                }
                            }
                        }

                        modalData.modalData = htmlData;

                        //создаём в родителе модалку
                        $( modalData.parent ).append( modalData.modalData );

                        $( document ).trigger( "modalBuild" );

                        //навешиваем события
                        addDelEvents();

                        //показываем модалку
                        $( ".modal", modalData.parent ).addClass( "modalShow" );

                        $( document ).trigger( "modalShow" );
                    }
                    else {
                        throw resp.text;
                    }
                }
                catch ( err ) {
                    console.error(err);

                    alert(err);
                }
            };

            modalData.ajax[ "error" ] = function ( err ) {
                console.error(err);
            };

            //выполняем запрос
            $.ajax( modalData.ajax );
        }
        catch (e) {
            console.error(e);
        }
    }

    // закрытие окна
    function closeModal() {
        try {
            $( ".modalShow", modalData.parent ).removeClass( "modalShow" );

            setTimeout(function() {
                $( ".modal", modalData.parent ).remove();

                //сбрасываем данные модалки
                modalData = $.extend( true, {}, modalDataDefault );

                $( document ).trigger( "modalClose" );
            }, 300);
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление/удаление событий
    function addDelEvents ( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".btnOk", modalData.parent ).on( "click", okClick );                                            //клик на кнопку OK
                $( ".btnClose, .cross, .modal > :first-child", modalData.parent ).on( "click", closeModal );       //клик на кнопку, крестик, фон
            }
            else {
                $( ".btnOk", modalData.parent ).off( "click", okClick );                                            //клик на кнопку OK
                $( ".btnClose, .cross, .modal > :first-child", modalData.parent ).off( "click", closeModal );       //клик на кнопку, крестик, фон
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    //клик на ОК
    function okClick ( e ) {
        try {
            //Если заданы конфиги кнопки ОК
            if ( modalData.configs.hasOwnProperty( "ok" ) ) {
                //Если задана функция для обратного вызова
                if ( modalData.configs.ok.hasOwnProperty("callback") ) {
                    modalData.configs.ok.callback( e );
                }
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    return {
        init: function () {
            init();
        },
        showModal: function ( parent = $("body"), modalData = "", ajax = null, configs = {} ) {
            showModal( parent, modalData, ajax, configs );
        },
        closeModal: function () {
            closeModal();
        }
    }
}

$( window ).on( "load", modal.init );
