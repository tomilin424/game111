/*
*
* КЛАСС ДЛЯ РАБОТЫ С ОЧЕРЕДЬЮ НА ЗАПУСК
*
* */

function queueFunc () {
    //индикатор загрузки всех нужных данных перед началом работы
    let startIndicator = 0;

    let needStartIndicator = 0;
    let queueActions = [];                      //массив выполняемых запросов после того как модель можно стартовать

    this.setNeedStartIndicator = function ( newVal ) {
        needStartIndicator = newVal;
    }
    this.getNeedStartIndicator = function ( ) {
        return needStartIndicator;
    }

    this.setQueueAction = function ( newVal ) {
        queueActions = newVal;
    }

    //запуск функций из очереди
    this.startQueue = function () {
        try {
            startIndicator++;

            if ( startIndicator !== needStartIndicator ) {
                return;
            }

            //перебираем действия для запуска
            queueActions.forEach( (elem) => {
                //Если не заданы параметры
                if ( elem[1] === null || elem[1].length === 0 ) {
                    //выполняем функцию
                    elem[0]();
                }
                else {
                    //выполняем функцию с параметрами
                    elem[0]( ...elem[1] );
                }
            } );
        }
        catch ( e ) {
            console.error(e);
        }
    }
}
