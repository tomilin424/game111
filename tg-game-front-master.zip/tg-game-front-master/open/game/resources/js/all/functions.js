/*
*
* ОБЩИЕ ФУНКЦИИ
*
* */

// Перевод строки в hex
function strToHex ( input ) {
    let hex, i;

    let result = "";

    for ( i = 0; i < input.length; i++ ) {
        hex = input.charCodeAt( i ).toString( 16 );

        result += ( "000" + hex ).slice( -4 );
    }

    return result
}

// Получить индекс элемента в массиве по ключу
function getItemIndexByKeyValue ( array, key, value ) {
    let index = -1;

    for ( let item of array ) {
        index++;

        if ( !item.hasOwnProperty( key ) ) {
            continue;
        }

        if ( item[ key ] === value ) {
            return index;
        }
    }

    return null;
}

// Получить элемент в массиве по ключу
function getItemByKeyValue ( array, key, value ) {
    for ( let item of array ) {
        if ( !item.hasOwnProperty( key ) ) {
            continue;
        }

        if ( item[ key ] === value ) {
            return item;
        }
    }

    return null;
}

// Получить значение объекта по пути
function getPathValue (obj, path) {
    var r = path.split(".");

    if ( path ) {
        return getPathValue( obj[r.shift()], r.join(".") );
    }

    return obj
}

// Разбивка числа на разряды через разделитель
function formatNumber (input, number = 3, delimiter = " ") {
    let reg = new RegExp( "(\\d)(?=(\\d{" + number + "})+(?!\\d))", "g" );

    return input.toString().replace(reg, '$1' + delimiter)
}

// Парсинг массива и вывод инфы в нужные блоки на странице
function parseArrayToElementData ( array ) {
    try {
        for ( let key in array ) {
            let elem = $( "[data-input-key=\"" + key + "\"]" );

            if ( elem.length === 0 ) {
                // console.log( "нет элемента", key );

                continue;
            }

            let value = array[ key ];

            // Если стоит параметр форматирования числа
            if ( elem.attr( "data-input-format" ) === "number" ) {
                let number = elem.attr( "data-input-format-number" ) !== undefined ? parseInt( elem.attr( "data-input-format-number" ) ) : 3;
                let delimiter = elem.attr( "data-input-format-delimiter" ) !== undefined ? elem.attr( "data-input-format-delimiter" ) : " ";

                value = formatNumber( value, number, delimiter );
            }

            // Если стоит символ перед текстом
            if ( elem.attr( "data-input-before" ) ) {
                value = elem.attr( "data-input-before" ) + value;
            }

            // Выводим значение
            elem.html( value );
        }

        return true;
    }
    catch ( e ) {
        console.error( e );

        return false;
    }
}