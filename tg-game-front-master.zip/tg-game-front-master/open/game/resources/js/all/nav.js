let nav = new navFunc();

function navFunc() {
  let currentIsShow = false;
  let isStart = false;                        //индикатор того, что модуль можно стартовать
  let queueActions = [];                      //массив выполняемых запросов после того как модель можно стартовать

  function init() {
    try {
      addEvents();
    }
    catch (e) {
      console.error(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      $(document).on("userMainDataStorageSuccess userMainDataLoadSuccess", build);                   // загрузка основной информации о юзере
    }
    catch (e) {
      console.error(e);
    }
  }

  // Построение меню
  function build() {
    try {
      // Перебираем ссылки
      $("#nContent > a").each(function () {
        $(this).attr({
          "href": $(this).attr("nav-src") + "/?id=" + user.getAllUserData().uuid + "&is=1",
          "prepared": "1"
        });

        $(this).on("click", menuClick);
      });
    }
    catch (e) {
      console.error(e);
    }
  }

  // Клик на пункт меню
  function menuClick(e) {
    try {
      // Если элемент не обработан
      if ($(e.currentTarget).attr("prepared") !== "1") {
        e.stopPropagation();
        e.preventDefault();
      }

      e.stopPropagation();
      e.preventDefault();

      let clickHref = $(e.currentTarget).attr("href").split("/")[1].split("#")[0].split("?")[0];
      let currentHref = window.location.href.split("/")[3].split("#")[0].split("?")[0];
      let itemFrame = $(e.currentTarget).attr("nav-item");

      // console.log( clickHref, currentHref );

      // Если текущая страница равна нажатой
      if (clickHref === currentHref) {
        e.stopPropagation();
        e.preventDefault();
      }

      tg.BackButton.hide();

      $(".page-content").removeClass("show")

      if (itemFrame !== "main") {
        $("#content.main-page").hide()
        $(`.page-content#${itemFrame}_page`).addClass("show")

        window?.pageOpen?.[itemFrame]?.();
      } else {
        $("#content.main-page").show()
      }

      // выделяем новый пункт меню
      selectMenuItem(itemFrame);
    }
    catch (e) {
      console.error(e);
    }
  }

  // выделение пункта меню
  function selectMenuItem(menuItem = "") {
    try {
      // снимаем выделение со всех пунктов, кроме нашего
      $("[nav-item]:not( [nav-item=\"" + menuItem + "\"] )").removeAttr("nav-item-select");

      // выделяем нужный пункт
      $("[nav-item=\"" + menuItem + "\"]").attr("nav-item-select", "1");
    }
    catch (e) {
      console.error(e);
    }
  }

  return {
    init: function () {
      init();
    }, selectMenuItem: function (menuItem = "") {
      selectMenuItem(menuItem);
    }
  }
}

$(window).on("load", nav.init);
