let system = new systemFunc();
let tg = null;

function systemFunc () {
    let lifeCardsStorageKey = "lifeCards";
    let spaceCardsStorageKey = "spaceCards";
    let referalsPayStorageKey = "referalsPay";
    let ratingStorageKey = "rating";
    let settingsStorageKey = "settings";


    function init() {
        try {
            tg = window.Telegram.WebApp;

            tg.BackButton.isVisible = false;
            tg.BackButton.hide();

            $( document ).trigger( "tgReady" );

            addEvents();

            tg.ready();

            tgStart();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", userLoadSuccess );
            // успешное чтение данных из хранилища или запросом на сервер
        }
        catch (e) {
            console.error(e);
        }
    }

    // Запуск настройки ТГ игры
    function tgStart () {
        try {
            tg.expand();
        }
        catch (e) {
            console.error(e);
        }
    }

    // успешное чтение данных из хранилища или запросом на сервер
    function userLoadSuccess ( e ) {
        try {
            // console.log(e);

            // Грузим данные настроек
            loadSettings();

            // Грузим данные Life карточек
            loadLifeCardsForLastBy();

            // Грузим данные Space карточек
            loadSpaceCards();

            // Грузим данные вознаграждения рефералов
            loadReferalsPayData();

            // Грузим данные рейтинга
            // loadRating();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка данных карточек (Life) с последней купленной
    function loadLifeCardsForLastBy ( ) {
        try {
            // Грузим данные
            $.ajax({
                url : "/apprin/v1/life/load_cards_users/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( lifeCardsStorageKey, JSON.stringify({
                            "cards" : resp.data.data.data,
                            "allCards" : resp.data.maxCards,
                            "byCards" : resp.data.byCards,
                            "maxPage" : resp.data.maxPage,
                            "newPage" : resp.data.page
                        }) );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка карточек Space
    function loadSpaceCards ( ) {
        try {
            // Грузим данные
            $.ajax({
                url : "/apprin/v1/space/load_cards_users/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( spaceCardsStorageKey, JSON.stringify({
                            "cards" : resp.data.cards,
                            "byCards" : resp.data.byCards,
                            "refCounts" : resp.data.refCounts
                        }) );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка данных о вознаграждениях за рефералов
    function loadReferalsPayData ( ) {
        try {
            // Грузим данные рефералов
            $.ajax({
                url : "/apprin/v1/friends/load_referals_pay_data/",
                data : "",
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( referalsPayStorageKey, JSON.stringify(resp.data) );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    // Загрузка данных рейтинга
    function loadRating( ) {
        try {
            $.ajax({
                url : "/apprin/v1/rating/load_data/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( ratingStorageKey, JSON.stringify({
                            "ratingData" : resp.data.items,
                            "userRating" : resp.data.userRating
                        }) );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка данных настроек
    function loadSettings( ) {
        try {
            // Загружаем
            $.ajax({
                url : "/apprin/v1/settings/loadData/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( settingsStorageKey, JSON.stringify( resp.data ) )

                        $( document ).trigger( "settingsLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }
    // Установка данных настроек
    function setSettings( key, value ) {
        try {
            let currSettings = JSON.parse( localStorage.getItem( settingsStorageKey ) );

            currSettings[ key ] = value;

            localStorage.setItem( settingsStorageKey, JSON.stringify( currSettings ) );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Установка данных настроек
    function clearCache() {
        try {
            localStorage.removeItem(lifeCardsStorageKey);
            localStorage.removeItem(spaceCardsStorageKey);
            localStorage.removeItem(referalsPayStorageKey);
            localStorage.removeItem(ratingStorageKey);
            localStorage.removeItem(settingsStorageKey);
        }
        catch (e) {
            console.error(e);
        }
    }

    return {
        init: function () {
            init();
        },
        loadLifeCardsForLastBy: function () {
            loadLifeCardsForLastBy();
        },
        loadSpaceCards: function () {
            loadSpaceCards();
        },
        loadRating: function () {
            loadRating();
        },
        loadSettings: function () {
            loadSettings();
        },
        setSettings: function ( key, value ) {
            setSettings( key, value );
        },
        clearCache: function (  ) {
            clearCache(  );
        }
    }
}

$( window ).on( "load", system.init );
