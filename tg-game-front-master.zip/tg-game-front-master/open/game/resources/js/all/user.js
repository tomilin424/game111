let user = new userFunc();

function userFunc () {
    let userData = {};                        //данные юзера
    let isStart = false;                        //индикатор того, что модуль можно стартовать
    let queueActions = [];                      //массив выполняемых запросов после того как модель можно стартовать
    let referalsData = [];                      //загруженные данные рефералов последней переданной страницы
    let referralsCount = 0;                      //загруженные данные рефералов последней переданной страницы
    let tasksData = [];                      //загруженные данные доступных задач

    let timerNotifActive = null;                // Таймер оповещения о том, что юзер активен
    let timeNotifActive = 3.5;                  // Время рассылки оповещения в минутах

    let storageKey = "userData";
    let storageReferalsKey = "refelas";
    let storageReferralsCountKey = "refelas_count";

    function init ( ) {
        try {
            addEvents();

            let initData = decodeURI( tg.initData ).split( "&" );

            tg.isClosingConfirmationEnabled = true;

            for ( let pair of initData ) {
                let pairArr = pair.split( "=" );
                let key = pairArr[ 0 ];
                let value = pairArr[ 1 ];

                if ( key === "user" ) {
                    value = JSON.parse( decodeURIComponent(value) );
                }

                userData[ key ] = value;
            }

            if ( userData.hasOwnProperty( "user" ) && userData.user.hasOwnProperty( "id" ) ) {
                userData[ "user_id" ] = userData.user.id;
            }

            let params = new URLSearchParams( document.location.search );

            let uuid = params.get( "id" );

            // Если есть данные в хранилище
            if ( localStorage.getItem( storageKey ) !== undefined && localStorage.getItem( storageKey ) !== null ) {
                userData[ "uuid" ] = JSON.parse( localStorage.getItem( storageKey ) ).uuid;
                userData[ "mainData" ] = JSON.parse( localStorage.getItem( storageKey ) ).mainData;

                localStorage.setItem( storageKey, JSON.stringify(userData) );

                // console.log( userData, "триггерим хранилище" );

                // TODO: check or delete comment #8
                // $( document ).trigger( "userMainDataStorageSuccess" );
            }
            else {
                localStorage.setItem( storageKey, JSON.stringify(userData) );
            }

            if ( uuid === null || uuid === undefined ) {
                // Получается UUID
                $.ajax({
                    url : "/apprin/v1/user/get_uuid/",
                    data : "user_id=" + userData.user_id,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( 'responce', responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            // Записываем UUID
                            userData[ "uuid" ] = resp.data;

                            localStorage.setItem( storageKey, JSON.stringify(userData) );

                            // Грузим основные данные юзера
                            //loadMainData();

                            // Перезапускаем страницу
                            window.location.href = "/?id=" + userData.uuid;
                        }
                        catch ( err ) {
                            console.error( err );
                        }
                    },
                    error : function ( err ) {
                        console.error( err );
                    },
                    complete : function () {

                    }
                });
            }
            else {
                // Записываем UUID
                userData[ "uuid" ] = uuid;

                // Грузим основные данные юзера
                loadMainData();
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка основных данных юзера
    function loadMainData () {
        try {
            // Запускаем оповещение о активности в игре
            startNotifActive();

            // Грузим основные данные юзера
            $.ajax({
                url : "/apprin/v1/user/load_main_data/",
                data : "id=" + userData.uuid + "&user_id=" + userData.user_id,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            $( document ).trigger( "userMainDataLoadInvalid" );

                            return;
                        }

                        //let isTrigger = !userData.hasOwnProperty( "mainData" );

                        userData[ "mainData" ] = resp.data;

                        localStorage.setItem( storageKey, JSON.stringify(userData) );

                        /*if ( isTrigger ) */$( document ).trigger( "userMainDataLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error( err );

                        $( document ).trigger( "userMainDataLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "userMainDataLoadEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событий
    function addEvents () {
        try {

        }
        catch (e) {
            console.error(e);
        }
    }


    // Запуск оповещения о активности в игре
    function startNotifActive () {
        try {
            clearNotifActiveTimer();

            timerNotifActive = setTimeout( continueNotifActive , timeNotifActive * 60 * 1000 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка таймера оповещения о активности в игре
    function clearNotifActiveTimer () {
        try {
            if ( timerNotifActive !== null ) {
                clearTimeout( timerNotifActive );

                timerNotifActive = null;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение оповещения о активности в игре
    function continueNotifActive () {
        try {
            clearNotifActiveTimer();

            // Грузим основные данные юзера
            $.ajax({
                url : "/apprin/v1/user/time/",
                data : "id=" + userData.uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            $( document ).trigger( "userMainDataLoadInvalid" );

                            return;
                        }

                        timerNotifActive = setTimeout( continueNotifActive , timeNotifActive * 60 * 1000 );
                    }
                    catch ( err ) {
                        console.error( err );

                        $( document ).trigger( "userMainDataLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }


    // Загрузка данных доступных задач юзера
    function loadAvailableTasks ( ) {
        try {
            // Сбрасываем последние данные рефералов
            referalsData = [];
            referralsCount = 0;

            // Грузим данные задач
            $.ajax({
                url : "/apprin/v1/user/get_available_tasks/",
                data : "id=" + userData.uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            $( document ).trigger( "userAvailableTasksLoadInvalid" );

                            return;
                        }

                        tasksData = resp.data;

                        $( document ).trigger( "userAvailableTasksLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error( err );

                        $( document ).trigger( "userAvailableTasksLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "userAvailableTasksLoadEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    // получение доступных задач юзера
    function getAvailableTasks() {
        try {
            return tasksData;
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }


    // Загрузка данных о рефералах юзера
    function loadReferalsData ( page = 1 ) {
        try {
            // Сбрасываем последние данные рефералов
            referalsData = [];
            referralsCount = 0;

            // Если первая станица И есть в хранилище старые данные рефералов
            if ( page === 1 &&
                localStorage.getItem( storageReferalsKey ) !== undefined &&
                localStorage.getItem( storageReferalsKey ) !== null ) {
                // Подгружаем данные из хранилища
                referalsData = JSON.parse( localStorage.getItem( storageReferalsKey ) );
                referralsCount = JSON.parse( localStorage.getItem( storageReferralsCountKey ) );

                $( document ).trigger( "userReferalsDataStorageSuccess" );
            }

            // Грузим данные рефералов
            $.ajax({
                url : "/apprin/v1/user/load_referals_data/",
                data : "id=" + userData.uuid + "&page=" + page,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            $( document ).trigger( "userReferalsDataLoadInvalid" );

                            return;
                        }

                        referalsData = resp.data;
                        referralsCount = resp.count || 0;

                        // Если первая страница
                        if ( page === 1 ) {
                            // Пишем данные в хранилище
                            localStorage.setItem( storageReferalsKey, JSON.stringify( referalsData ) );
                            localStorage.setItem( storageReferralsCountKey, JSON.stringify( referralsCount ) );
                        }

                        $( document ).trigger( "userReferalsDataLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error( err );

                        $( document ).trigger( "userMainDataLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "userReferalsDataLoadEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    // получение основных данных юзера
    function getMainUserData() {
        try {
            return userData.mainData;
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }
    // поменять нужный ключ в основных данных юзера
    function setMainUserData( key, value ) {
        try {
            userData.mainData[ key ] = value;

            localStorage.setItem( storageKey, JSON.stringify(userData) );
        }
        catch (e) {
            console.error(e);
        }
    }
    // чтение основных данных юзера из хранилища
    function readStorageMainUserData( ) {
        try {
            userData = JSON.parse( localStorage.getItem( storageKey ) );
        }
        catch (e) {
            console.error(e);
        }
    }

    // получение всех данных юзера
    function getAllUserData() {
        try {
            return userData;
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    return {
        init: function () {
            init();
        },

        loadMainData: function () {
            loadMainData();
        },
        getMainUserData: function () {
            return getMainUserData();
        },
        setMainUserData: function ( key, value ) {
            setMainUserData( key, value );
        },
        readStorageMainUserData: function () {
            readStorageMainUserData();
        },
        getAllUserData: function () {
            return getAllUserData();
        },

        loadReferalsData: function ( page = 1 ) {
            loadReferalsData ( page );
        },
        getReferalsData: function () {
            return referalsData;
        },
        getReferralsCount: function () {
            return referralsCount;
        },

        loadAvailableTasks: function () {
            loadAvailableTasks ();
        },
        getAvailableTasks: function () {
            return getAvailableTasks ();
        }
    }
}

$( window ).on( "load", user.init );
