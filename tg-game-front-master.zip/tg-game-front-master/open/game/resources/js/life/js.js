let lifePage = new lifePageFunc();

function lifePageFunc() {
  let settingsStorageKey = "settings";
  let lifeCardsStorageKey = "lifeCards";

  let isLoadEnd = false;                          // Индикатор того, что уже была загрузка данных (хранилище или аякс)

  let byCards = 0;                                // Куплено карточек
  let allCards = 0;                               // Всего карточек
  let cards = [];                                 // Данные карточек
  let newCards = [];                              // Данные загруженных карточек, но не обработанных
  let maxPage = 0;                                // Максимальная страница
  let page = 0;                                   // Текущая страница. 0 - карточки строятся первый раз
  let loadPages = {};                             // Объект с загруженными данными страниц (чтобы не обрабатывать по несколько раз)
  let newPage = 0;                                // Страница, для которой были загружены данные
  let isPageLoad = false;                         // Индикатор того, что сейчас идёт загрузка
  let isByCard = false;                           // Индикатор того, что идёт покупка карточки
  let noBlurCount = 0;                            // Количество не заблюренных карточек с последней недоступной (включая её)
  let unblockCount = 0;                           // Количество открытых карточек, если позволяет баланс
  let pageOpenFlag = false;                           // Количество открытых карточек, если позволяет баланс

  let isLoadCards = false;                        // Идикатор того, что была загрузка карточек (нужно при обновлении данных юзера)

  let balanceInHourTimer = null;                  // Таймер обновления баланса при пассивном заработке

  function init() {
    try {
      nav.selectMenuItem("life");

      // Удаляем карточки
      clearCards();

      addEvents();
    }
    catch (e) {
      console.error(e);
    }
  }

  function pageOpen() {
    try {
      if (cards.length !== 0) {
        const lastByID = Math.max(...cards.filter(item => item.isBy).map(item => parseInt(item.id)))

        let lastByCardElem = $("[card-id=\"" + lastByID + "\"]");

        if (lastByCardElem && lastByCardElem.offset()) {
          let scrollLeft = lastByCardElem.offset().left - $(window).width() * 0.2 / 2;

          $("#lCItems").animate({
            "scrollLeft": scrollLeft
          }, 1000);
        }

        setTimeout(() => {
          pageOpenFlag = true;
        }, 2000)
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  //добавление событие
  function addEvents() {
    try {
      $("#lCItems").on("scroll", function () {
        if (!pageOpenFlag) {
          setTimeout(() => {
            scroll()
          }, 2000)
        } else {
          scroll()
        }
      });                 // Прокрутка элемента с карточками

      $(document).on("lifeCardsDataLoadSuccess", buildCards);                 // Успешное завершение загрузки данных карточек
      $(document).on("userMainDataStorageSuccess userMainDataLoadSuccess", userDataLoad);                 // Успешное завершение загрузки данных юзера

      $(document).on("settingsLoadSuccess", settingsLoad);                    // Загрузились настройки юзера
    }
    catch (e) {
      console.error(e);
    }
  }

  // Успешное завершение загрузки данных юзера
  function userDataLoad(e) {
    try {
      // console.log( e, user.getMainUserData() );

      if (!isLoadCards) {
        isLoadCards = true;

        // запускаем загрузку данных о карточках с последней купленной
        loadCardsForLastBy();
      }

      // Строим данные по монетам
      buildMonets();

      // Запускаем таймер пассивного заработка
      startBalanceInHourTimer();
    }
    catch (e) {
      console.error(e);
    }
  }

  //Построение данных по монетам
  function buildMonets() {
    try {
      parseArrayToElementData(user.getMainUserData());
    }
    catch (e) {
      console.error(e);
    }
  }

  //Построение данных над карточками
  function buildCardsHeader() {
    try {
      $("#lifeCard > span:nth-child(1)").html(byCards);
      $("#lifeCard > span:nth-child(3)").html(allCards);
    }
    catch (e) {
      console.error(e);
    }
  }

  // Загрузка данных карточек с последней купленной
  function loadCardsForLastBy() {
    try {
      isPageLoad = true;

      // console.log( "Локальное хранилище", localStorage.getItem( lifeCardsStorageKey ) );

      // Если есть данные в хранилище
      if (localStorage.getItem(lifeCardsStorageKey) !== undefined && localStorage.getItem(
        lifeCardsStorageKey) !== null) {
        let storageData = JSON.parse(localStorage.getItem(lifeCardsStorageKey));

        // console.log( storageData );

        // Берём данные карточек
        newCards = storageData.cards;

        // Записываем количество
        allCards = storageData.allCards
        byCards = storageData.byCards;

        // Записываем максимальную страницу и текущую
        maxPage = storageData.maxPage;
        newPage = storageData.newPage;

        // Записываем страницу в обработанные
        loadPages[newPage] = null;

        // строим данные над карточками
        buildCardsHeader();

        $(document).trigger("lifeCardsDataLoadSuccess");

        return;
      }

      // Грузим данные
      $.ajax({
        url: "/apprin/v1/life/load_cards_users/",
        data: "id=" + user.getAllUserData().uuid,
        type: "POST",
        success: function (responce) {
          // console.log( responce );

          try {
            let resp = JSON.parse(responce); //парсим ответ сервера

            if (resp.status !== "ok") {
              return;
            }

            // Берём данные карточек
            newCards = resp.data.data.data;

            // Записываем количество
            allCards = resp.data.maxCards
            byCards = resp.data.byCards;

            // Записываем максимальную страницу и текущую
            maxPage = resp.data.maxPage
            newPage = resp.data.page;

            // Записываем страницу в обработанные
            loadPages[newPage] = null;

            // строим данные над карточками
            buildCardsHeader();

            $(document).trigger("lifeCardsDataLoadSuccess");
          }
          catch (err) {
            console.error(err);
          }
        },
        error: function (err) {
          console.error(err);
        },
        complete: function () {
        }
      });
    }
    catch (e) {
      console.error(e);

      isPageLoad = false;
    }
  }

  // Загрузка карточек
  function loadCards() {
    try {
      // Грузим данные
      $.ajax({
        url: "/apprin/v1/life/load_cards/",
        data: "id=" + user.getAllUserData().uuid + "&page=" + newPage,
        type: "POST",
        success: function (responce) {
          // console.log( responce );

          try {
            let resp = JSON.parse(responce); //парсим ответ сервера

            if (resp.status !== "ok") {
              return;
            }

            // Берём данные карточек
            newCards = resp.data.data;

            $(document).trigger("lifeCardsDataLoadSuccess");
          }
          catch (err) {
            console.error(err);
          }
        },
        error: function (err) {
          console.error(err);
        },
        complete: function () {
          isPageLoad = false;
        }
      });
    }
    catch (e) {
      console.error(e);

      isPageLoad = false;
    }
  }

  // Загрузились настройки юзера
  function settingsLoad(e) {
    try {
      // console.log( "ЗАГРУЖЕНЫ НАСТРОЙКИ" );

      let settings = JSON.parse(localStorage.getItem(settingsStorageKey));

      // Если не было первой инструкции
      if (!settings.isEndFirstInstr) {
        // Запускаем шаг инструкции
        runFirstInstr(2);
      }
    }
    catch (e) {
      console.error(e);
    }
  }


  // Запуск таймера пассивного заработка
  function startBalanceInHourTimer() {
    try {
      clearBalanceInHourTimer();

      // Если монеты не зарабатываются
      if (user.getMainUserData().balanceInHour === 0) {
        return;
      }

      balanceInHourTimer = setTimeout(continueBalanceInHourTimer, 3000);
    }
    catch (e) {
      console.error(e);
    }
  }

  // Очистка таймера пассивного заработка
  function clearBalanceInHourTimer() {
    try {
      if (balanceInHourTimer !== null) {
        clearTimeout(balanceInHourTimer);

        balanceInHourTimer = null;
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Продолжение таймера пассивного заработка
  function continueBalanceInHourTimer() {
    try {
      clearBalanceInHourTimer();

      // Время старта
      let enterTime = new Date(user.getMainUserData().balanceInHourStartTime.replace(" ", "T"));
      // Текущее время
      let nowTime = new Date();
      // Текущее московское время
      let nowMoscowTime = new Date(nowTime.getTime() + (180 + nowTime.getTimezoneOffset()) * 60 * 1000);

      // Из текущего времени вычитаем разницу часовых поясов
      //nowTime.setHours( nowTime.getHours() - 7 );

      // Разница дат во времени
      let diff = (nowMoscowTime.getTime() - enterTime.getTime()) / 1000 / 60 / 60;
      // Монет в час
      let moneyInHour = user.getMainUserData().balanceInHour;
      // Надо добавить монет
      let addBalance = parseInt(diff * moneyInHour);

      // console.log( "Время входа " + enterTime, "Сейчас " + nowMoscowTime, "Разница " + diff + " ч.", "В час "  +moneyInHour,
      //     "Добавим на баланс " + addBalance, "Текущий баланс юзера " + user.getMainUserData().balance );

      // Если надо добавить больше или равно 1
      if (addBalance >= 1) {
        // console.log( "new balance " + (user.getMainUserData().balance + addBalance) );

        user.setMainUserData("balance", user.getMainUserData().balance + addBalance);
        user.setMainUserData("balanceInHourStartTime", nowMoscowTime.toJSON().replace("T", " "));

        // Выводим новый баланс
        $('[data-input-key="balance"]')
        .removeClass("animScale")
        .html(formatNumber(user.getMainUserData().balance + addBalance - 1));

        setTimeout(function () {
          $('[data-input-key="balance"]').addClass("animScale");
        }, 100);
      }

      balanceInHourTimer = setTimeout(continueBalanceInHourTimer, 3000);
    }
    catch (e) {
      console.error(e);
    }
  }


  // Прокрутка страницы
  function scroll(e) {
    try {
      let scrollWidth = $("#lCItems").prop('scrollWidth');
      let divWidth = $("#lCItems").width();
      let scrollerEndPoint = scrollWidth - divWidth;
      let divScrollerLeft = $("#lCItems").scrollLeft();

      let workPage = 0;

      // Если прокрутка вправо
      if (!isPageLoad && Math.abs(divScrollerLeft - scrollerEndPoint) <= 50) {
        // Если новая страница не больше максимума
        if (page + 1 <= maxPage) {
          workPage = page + 1;
        }
      }

      // console.log( page, maxPage, divScrollerLeft, scrollerEndPoint );

      // Если прокрутка влево
      if (!isPageLoad && divScrollerLeft <= 50) {
        // Если новая страница больше 0
        if (page - 1 > 0) {
          workPage = page - 1;
        }
      }

      // Если задана страница для обработки
      if (workPage > 0) {
        // Если страница обработки уже была обработана
        if (loadPages.hasOwnProperty(workPage)) {
          return;
        }

        isPageLoad = true;

        // Записываем страницу в обработанные
        loadPages[workPage] = null;

        newPage = workPage;

        // Загружаем карточки
        loadCards();
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Построение карточек
  function buildCards() {
    try {
      let userData = user.getMainUserData();

      // console.log( userData );

      let items = $('<div></div>');
      let lastByID = 0;

      for (let card of newCards) {
        let item = $('<div>' + '<div class="lCIItem">' + '                <div class="lCIIImg"></div>' + '' + '                <div class="lCIIText">' + '                    <span class="whiteFontColor"></span>' + '                </div>' + '' + '                <div class="lCIIBottom">' + '                    <div>' + '                        <div>' + '                            <img src="/resources/img/rocket_angle.png" />' + '' + '                            <div>' + '                                <div class="lCIIBRockets">' + '                                    <span class="blueGradientFont smallLargerFontSize">+0</span>' + '                                </div>' + '' + '                                <span class="whiteFontColor smallFontSize">' + lang.getText(
          "rockets")[0].toUpperCase() + lang.getText("rockets")
        .slice(1) + '</span>' + '                            </div>' + '                        </div>' + '' + '                        <div></div>' + '' + '                        <div>' + '                            <img src="/resources/img/earn_larg.svg" />' + '' + '                            <div>' + '                                <div class="lCIIBMoney">' + '                                    <span class="goldGradientFont smallLargerFontSize">+0</span>' + '                                </div>' + '' + '                                <span class="whiteFontColor smallFontSize">' + lang.getText(
          "money_in_hour") + '</span>' + '                            </div>' + '                        </div>' + '                    </div>' + '' + '                    <div class="lCIIBByBtn">' + '                        <span class="smallLargerFontSize">' + lang.getText(
          "by_for") + '</span>' + '' + '                        <img src="/resources/img/earn_larg.svg" />' + '' + '                        <span class="lCIIBSum goldGradientFont smallLargerFontSize">0</span>' + '                    </div>' + '                </div>' + '' + '                <div class="lCIIBlock">' + '                    <img src="/resources/img/lock.svg" />' + '                </div>' + '            </div>' + '</div>');

        // Если задана картинка
        if (card.img !== null) {
          $(".lCIIImg", item).css("background-image",
            'url("/resources/img/life/cards/' + card.img + '")');
        }

        // Пишем текст
        $(".lCIIText > span", item).html(card.text);
        $(".lCIIBRockets > span", item).html("+" + card.rockets);
        $(".lCIIBMoney > span", item).html("+" + card.moneyInHour);
        $(".lCIIBSum", item).html(card.sum);

        // Если куплено
        if (card.isBy === true) {
          $(".lCIIBByBtn", item).html('' + '<span class="smallLargerFontSize">' + lang.getText(
            "byed") + '</span>' + '' + '<img src="/resources/img/earn/end.png" />' + '');

          lastByID = card.id;
        }

        // Если карточка не куплена
        if (!card.isBy) {
          // Блокируем карточку
          $(".lCIIBlock", item).addClass("show");

          // Если количество не заблюренных карточек максимум
          if (noBlurCount === 3) {
            //Скрываем контент
            $(".lCIIImg, .lCIIText", item).addClass("blockBlur");
          } else {
            noBlurCount++;
          }
        }

        // Если карточка не куплена И стоимость карточки подходит под баланс и не было открытых карточек
        if (!card.isBy && card.sum <= userData.balance && unblockCount === 0) {
          // Разблокируем карточку
          $(".lCIIBlock", item).removeClass("show");

          //Показываем контент
          $(".lCIIImg, .lCIIText", item).removeClass("blockBlur");

          // Добавляем события
          addDelEventsCard(item);

          unblockCount++;
        }

        // Меняем атрибуты
        $(".lCIItem", item).attr({
          "card-id": card.id, "card-type": card.type, "card-by": card.isBy === true ? 1 : 0
        });

        // Добавляем элемент к другим
        items.append(item.contents());
      }

      // console.log( page, newPage );

      // Если первая загрузка или новая страница больше прошлой
      if (cards.length === 0 || newPage >= page) {
        // Записываем страницу в текущую
        if (cards.length === 0) {
          page = newPage;
        } else {
          page = newPage;
        }

        // console.log( "Добавляем карточку в конец" );

        // Добавляем карточки в конец
        $("#lCItems").append(items.contents());

        // Если первая загрузка
        if (cards.length === 0) {
          let lastByCardElem = $("[card-id=\"" + lastByID + "\"]");

          // TODO: check or delete comment #1
          if (lastByCardElem && lastByCardElem.offset()) {
            let scrollLeft = lastByCardElem.offset().left - $(window).width() * 0.2 / 2;

            // Перематываем до последней купленной карточки
            $("#lCItems").animate({
              "scrollLeft": scrollLeft
            }, 1000);
          }

          setTimeout(function () {
            isPageLoad = false;
          }, 1000);
        }

        // Добавляем карточки в конец
        cards = cards.concat(newCards);
      } else {
        // console.log( "Добавляем карточку в начало" );

        let lastByCardElem = $("[card-id]:first-child");
        let lastLeftScroll = $("#lCItems").scrollLeft();

        // Добавляем карточки в начало
        $("#lCItems").prepend(items.contents());

        let scrollLeft = lastByCardElem.offset().left + lastLeftScroll;

        // console.log( scrollLeft, lastByCardElem );

        // Перематываем до текущей карточки
        $("#lCItems").scrollLeft(scrollLeft);

        // Записываем страницу в текущую
        page = newPage;

        // Добавляем карточки в начало
        cards = newCards.concat(cards);

        isPageLoad = false;
      }

      // Сбрасываем временные переменные
      newPage = 0;
      newCards = [];
    }
    catch (e) {
      console.error(e);
    }
  }

  // Добавление/Удаление событий с карточки
  function addDelEventsCard(card, isAdd = true) {
    try {
      if (isAdd) {
        $(".lCIIBByBtn", card).on("click", byCard);                     // Клик на кнопку покупки карточки
      } else {
        $(".lCIIBByBtn", card).off("click", byCard);                     // Клик на кнопку покупки карточки
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Очистка данных карточек
  function clearCards() {
    try {
      $("#lCItems > *").remove();
    }
    catch (e) {
      console.error(e);
    }
  }

  // Покупка карточки
  function byCard(e) {
    tg?.HapticFeedback?.impactOccurred?.('soft')

    try {
      if (isByCard) {
        return;
      }

      isByCard = true;

      // ID карточки
      let cardID = parseInt($(e.currentTarget).parents("[card-id]").attr("card-id"));

      $.ajax({
        url: "/apprin/v1/life/by_card/",
        data: "id=" + user.getAllUserData().uuid + "&cardID=" + cardID,
        type: "POST",
        success: function (responce) {
          // console.log( responce );

          try {
            let resp = JSON.parse(responce); //парсим ответ сервера

            if (resp.status !== "ok") {
              return;
            }

            // Показываем количество монет
            showHideNotifLine(true, lang.getText("card_success_by"), "end.png", resp.data.rockets);

            // Меняем данные карточки
            setCardData(resp.data.cardData.id, resp.data.cardData);

            // Обновляем карточку на странице
            updateCard(resp.data.cardData);

            // Если карточка была куплена
            if (resp.data.cardData.isBy) {
              // Сбрасываем таймер пассивного заработка
              clearBalanceInHourTimer();

              // Временно записываем баланс юзера
              user.setMainUserData("balance",
                user.getMainUserData()["balance"] - resp.data.cardData.sum);

              // Временно записываем монет в час юзера
              user.setMainUserData("balanceInHour",
                user.getMainUserData()["balanceInHour"] + resp.data.cardData.moneyInHour);

              // console.log( "Новые данные юзера", user.getMainUserData() );

              // загружаем новые данные юзера
              user.loadMainData();

              // Увеличиваем количество купленных карточек
              byCards++;

              // Меняем количество купленных карточек на странице
              $("#lifeCard > span:nth-child(1)").html(byCards).addClass("animScale");

              setTimeout(function () {
                $("#lifeCard > span:nth-child(1)").removeClass("animScale");
              }, 300);

              // Загружаем снова данные для запись в хранилище
              system.loadLifeCardsForLastBy();

              // У родителя подгружаем новые данные
              parent.mainPage.reloadMainUserData();

              // Обновляем данные на зависимых страницах
              parent.mainPage.reload("space");
            }
          }
          catch (err) {
            console.error(err);
          }
        },
        error: function (err) {
          console.error(err);
        },
        complete: function () {
          isByCard = false;

          navigator.vibrate(200);
        }
      });
    }
    catch (e) {
      console.error(e);

      isByCard = false;
    }
  }

  // Замена данных карточки
  function setCardData(id, newCardData) {
    try {
      // Перебираем текущие карточки
      for (let i = 0; i <= cards.length - 1; i++) {
        if (cards[i].id === id) {
          cards[i] = newCardData;

          return;
        }
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Обновление карточки на странице
  function updateCard(cardData) {
    try {
      // console.log( "Карточка", cardData );

      let cardElem = $("[card-id=\"" + cardData.id + "\"]");
      let userData = user.getMainUserData();

      // Если карточка куплена
      if (cardData.isBy) {
        // Удаляем события
        addDelEventsCard(cardElem, false);

        // Меняем элементы
        $(".lCIIBByBtn", cardElem).html('' + '<span class="smallLargerFontSize">' + lang.getText(
          "byed") + '</span>' + '' + '<img src="/resources/img/earn/end.png">' + '');

        // Меняем атрибуты
        cardElem.attr("card-by", "1");
      }

      // Сбрасываем индикатор блюра
      noBlurCount = 0;
      // Сбрасываем количество разблокированных карточек
      unblockCount = 0;

      // Перебираем карточки на странице
      $("[card-id]").each(function () {
        let cardData = getItemByKeyValue(cards, "id", parseInt($(this).attr("card-id")));

        // console.log( "Карточка на обновлении", cardData );

        // Если карточка не куплена
        if (!cardData.isBy) {
          // console.log( "блокируем" );

          // Блокируем карточку
          $(".lCIIBlock", this).addClass("show");

          // Если количество не заблюренных карточек максимум
          if (noBlurCount === 3) {
            // console.log( "блюр 1" );

            //Скрываем контент
            $(".lCIIImg, .lCIIText", this).addClass("blockBlur");
          } else {
            // console.log( "антиблюр 1" );

            // Если не были разблокированы карточки
            if (unblockCount === 0) {
              // console.log( "антиблок 1" );

              // Если баланс позволяет купить карточку
              if (cardData.sum <= userData.balance) {
                // console.log( "Баланс позволяет", cardData.sum, userData.balance );

                // Снимаем блокировку карточку
                $(".lCIIBlock", this).removeClass("show");

                // Добавляем события
                addDelEventsCard(this);
              }

              unblockCount++;
            }

            //Показываем контент
            $(".lCIIImg, .lCIIText", this).removeClass("blockBlur");

            noBlurCount++;
          }
        }
      });
    }
    catch (e) {
      console.error(e);
    }
  }


  // Показ/Скрытие попап-а
  function showHidePopup(isShow = true) {
    try {
      if (isShow) {
        $(".popup").addClass("popupShow");
      } else {
        $(".popup").removeClass("popupShow");
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Добавление/Удаление событий попап-а
  function addDelEventsPopup(isAdd = true) {
    try {
      if (isAdd) {
        $(".popupBackground, .popupClose").on("click", closePopup);             // Клик на закрывающие элементы
        //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
      } else {
        $(".popupBackground, .popupClose").off("click", closePopup);             // Клик на закрывающие элементы
        //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Закрытие попап-а
  function closePopup() {
    try {
      // НЕ УНИВЕРСАЛЬНЫЙ КОД
      currentCheckTask = null;

      // Скрываем
      showHidePopup(false);

      // Удаляем события
      addDelEventsPopup(false);

      // Удаляем события задачи попап-а
      addDelTaskEventsPopup(false);

      // Скрываем кнопку перехода
      $(".popupBtnLink").addClass("hide");
      // Меняем надпись на старую
      $(".popupBtn > span").html(lang.getText("go"));

      // Удаляем стили ненужные. ЭТО НЕ УНИВЕРСАЛЬНЫЙ КОД
      $(".popupContent").removeClass("popupContentSmallPadding");

      // Срасываем таймер
      dailyQuizResetTimer();
    }
    catch (e) {
      console.error(e);
    }
  }


  // Показ первой инструкции
  function runFirstInstr(stepInstr = 1) {
    try {
      // Пишем контент
      $(".popupContent")
      .html('' + '        <div id="pCFirstInstr">' + "            <div id=\"pCFIImg\" style=\"background-image: url(/resources/img/instruction/" + stepInstr + ".png);\"></div>" + '' + '            <span class="smallLargerFontSize">' + lang.getText(
        "first_instr_text_" + stepInstr) + '</span>' + '        </div>' + '' + '        <a href="#" target="_blank" class="btn popupBtn" instr-step="' + stepInstr + '">' + '            <span>' + (stepInstr !== 6 ? lang.getText(
        "next") : lang.getText("fly")) + '</span>' + '        </a>')
      .addClass("mb");

      // Показываем
      showHidePopup();

      // Клик на кнопку
      $(".popupBtn").on("click", runFirstInstrBtnClick);
    }
    catch (e) {
      console.error(e);
    }
  }

  // Клик на кнопку первой инструкции
  function runFirstInstrBtnClick(e) {
    try {
      e.stopPropagation();
      e.preventDefault();

      let stepsItem = {
        "1": "main", "2": "life", "3": "space", "4": "friends", "5": "earn", "6": "life"
      };
      let stepInstr = parseInt($(e.currentTarget).attr("instr-step"));

      stepInstr++;

      // Если последний этап
      if (stepInstr === 6) {
        // Закрываем попап
        closePopup();

        // Записываем настройки
        $.ajax({
          url: "/apprin/v1/settings/setAllFirst/",
          data: "id=" + user.getAllUserData().uuid,
          type: "POST",
          success: function (responce) {
            // console.log( responce );

            try {
              let resp = JSON.parse(responce); //парсим ответ сервера

              if (resp.status !== "ok") {
                return;
              }

              system.setSettings("isEndFirstInstr", true);

              // Кликаем на нужный пункт меню
              $("[nav-item=\"life\"]").trigger("click");
            }
            catch (err) {
              console.error(err);
            }
          },
          error: function (err) {
            console.error(err);
          },
          complete: function () {

          }
        });
      } else {
        // Если не предпоследний пункт
        if (stepInstr !== 5) {
          // Переходим по нужному адресу
          window.location.href = $("[nav-item=\"" + stepsItem[stepInstr.toString()] + "\"]").attr(
            "href");
        } else {
          // Закрываем попап
          closePopup();

          setTimeout(function () {
            // Снова показываем инструкцию
            runFirstInstr(stepInstr);
          }, 500);
        }
      }
    }
    catch (e) {
      console.error(e);
    }
  }


  // Показ/Скрытие линейного уведомления
  function showHideNotifLine(isShow = true, text = "", icon = "end.png", sum = -1) {
    try {
      if (isShow) {
        $(".notifLine > img:first-child").attr("src", "/resources/img/earn/" + icon);
        $(".notifLine > span:nth-child(2)").html(text);

        // Если нет суммы
        if (sum < 0) {
          // Скрываем поля некоторые
          $(".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)").addClass("hide");
        } else {
          $(".notifLine > span:nth-child(4)").html("+" + sum);

          // показываем поля некоторые
          $(".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)").removeClass("hide");
        }

        // Добавляем события
        addDelEventsNotifLine();

        $(".notifLine").addClass("show");

        notifLineTimer = setTimeout(function () {
          // Закрываем
          showHideNotifLine(false);
        }, 5000);
      } else {
        clearTimeout(notifLineTimer);

        notifLineTimer = null;

        // Удаляем события
        addDelEventsNotifLine(false);

        $(".notifLine").removeClass("show");
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Добавление/Удаление событий линейного уведомления
  function addDelEventsNotifLine(isAdd = true) {
    try {
      if (isAdd) {
        $(".notifLine").on("click", closeNotifLine);            // Клик на уведомление
      } else {
        $(".notifLine").off("click", closeNotifLine);            // Клик на уведомление
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  // Закрытие линейного уведомления
  function closeNotifLine() {
    try {
      // Скрываем уведомление
      showHideNotifLine(false);
    }
    catch (e) {
      console.error(e);
    }
  }


  return {
    init: function () {
      init();
    }, pageOpen: function () {
      pageOpen();
    }
  }
}

// запускаем инициализацию страницы рефералов
$(window).on("load", lifePage.init);

if (!window.pageOpen) {
  window.pageOpen = {}
}

window.pageOpen['life'] = lifePage.pageOpen