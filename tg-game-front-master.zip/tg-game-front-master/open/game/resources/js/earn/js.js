let earnPage = new earnPageFunc();

function earnPageFunc () {
    let settingsStorageKey = "settings";
    let currentCheckTask = null;                 // Данные текущей проверяемой задачи

    let dailyQuiz = null;                       // Информация о ежедневном квиз-е
    let dailyQuizStep = null;                       // Информация о ежедневном квиз-е
    let dailyQuizTimer = null;                  // Таймер при ответе на вопрос квиз-а
    let dailyQuizTime = 0;                      // Время для таймера
    let isShowBadNotif = false;                 // 0 - не было показано окно замены вопроса, 1 - было показано окно замены вопроса
    let lastQuestExistAnswer = true;            // 0 - на последний вопрос не было ответа, 1 - ответ был
    let answerCount = {
        "good" : 0,
        "bad" : 0
    };                                                  // Количества ответов. good - верных, bad - ошибочных

    let notifLineTimer = null;                  // Таймер скрытия линейного уведомления

    let timerNewQuiz = null;                    // Таймер до нового квиз-а
    let currentTimeNewQuiz = 0;                 // Текущее время до нового квиз-а в секундах
    let newQuizStepSeconds = 5;                // Шаг таймера нового квиз-а в секундах

    let advert = window.Adsgram.init({ blockId: "2200" });              // Элемент для показа рекламы

    let isPay = false;                          // Индикатор того, что идёт оплата доната квиза
    let payCheckOrderUUID = null;               // UUID доната
    let payTimer = null;                                            // Таймер во время проверки оплаты
    let maxPayTime = 5;                                         // Максимальное время ожидания оплаты в минутах
    let currPayTime = 0;                                        // Текущее прошеднее время в секундах
    let payTime = 3;                                            // Интервал проверки оплаты в секундах

    function init() {
        try {
            nav.selectMenuItem( "earn" );

            // Удаляем задачи
            clearTasks();

            // Добавляем слушатели событий
            addEvents();

            // Добавляем слушатели событий всплывающих подсказок
            titleAddDelEvents();

            // Загружаем данные о ежедневном квиз-е
            loadDailyQuiz();

            // Запускаем загрузку задач
            user.loadAvailableTasks( );

            tg.onEvent( "invoiceClosed", closeInvoice );
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( document ).on( "userAvailableTasksLoadSuccess", buildTasks );               // Успешное завершение загрузки доступных задач

            $( document ).on( "dailyQuizLoadSuccess", buildDailyQuiz );                          // Успешная загрузка данных о квиз-е
            $( "#quizItem" ).on( "click", dailyQuizClick );                                         // Клик на квиз

            $( document ).on( "settingsLoadSuccess", settingsLoad );                    // Загрузились настройки юзера
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузились настройки юзера
    function settingsLoad( e ) {
        try {
            let settings = JSON.parse( localStorage.getItem( settingsStorageKey ) );

            // Если не было первой инструкции
            if ( !settings.isEndFirstInstr ) {
                // Запускаем шаг инструкции
                runFirstInstr( 5 );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Запуск таймера нового квиз-а
    function startTimerNewQuiz( ) {
        try {
            // Чистим таймер
            clearTimerNewQuiz();

            currentTimeNewQuiz = dailyQuiz.dateNewQuizSeconds;

            let newTimeArr = {
                "hour" : parseInt( currentTimeNewQuiz / 60 / 60 ),
                "minutes" : 0,
                "seconds" : 0
            };

            newTimeArr.minutes = parseInt( ( currentTimeNewQuiz - newTimeArr.hour * 60 * 60 ) / 60 );
            newTimeArr.seconds = parseInt( ( currentTimeNewQuiz - newTimeArr.minutes * 60 - newTimeArr.hour * 60 * 60 ) );

            // console.log( newTimeArr );

            newTimeArr.hour = ("00" + newTimeArr.hour).slice( -2 ).toString().split( "" );
            newTimeArr.minutes = ("00" + newTimeArr.minutes).slice( -2 ).toString().split( "" );
            newTimeArr.seconds = ("00" + newTimeArr.seconds).slice( -2 ).toString().split( "" );

            // Выводим время таймера
            $( ".eIRNoActive > div:first-child > span:nth-child( 1 )" ).html( newTimeArr.hour[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 2 )" ).html( newTimeArr.hour[ 1 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 4 )" ).html( newTimeArr.minutes[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 5 )" ).html( newTimeArr.minutes[ 1 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 7 )" ).html( newTimeArr.seconds[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 8 )" ).html( newTimeArr.seconds[ 1 ] );

            timerNewQuiz = setTimeout( continueTimerNewQuiz, newQuizStepSeconds * 1000 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка таймера нового квиз-а
    function clearTimerNewQuiz( ) {
        try {
            if ( timerNewQuiz !== null ) {
                clearTimeout( timerNewQuiz );

                timerNewQuiz = null;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение таймера нового квиз-а
    function continueTimerNewQuiz( ) {
        try {
            // Чистим таймер
            clearTimerNewQuiz();

            let newTime = currentTimeNewQuiz - newQuizStepSeconds;

            if ( newTime <= 0 ) {
                // Загружаем данные о новом ежедневном квиз-е
                loadDailyQuiz();

                return;
            }

            currentTimeNewQuiz = newTime;

            let newTimeArr = {
                "hour" : parseInt( currentTimeNewQuiz / 60 / 60 ),
                "minutes" : 0,
                "seconds" : 0
            };

            newTimeArr.minutes = parseInt( ( currentTimeNewQuiz - newTimeArr.hour * 60 * 60 ) / 60 );
            newTimeArr.seconds = parseInt( ( currentTimeNewQuiz - newTimeArr.minutes * 60 - newTimeArr.hour * 60 * 60 ) );


            // console.log( newTimeArr );

            newTimeArr.hour = ("00" + newTimeArr.hour).slice( -2 ).toString().split( "" );
            newTimeArr.minutes = ("00" + newTimeArr.minutes).slice( -2 ).toString().split( "" );
            newTimeArr.seconds = ("00" + newTimeArr.seconds).slice( -2 ).toString().split( "" );

            // Выводим время таймера
            $( ".eIRNoActive > div:first-child > span:nth-child( 1 )" ).html( newTimeArr.hour[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 2 )" ).html( newTimeArr.hour[ 1 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 4 )" ).html( newTimeArr.minutes[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 5 )" ).html( newTimeArr.minutes[ 1 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 7 )" ).html( newTimeArr.seconds[ 0 ] );
            $( ".eIRNoActive > div:first-child > span:nth-child( 8 )" ).html( newTimeArr.seconds[ 1 ] );

            timerNewQuiz = setTimeout( continueTimerNewQuiz, newQuizStepSeconds * 1000 );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Закрытие инвойса ТГ
    function closeInvoice( e ) {
        try {
            // console.log( "invoice close event" , e );

            // Если была оплата
            if ( isPay ) {
                // Если не было оплаты
                if ( e.status !== "paid" ) {
                    isPay = false;

                    $( ".pCQNButtons > div" ).removeClass( "inactive" );

                    // включаем кнопку
                    dailyQuizOnOffBtn();
                }
            }
        }
        catch (e) {
            console.error(e);
        }
    }


    // Загрузка данных ежедневного квиз-а
    function loadDailyQuiz( ) {
        try {
            $.ajax({
                url : "/apprin/v1/quiz/load_daily/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( response ) {
                    // console.log( 'response', response );

                    try {
                        let resp = JSON.parse( response ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // записываем данные квиз-а
                        dailyQuiz = resp.data;

                        $( document ).trigger( "dailyQuizLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);

                        $( document ).trigger( "dailyQuizLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "dailyQuizLoadEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }
    // Построение ежедневного квиз-а
    function buildDailyQuiz( ) {
        try {
            // Если квиз заблочен
            if ( dailyQuiz.isBadReferals ) {
                $( "#quizItem" ).addClass( "block show animScale" );

                return;
            }

            // Снимаем блокировку
            $( "#quizItem" ).removeClass( "block" );

            // Если квиз не был запущен
            if ( !dailyQuiz.isStart ) {
                $( "#quizItem .eIRNoActive" ).removeClass( "show" );

                $( "#quizAllSum > span" ).html( lang.getText( "from" ) + " " + ( dailyQuiz.sumEnter ) );

                $( "#quizItem .eIRActive" ).addClass( "show" );
            }
            else {
                // Запускаем таймер
                startTimerNewQuiz();

                $( "#quizItem .eIRActive" ).removeClass( "show" );

                // Показываем таймер
                $( "#quizItem .eIRNoActive" ).addClass( "show" );
            }

            $( "#quizItem" ).addClass( "show animScale" );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на квиз
    function dailyQuizClick( e ) {
        try {
            if ( dailyQuiz.isStart ) {
                return;
            }

            // Меняем содержимое попап-а
            $( "#earn_page .popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupIconLarge">' +
                '            <img src="/resources/img/earn/quiz.png" />' +
                '        </div>' +
                '' +
                '        <div class="popupLabel">' +
                '            <span class="smallLargerFontSize">' + lang.getText( "end_quiz_and_get_money" ) + '</span>' +
                '        </div>' +
                '' +
                '        <div id="popupQuizPreviewItems">' +
                '            <div class="pQPILarge">' +
                '                <div>' +
                '                    <img src="/resources/img/rocket_angle.png" />' +
                '' +
                '                    <span class="blueGradientFont smallLargerFontSize">+0</span>' +
                '                </div>' +
                '' +
                '                <div>' +
                '                    <span class="smallFontSize">' + lang.getText( "for_enter_game" ) + '</span>' +
                '                </div>' +
                '            </div>' +
                '' +
                '            <div class="pQPILarge">' +
                '                <div>' +
                '                    <img src="/resources/img/rocket_angle.png" />' +
                '' +
                '                    <span class="blueGradientFont smallLargerFontSize">+0</span>' +
                '                </div>' +
                '' +
                '                <div>' +
                '                    <span class="smallFontSize">' + lang.getText( "for_good_answer" ) + '</span>' +
                '                </div>' +
                '            </div>' +
                '' +
                '            <div>' +
                '                <div>' +
                '                    <span class="smallLargerFontSize">0</span>' +
                '                </div>' +
                '' +
                '                <div>' +
                '                    <span class="smallFontSize">' + lang.getText( "questions" ) + '</span>' +
                '                </div>' +
                '            </div>' +
                '' +
                '            <div>' +
                '                <div>' +
                '                    <span class="smallLargerFontSize">0 ' + lang.getText( "sec" ) + '</span>' +
                '                </div>' +
                '' +
                '                <div>' +
                '                    <span class="smallFontSize">' + lang.getText( "quest_time" ) + '</span>' +
                '                </div>' +
                '            </div>' +
                '' +
                '            <div class="pQPIBlue">' +
                '                <div>' +
                '                    <img src="/resources/img/rocket_angle.png" />' +
                '' +
                '                    <span class="smallLargerFontSize">0</span>' +
                '                </div>' +
                '' +
                '                <div>' +
                '                    <span class="smallFontSize">' + lang.getText( "max_pay" ) + '</span>' +
                '                </div>' +
                '            </div>' +
                '        </div>' +
                '' +
                '        <a href="" target="_blank" class="btn popupBtn">' +
                '            <span>' + lang.getText( "go" ) + '</span>' +
                '        </a>' );

            // Пишем данные квиз-а
            $( "#popupQuizPreviewItems > div:first-child > div:first-child > span" ).html( "+" + dailyQuiz.sumEnter );
            $( "#popupQuizPreviewItems > div:nth-child( 2 ) > div:first-child > span" ).html( "+" + dailyQuiz.sumGoodAnswer );
            $( "#popupQuizPreviewItems > div:nth-child( 3 ) > div:first-child > span" ).html( dailyQuiz.questions.length );
            $( "#popupQuizPreviewItems > div:nth-child( 4 ) > div:first-child > span" ).html( dailyQuiz.answerTime + " " + lang.getText( "sec" ) );
            $( "#popupQuizPreviewItems > div:nth-child( 5 ) > div:first-child > span" ).html( ( dailyQuiz.questions.length * dailyQuiz.sumGoodAnswer + dailyQuiz.sumEnter ) * dailyQuiz.goodMult );


            // показываем поп-ап
            showHidePopup();
            // Добавляем события попап-у
            addDelEventsPopup();
            // Добавляем события задачи попап-а
            addDelDailyQuizPreviewEventsPopup();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий ежедневного квиз-а попап-а
    function addDelDailyQuizPreviewEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBtn" ).on( "click", popupButtonDailyQuizPreviewClick );                           // клик на кнопку
            }
            else {
                $( ".popupBtn" ).off( "click", popupButtonDailyQuizPreviewClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий с плашек ежедневного квиз-а
    function addDelDailyQuizItemsEvents( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".pCQIItem" ).on( "click", dailyQuizItemClick );                           // клик на вариант ответа
            }
            else {
                $( ".pCQIItem" ).off( "click", dailyQuizItemClick );                           // клик на вариант ответа
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на кнопку попап-а в превью квиз-а
    function popupButtonDailyQuizPreviewClick( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            // Скрываем попап
            closePopup();

            setTimeout( function() {
                // Шлём данные для отметки начала прохождения квиз-а
                $.ajax({
                    url : "/apprin/v1/quiz/start_daily/",
                    data : "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id,
                    type : "POST",
                    success : function ( response ) {
                        // console.log( 'response', response );

                        try {
                            let resp = JSON.parse( response ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            // записываем новые данные квиз-а
                            dailyQuiz = resp.data;

                            // Кидаем событие загрузки данных квиз-а (чтобы обновился элемент квиз-а)
                            $( document ).trigger( "dailyQuizLoadSuccess" );

                            // Ставим статус прохождения квиз-а
                            dailyQuizStep = 0;

                            // Меняем содержимое попап-а
                            $( "#earn_page .popupContent" ).html( '' +
                                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                                '' +
                                '        <div id="pCQuizAllSum">' +
                                '            <div>' +
                                '                <img src="/resources/img/rocket_angle.png" />' +
                                '' +
                                '                <span class="blueGradientFont" quiz-all-sum="0">0</span>' +
                                '            </div>' +
                                '' +
                                '            <span class="smallFontSize">' + lang.getText( "you_sum" ) + '</span>' +
                                '        </div>' +
                                '' +
                                '        <div id="pCQuiz">' +
                                '            <div class="pCQImg">' +
                                '                <img src="/resources/img/tasks/daily/task_DELETE.jpg" />' +
                                '            </div>' +
                                '' +
                                '            <div class="pCQStatus">' +
                                '            </div>' +
                                '' +
                                '            <div id="pCQTimer">' +
                                '                <div>' +
                                '                    <span class="largFontSize">0</span>' +
                                '                </div>' +
                                '' +
                                '                <div>' +
                                '                    <span class="largFontSize">0</span>' +
                                '                </div>' +
                                '' +
                                '                <div>' +
                                '                    <span class="largFontSize">:</span>' +
                                '                </div>' +
                                '' +
                                '                <div>' +
                                '                    <span class="largFontSize">0</span>' +
                                '                </div>' +
                                '' +
                                '                <div>' +
                                '                    <span class="largFontSize">0</span>' +
                                '                </div>' +
                                '            </div>' +
                                '' +
                                '            <div id="pCQQuestion">' +
                                '                <span class="largerFontSize">\</span>' +
                                '            </div>' +
                                '' +
                                '            <div id="pCQItems">' +
                                '            </div>' +
                                '' +
                                '            <div class="pCQNotif">' +
                                '                <div class="pCQNLabel">' +
                                '                    <span class="largerFontSize">' + lang.getText( 'time_end' ) + '</span>' +
                                '                </div>' +
                                '' +
                                '                <div class="pCQNText">' +
                                '                    <span>' + lang.getText( "you_can_by_or_adv" ) + '</span>' +
                                '                </div>' +
                                '' +
                                '                <div class="pCQNButtons">' +
                                '                    <div class="pCQNBYellow">' +
                                '                        <span class="darkFont">' + lang.getText( "by_for_cleim" ) + '</span>' +
                                '' +
                                '                        <span class="darkFont">0.0000</span>' +
                                '                    </div>' +
                                '' +
                                '                    <div>' +
                                '                        <span>' + lang.getText( "free" ) + '</span>' +
                                '' +
                                '                        <span class="grayFontColor">1 ' + lang.getText( "raz" ) + '</span>' +
                                '                    </div>' +
                                '                </div>' +
                                '            </div>' +
                                '        </div>' +
                                '' +
                                '        <a href="" target="_blank" class="btn popupBtn popupBtnQuiz">' +
                                '            <span>' + lang.getText( "next_question" ) + '</span>' +
                                '        </a>' ).addClass( "popupContentSmallPadding" );

                            let items = $( '<div></div>' );

                            // Перебираем вопросы
                            for ( let x = 1; x <= dailyQuiz.questions.length; x++ ) {
                                items.append( '<div ></div>' );
                            }

                            // Выводим элементы статуса
                            $( ".pCQStatus" ).html( items.contents() );

                            // Переходим к следующему этапу
                            dailyQuizNextStep();


                            // Показываем попап
                            showHidePopup();
                            // Добавляем события попап-у
                            addDelEventsPopup();
                            // Добавляем события задачи попап-а
                            addDelDailyQuizEventsPopup();
                        }
                        catch ( err ) {
                            console.error(err);
                        }
                    },
                    error : function ( err ) {
                        console.error(err);
                    },
                    complete : function () {

                    }
                });
            } , 300 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий кнопки при прохождении квиз-а
    function addDelDailyQuizEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBtnQuiz" ).on( "click", dailyQuizNextStep );                           // клик на кнопку
                $( ".pCQNButtons > div" ).on( "click", dailyQuizReplaceQuest );                     // Клик на кнопку замены вопроса
            }
            else {
                $( ".popupBtnQuiz" ).off( "click", dailyQuizNextStep );                           // клик на кнопку
                $( ".pCQNButtons > div" ).off( "click", dailyQuizReplaceQuest );                     // Клик на кнопку замены вопроса
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на вариант ответа
    function dailyQuizItemClick( e ) {
        try {
            // Снимаем выделение с ранее выбранного варианта
            $( '.pCQIItem[quiz-item-select="1"]' ).removeAttr( "quiz-item-select" ).removeClass( "pCQIItemGood" );

            // Выделяем новый вариант
            $( "img", e.currentTarget ).attr( "src", "/resources/img/earn/end_invert.svg" );
            $( e.currentTarget ).attr( "quiz-item-select", "1" ).addClass( "pCQIItemGood" );

            // console.log( $( e.currentTarget ) );

            // Переходим к следующему вопросу
            dailyQuizNextStep();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Переход к следующему вопросу квиз-а
    function dailyQuizNextStep( e ) {
        try {
            try {
                e.stopPropagation();
                e.preventDefault();
            } catch (e) {
            }

            let currentStep = dailyQuizStep;

            let nextStep = currentStep + 1;

            // console.log( currentStep, nextStep );

            // Если было показано окно замены вопроса
            if ( isShowBadNotif ) {
                nextStep = currentStep;
                currentStep--;
            }

            // Выключаем кнопку
            dailyQuizOnOffBtn(false);

            // индикатор того, что была замена вопроса
            let isChangeQuest = dailyQuiz.isChangeQuest === true;

            // удаляем идикатор замены вопроса
            delete dailyQuiz.isChangeQuest;

            // console.log( isChangeQuest );

            // Если новый этап равен 1
            if (nextStep === 1) {
                dailyQuizStep = nextStep;

                // Если не было замены вопроса
                if ( !isChangeQuest ) {
                    // Увеличиваем сумму выигрыша в квиз-е
                    dailyQuizAddAllSum(dailyQuiz.sumEnter);
                }

                // Ставим полоску
                dailyQuizSetStep( 1, "current" );
                // строим следующий этап
                dailyQuizBuildStep();
                // добавляем события элементам
                addDelDailyQuizItemsEvents();
                // включаем кнопку
                dailyQuizOnOffBtn();
                // запускаем таймер
                dailyQuizStartTimer( dailyQuiz.answerTime );
            }
            else {
                // Если было показано окно замены вопроса
                if ( isShowBadNotif ) {
                    // Если вопрос был последним
                    if ( nextStep > dailyQuiz.questions.length ) {
                        dailyQuizStep = -1;

                        // показываем результативный слой
                        dailyQuizShowResult();

                        // Отправляем данные для завершения квиз-а
                        $.ajax({
                            url : "/apprin/v1/quiz/end_daily/",
                            data : "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id,
                            type : "POST",
                            success : function ( responce ) {
                                // console.log( responce );

                                try {
                                    let resp = JSON.parse( responce ); //парсим ответ сервера

                                    if ( resp.status !== "ok" ) {
                                        return;
                                    }
                                }
                                catch ( err ) {
                                    console.error(err);
                                }
                            },
                            error : function ( err ) {
                                console.error(err);
                            },
                            complete : function () {
                                $( ".pCQNButtons > div" ).removeClass( "inactive" );

                                // включаем кнопку
                                dailyQuizOnOffBtn();
                            }
                        });

                        return;
                    }

                    isShowBadNotif = false;

                    // Шлём данные о старте ответа на вопрос
                    $.ajax({
                        url: "/apprin/v1/quiz/start_answer/",
                        data: "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id + "&quest=" + ( currentStep - 1 ) + "&isEmpty=" + (lastQuestExistAnswer ? "0" : "1"),
                        type: "POST",
                        success: function (responce) {
                            // console.log(responce);

                            try {
                                let resp = JSON.parse(responce); //парсим ответ сервера

                                if (resp.status !== "ok") {
                                    return;
                                }

                                // Если текущий вопрос был последним
                                if ( currentStep === dailyQuiz.questions.length ) {
                                    // увеличиваем количество неверных ответов
                                    answerCount.bad++;

                                    // показываем результативный слой
                                    dailyQuizShowResult();

                                    return;
                                }

                                // Текущий вопрос ставим ошибочным-пройденным
                                dailyQuizSetStep( nextStep - 1, "error" );
                                // Следующий вопрос ставим текущим
                                dailyQuizSetStep( nextStep, "current" );
                                // строим шаг
                                dailyQuizBuildStep();
                                // добавляем события элементам
                                addDelDailyQuizItemsEvents();
                                // включаем кнопку
                                dailyQuizOnOffBtn();
                                // запускаем таймер
                                dailyQuizStartTimer( dailyQuiz.answerTime );
                                // Скрываем окошко с предложением о замене вопроса
                                dailyQuizShowHideNotif( false );
                            }
                            catch (err) {
                                console.error(err);
                            }
                        },
                        error: function (err) {
                            console.error(err);
                        },
                        complete: function () {
                            lastQuestExistAnswer = true;
                        }
                    });
                }
                else {
                    // индекс выбранного варианта
                    let answerIndex = parseInt( $( '[quiz-item-select="1"]' ).attr( "quiz-item-index" ) );

                    if ( answerIndex === undefined || isNaN( answerIndex ) ) {
                        throw "Invalid answer index";
                    }

                    // Шлём данные ответа на вопрос квиз-а
                    $.ajax({
                        url: "/apprin/v1/quiz/check_daily/",
                        data: "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id + "&quest=" + (currentStep - 1) + "&answer=" + answerIndex,
                        type: "POST",
                        success: function (responce) {
                            // console.log(responce);

                            try {
                                let resp = JSON.parse(responce); //парсим ответ сервера

                                if (resp.status !== "ok") {
                                    return;
                                }

                                // Если есть индикатор верности ответа
                                if ( resp.data.hasOwnProperty( "isGood" ) ) {
                                    // Если ответ верный
                                    if ( resp.data.isGood ) {
                                        // Увеличиваем сумму выигрыша в квиз-е
                                        dailyQuizAddAllSum( dailyQuiz.sumGoodAnswer );

                                        // увеличиваем количество верных ответов
                                        answerCount.good++;

                                        // Если был последний вопрос
                                        if ( resp.data.isEnd || nextStep > dailyQuiz.questions.length ) {
                                            dailyQuizStep = -1;

                                            // показываем результативный слой
                                            dailyQuizShowResult();

                                            return;
                                        }

                                        // записываем новый шаг
                                        dailyQuizStep = nextStep;

                                        // Текущий вопрос ставим успешно-пройденным
                                        dailyQuizSetStep( currentStep, "ok" );
                                        // Следующий вопрос ставим текущим
                                        dailyQuizSetStep( nextStep, "current" );
                                        // строим шаг
                                        dailyQuizBuildStep();
                                        // добавляем события элементам
                                        addDelDailyQuizItemsEvents();
                                        // включаем кнопку
                                        dailyQuizOnOffBtn();
                                        // запускаем таймер
                                        dailyQuizStartTimer( dailyQuiz.answerTime );
                                        // Скрываем окошко с предложением о замене вопроса
                                        dailyQuizShowHideNotif( false );
                                    }
                                    else {
                                        // записываем новый шаг
                                        dailyQuizStep = nextStep;
                                        // увеличиваем количество неверных ответов
                                        answerCount.bad++;

                                        // включаем кнопку
                                        dailyQuizOnOffBtn();
                                        // Меняем оповещение
                                        dailyQuizChangeNotif( lang.getText( "its_bad_answer" ) );
                                        // Показываем окошко с предложением о замене вопроса
                                        dailyQuizShowHideNotif( );
                                        // Сбрасываем таймер
                                        dailyQuizResetTimer();
                                        // Показываем верный ответ
                                        dailyQuizShowValidAnswer( resp.data.goodAnswers );
                                    }
                                }
                            }
                            catch (err) {
                                console.error(err);
                            }
                        },
                        error: function (err) {
                            console.error(err);
                        },
                        complete: function () {

                        }
                    });
                }
            }
        }
        catch (e) {
            console.error(e);

            // Включаем кнопку
            dailyQuizOnOffBtn();
        }
    }
    // Показ верного ответа квиз-а
    function dailyQuizShowValidAnswer( validAnswers ) {
        try {
            let currentAnswer = parseInt( $( '[quiz-item-select="1"]' ).attr( 'quiz-item-index' ) );
            let isCurrentAnswerOk = false;

            for ( let answer of validAnswers ) {
                // Если текущий ответ верный
                if ( currentAnswer + 1 === answer ) {
                    // console.log( currentAnswer + 1, answer );
                    isCurrentAnswerOk = true;
                }

                // Выделяем верный ответ
                $( '[quiz-item-index="' + (answer - 1) + '"]:not([quiz-item-select="1"]) > div > img' ).attr( "src", "/resources/img/earn/end_invert.svg" );
                $( '[quiz-item-index="' + (answer - 1) + '"]:not([quiz-item-select="1"])' ).removeClass( "pCQIItemGood" ).addClass( "pCQIItemOk" );
            }

            // Если выбранный ответ неверный
            if ( !isCurrentAnswerOk ) {
                // console.log( "Ответ неверный был" );
                // Выделяем соответствующим образом
                $( '[quiz-item-select="1"] > div > img' ).attr( "src", "/resources/img/earn/error_invert.svg" );
                $( '[quiz-item-select="1"]' ).removeClass( "pCQIItemOk pCQIItemGood" ).addClass( "pCQIItemError" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Простроение этапа квиз-а
    function dailyQuizBuildStep( ) {
        try {
            let currentStep = dailyQuizStep;

            // Удаляем события с элементов на выбор
            addDelDailyQuizItemsEvents( false );

            // Меняем вопрос
            $( "#pCQQuestion > span" ).html( dailyQuiz.questions[ currentStep - 1 ] );
            // Удаляем прошлые элементы на выбор
            $( ".pCQIItem" ).remove();

            let items = $( '<div></div>' );
            let index = 0;

            // Перебираем варианты ответов
            for ( let answer of dailyQuiz.answers[ currentStep - 1 ].answers ) {
                items.append( '' +
                    '<div class="pCQIItem" quiz-item-index="' + index + '">' +
                    '                    <span>' + answer + '</span>' +
                    '' +
                    '                    <div>' +
                    '                        <img src="/resources/img/earn/end_invert.svg" />' +
                    '                    </div>' +
                    '                </div>' );

                index++;
            }

            // Выводим варианты на страницу
            $( "#pCQItems" ).html( items.contents() );

            // Обновляем оповещение квиз-а
            dailyQuizUpdateNotif();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Изменение оповещения снизу квиз-а
    function dailyQuizChangeNotif( label ) {
        try {
            $( ".pCQNLabel > span" ).html( label );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Вкл/Выкл кнопки квиз-а
    function dailyQuizOnOffBtn( isOn = true ) {
        try {
            if ( isOn ) {
                $( ".popupBtnQuiz" ).removeClass( "popupBtnQuizInactive" );
            }
            else {
                $( ".popupBtnQuiz" ).addClass( "popupBtnQuizInactive" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Установка полоски квиз-а
    function dailyQuizSetStep( stepNumber, status ) {
        try {
            $( ".pCQStatus > div" ).eq(stepNumber -1).removeClass( "current ok error" ).addClass( status );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Добавление итогового выигрыша в квиз-е
    function dailyQuizAddAllSum( addSum ) {
        try {
            let currentSum = parseInt( $( "[quiz-all-sum]" ).attr( "quiz-all-sum" ) );

            $( "[quiz-all-sum]" ).html( currentSum + addSum ).attr( "quiz-all-sum", currentSum + addSum );

            $( "#pCQuizAllSum" ).addClass( "animScale" );

            setTimeout( function() {
                $( "#pCQuizAllSum" ).removeClass( "animScale" );
            }, 300 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Запуск таймера вопроса квиз-а
    function dailyQuizStartTimer( startTimeSeconds ) {
        try {
            // Чистим таймер
            dailyQuizClearTimer();

            dailyQuizTime = startTimeSeconds;

            let timeArr = ( "00" + startTimeSeconds.toString() ).slice( -2 ).split( "" );

            $( "#pCQTimer > :nth-child(4) > span" ).html( timeArr[ 0 ] );
            $( "#pCQTimer > :nth-child(5) > span" ).html( timeArr[ 1 ] );

            dailyQuizTimer = setTimeout( dailyQuizContinueTimer, 1000 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение таймера вопроса квиз-а
    function dailyQuizContinueTimer( ) {
        try {
            let newTime = dailyQuizTime - 1;

            // Чистим таймер
            dailyQuizClearTimer();

            // Если время вышло
            if ( newTime <= 0 ) {
                // удаляем события с элементов
                addDelDailyQuizItemsEvents( false );

                dailyQuizStep++;

                // Ставим индикатор отсутствия ответа на последний вопрос
                lastQuestExistAnswer = false;
                // увеличиваем количество неверных ответов
                //answerCount.bad++;

                // Сбрасываем таймер
                dailyQuizResetTimer();
                // Меняем оповещение
                dailyQuizChangeNotif( lang.getText( "time_end" ) );
                // Выводим окошко с предложением о замене вопроса
                dailyQuizShowHideNotif();

                return;
            }

            let timeArr = ( "00" + newTime.toString() ).slice( -2 ).split( "" );

            $( "#pCQTimer > :nth-child(4) > span" ).html( timeArr[ 0 ] );
            $( "#pCQTimer > :nth-child(5) > span" ).html( timeArr[ 1 ] );

            // Записываем новое время
            dailyQuizTime = newTime;

            dailyQuizTimer = setTimeout( dailyQuizContinueTimer, 1000 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка таймера вопроса квиз-а
    function dailyQuizClearTimer( ) {
        try {
            if ( dailyQuizTimer !== null ) {
                clearTimeout( dailyQuizTimer );

                dailyQuizTimer = null;
                dailyQuizTime = 0;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Сброс таймера вопроса квиз-а
    function dailyQuizResetTimer( ) {
        try {
            dailyQuizClearTimer();

            $( "#pCQTimer > :nth-child(4) > span" ).html( "0" );
            $( "#pCQTimer > :nth-child(5) > span" ).html( "0" );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Показ результата прохождения квиз-а
    function dailyQuizShowResult( ) {
        try {
            // Берём текущий заработок
            let allSum = parseInt( $( "[quiz-all-sum]" ).attr( "quiz-all-sum" ) );

            // Скрываем попап
            closePopup();
            // Удаляем события задачи попап-а
            addDelDailyQuizEventsPopup( false );

            setTimeout( function() {
                // Меняем содержимое попап-а
                $( "#earn_page .popupContent" ).html( '' +
                    '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                    '' +
                    '        <div class="popupIconLarge">' +
                    '            <img src="/resources/img/earn/surprized.png" />' +
                    '        </div>' +
                    '' +
                    '        <div class="popupLabel">' +
                    '            <span class="smallLargerFontSize">' + lang.getText( "you_end_daily_quiz" ) + '</span>' +
                    '        </div>' +
                    '' +
                    '        <div class="popupSublabel">' +
                    '            <span class="smallLargerFontSize grayFontColor">' + lang.getText( "for_you" ) + '&nbsp;</span>' +
                    '' +
                    '            <span class="smallLargerFontSize grayFontColor">0</span>' +
                    '' +
                    '            <span class="smallLargerFontSize grayFontColor">&nbsp;' + lang.getText( "good_answers" ) + '.<br/>' + lang.getText( "you_get_money" ) + '&nbsp;</span>' +
                    '' +
                    '            <span class="smallLargerFontSize grayFontColor">0</span>' +
                    '' +
                    '            <span class="smallLargerFontSize grayFontColor">&nbsp;' + lang.getText( "rockets" ) + '.</span>' +
                    '        </div>' +
                    '' +
                    '        <div id="popupQuizResultItems">' +
                    '            <div>' +
                    '                <div>' +
                    '                    <span class="smallLargerFontSize greenFontColor">0</span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <span class="smallFontSize">' + lang.getText( "success" ) + '</span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div>' +
                    '                <div>' +
                    '                    <span class="smallLargerFontSize redFontColor">0</span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <span class="smallFontSize">' + lang.getText( "unsuccess" ) + '</span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div class="pQPIBlue">' +
                    '                <div>' +
                    '                    <img src="/resources/img/rocket_angle.png" />' +
                    '' +
                    '                    <span class="smallLargerFontSize">0</span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <span class="smallFontSize">' + lang.getText( "win" ) + '</span>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '' +
                    '        <a href="" target="_blank" class="btn popupBtn">' +
                    '            <span>' + lang.getText( "close" ) + '</span>' +
                    '        </a>' );

                // Если нет неверных ответов
                if ( answerCount.bad === 0 ) {
                    allSum *= dailyQuiz.goodMult;
                }

                // Пишем данные
                $( ".popupSublabel > span:nth-child( 2 ), #popupQuizResultItems > div:nth-child( 1 ) > div:nth-child( 1 ) > span" ).html( answerCount.good );
                $( ".popupSublabel > span:nth-child( 4 ), #popupQuizResultItems > div:nth-child( 3 ) > div:nth-child( 1 ) > span" ).html( allSum );
                $( "#popupQuizResultItems > div:nth-child( 2 ) > div:nth-child( 1 ) > span" ).html( answerCount.bad );

                dailyQuizStep = -1;

                // показываем поп-ап
                showHidePopup();
                // Добавляем события попап-у
                addDelEventsPopup();
                // Добавляем события результата квиз-а
                addDelDailyQuizResultEventsPopup();

                // console.log( "Старые ракеты", user.getMainUserData().balanceRockets, "добавляемые ракеты", parseInt( allSum ) );

                // У родителя подгружаем новые данные
                parent.mainPage.reloadMainUserData();

                // обновляем данные связанных страниц
                parent.mainPage.reload( "space" );
            } ,0.3 );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий кнопки при показе результата квиз-а
    function addDelDailyQuizResultEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBtn" ).on( "click", dailyQuizClose );                           // клик на кнопку
            }
            else {
                $( ".popupBtn" ).off( "click", dailyQuizClose );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие квиз-а
    function dailyQuizClose( e ) {
        try {
            try {e.preventDefault(); e.stopPropagation();} catch (e) {}

            // Удаляем события
            addDelDailyQuizResultEventsPopup( false );
            addDelDailyQuizPreviewEventsPopup( false );
            addDelDailyQuizEventsPopup( false );
            addDelDailyQuizItemsEvents( false );

            // Сбрасываем все переменные
            dailyQuizResetTimer();

            answerCount.good = 0;
            answerCount.bad = 0;
            isShowBadNotif = false;
            lastQuestExistAnswer = true;


            // закрываем попап
            closePopup();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на замену вопроса
    function dailyQuizReplaceQuest( e ) {
        try {
            // console.log( "CLICK" );

            $( ".pCQNButtons > div" ).addClass( "inactive" );

            // выключаем кнопку
            dailyQuizOnOffBtn( false );

            // Тип замены
            let typeChange = parseInt( $( e.currentTarget ).attr( "type-change" ) );

            // Если бесплатная замена
            if ( typeChange === 1 ) {
                // Отправляем данные для замены вопроса
                $.ajax({
                    url : "/apprin/v1/quiz/change_quest/",
                    data : "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id +
                        "&quest=" + ( dailyQuizStep - 2 > 0 ? dailyQuizStep - 2 : 0 ) + "&isFree=1",
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            // Обновляем данные оповещения о замене
                            dailyQuizUpdateNotif();

                            // Записываем текущий этап
                            let currentStep = dailyQuizStep;

                            // записываем новые данные квиз-а
                            dailyQuiz = resp.data;

                            // Уменьшаем этап
                            currentStep--;

                            // записываем этап
                            dailyQuizStep = currentStep;

                            // ставим индикатор замены вопроса
                            dailyQuiz[ "isChangeQuest" ] = true;

                            // убираем индикатор показа окна замены вопроса
                            isShowBadNotif = false;

                            // Уменьшаем количество неверных ответов
                            answerCount.bad--;

                            // Скрываем уведомление снизу
                            dailyQuizShowHideNotif( false );
                            // Ставим полоску
                            dailyQuizSetStep( currentStep, "current" );
                            // строим следующий этап
                            dailyQuizBuildStep();
                            // добавляем события элементам
                            addDelDailyQuizItemsEvents();
                            // запускаем таймер
                            dailyQuizStartTimer( dailyQuiz.answerTime );
                        }
                        catch ( err ) {
                            console.error(err);
                        }
                    },
                    error : function ( err ) {
                        console.error(err);
                    },
                    complete : function () {
                        $( ".pCQNButtons > div" ).removeClass( "inactive" );

                        // включаем кнопку
                        dailyQuizOnOffBtn();
                    }
                });
            }
            // Если реклама
            else if ( typeChange === 2 ) {
                // Запускаем показ
                advert.show()
                    .then((result) => {
                        // console.log( result );

                        if ( !result.done || result.error ) {
                            return;
                        }

                        // Отправляем данные для замены вопроса
                        $.ajax({
                            url : "/apprin/v1/quiz/change_quest/",
                            data : "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id +
                                "&quest=" + ( dailyQuizStep - 2 > 0 ? dailyQuizStep - 2 : 0 ) + "&isFree=0&str=" +
                                sha256( dailyQuiz.id + user.getAllUserData().uuid + ( dailyQuizStep - 2 > 0 ? dailyQuizStep - 2 : 0 ) ),
                            type : "POST",
                            success : function ( responce ) {
                                // console.log( responce );

                                try {
                                    let resp = JSON.parse( responce ); //парсим ответ сервера

                                    if ( resp.status !== "ok" ) {
                                        return;
                                    }

                                    // Обновляем данные оповещения о замене
                                    dailyQuizUpdateNotif();

                                    // Записываем текущий этап
                                    let currentStep = dailyQuizStep;

                                    // записываем новые данные квиз-а
                                    dailyQuiz = resp.data;

                                    // Уменьшаем этап
                                    currentStep--;

                                    // записываем этап
                                    dailyQuizStep = currentStep;

                                    // ставим индикатор замены вопроса
                                    dailyQuiz[ "isChangeQuest" ] = true;

                                    // убираем индикатор показа окна замены вопроса
                                    isShowBadNotif = false;

                                    // Уменьшаем количество неверных ответов
                                    answerCount.bad--;

                                    // Скрываем уведомление снизу
                                    dailyQuizShowHideNotif( false );
                                    // Ставим полоску
                                    dailyQuizSetStep( currentStep, "current" );
                                    // строим следующий этап
                                    dailyQuizBuildStep();
                                    // добавляем события элементам
                                    addDelDailyQuizItemsEvents();
                                    // запускаем таймер
                                    dailyQuizStartTimer( dailyQuiz.answerTime );
                                }
                                catch ( err ) {
                                    console.error(err);
                                }
                            },
                            error : function ( err ) {
                                console.error(err);
                            },
                            complete : function () {
                                $( ".pCQNButtons > div" ).removeClass( "inactive" );

                                // включаем кнопку
                                dailyQuizOnOffBtn();
                            }
                        });
                    })
                    .catch((result) => {
                        // console.log( result );
                    });
            }
            // Если донат
            else if ( typeChange === 3 ) {
                if ( isPay ) {
                    return;
                }

                isPay = true;

                let currency = "XTR";

                $.ajax({
                    url : "/apprin/v1/quiz/by/",
                    data : "id=" + user.getAllUserData().uuid + "&quizID=" + dailyQuiz.id +
                        "&quest=" + ( dailyQuizStep - 2 > 0 ? dailyQuizStep - 2 : 0 ) + "&curr=" + currency + "&s=1",
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                throw "Ошибка";

                                return;
                            }

                            // Если валюта звёзды
                            if ( currency.toUpperCase() === "XTR" ) {
                                // Открываем окошко оплаты
                                tg.openInvoice( resp.data.payLink );
                            }

                            // записываем UUID заказа
                            payCheckOrderUUID = resp.data.orderData.id;

                            // запускаем проверку оплаты
                            startByCheckTimer();
                        }
                        catch ( err ) {
                            console.error(err);

                            isPay = false;

                            $( ".pCQNButtons > div" ).removeClass( "inactive" );

                            // включаем кнопку
                            dailyQuizOnOffBtn();
                        }
                    },
                    error : function ( err ) {
                        console.error(err);

                        isPay = false;

                        $( ".pCQNButtons > div" ).removeClass( "inactive" );

                        // включаем кнопку
                        dailyQuizOnOffBtn();
                    },
                    complete : function () {
                    }
                });
            }
        }
        catch (e) {
            console.error(e);

            isPay = false;

            $( ".pCQNButtons > div" ).removeClass( "inactive" );

            // включаем кнопку
            dailyQuizOnOffBtn();
        }
    }

    // Запуск таймера проверки оплаты (ракеты)
    function startByCheckTimer( ) {
        try {
            clearByCheckTimer( );

            currPayTime = 0;

            payTimer = setTimeout( continueByCheckTimer, payTime * 1000 );
        }
        catch (e) {
            console.error(e);

            isPay = false;
        }
    }
    // Очистка таймера проверки оплаты (ракеты)
    function clearByCheckTimer( ) {
        try {
            if ( payTimer !== null ) {
                clearTimeout( payTimer );

                payTimer = null;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение таймера проверки оплаты (ракеты)
    function continueByCheckTimer( ) {
        try {
            clearByCheckTimer( );

            // Проверяем
            $.ajax({
                url : "/apprin/v1/quiz/byCheck/",
                data : "id=" + user.getAllUserData().uuid + "&orderID=" + payCheckOrderUUID,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если оплата успешна
                        if ( resp.data.isOk ) {
                            // Обновляем данные оповещения о замене
                            dailyQuizUpdateNotif();

                            // Записываем текущий этап
                            let currentStep = dailyQuizStep;

                            // записываем новые данные квиз-а
                            dailyQuiz = resp.data;

                            // Уменьшаем этап
                            currentStep--;

                            // записываем этап
                            dailyQuizStep = currentStep;

                            // ставим индикатор замены вопроса
                            dailyQuiz[ "isChangeQuest" ] = true;

                            // убираем индикатор показа окна замены вопроса
                            isShowBadNotif = false;

                            // Уменьшаем количество неверных ответов
                            answerCount.bad--;

                            // Скрываем уведомление снизу
                            dailyQuizShowHideNotif( false );
                            // Ставим полоску
                            dailyQuizSetStep( currentStep, "current" );
                            // строим следующий этап
                            dailyQuizBuildStep();
                            // добавляем события элементам
                            addDelDailyQuizItemsEvents();
                            // запускаем таймер
                            dailyQuizStartTimer( dailyQuiz.answerTime );

                            $( ".pCQNButtons > div" ).removeClass( "inactive" );

                            // включаем кнопку
                            dailyQuizOnOffBtn();

                            isPay = false;
                        }
                        else {
                            // Если время меньше или равно максимума
                            if ( currPayTime + payTime <= maxPayTime * 60 ) {
                                // Снова запускаем таймер
                                payTimer = setTimeout( continueByCheckTimer, payTime * 1000 );
                            }
                            else {
                                // Показываем оповещение
                                showHideNotifLine( true, "Error pay", "error.png" );

                                // Скрываем попап
                                addDelEventsPopup( false );
                                showHidePopup( false );

                                isPay = false;

                                $( ".pCQNButtons > div" ).removeClass( "inactive" );

                                // включаем кнопку
                                dailyQuizOnOffBtn();
                            }
                        }
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            isPay = true;
        }
    }

    // Показ/Скрытие оповещения снизу квиз-а
    function dailyQuizShowHideNotif( isShow = true ) {
        try {
            if ( isShow ) {
                isShowBadNotif = true;

                $( ".pCQNotif" ).addClass( "show" );
            }
            else {
                isShowBadNotif = false;

                $( ".pCQNotif" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Обновление оповещения снизу квиз-а
    function dailyQuizUpdateNotif( ) {
        try {
            // Количество доступных бесплатных замен
            let freeChanges = dailyQuiz.maxFreeChangeNumbers - dailyQuiz.freeChangeNumbers;

            // Если замены есть
            if ( freeChanges > 0 ) {
                // Меняем количество бесплатных замен
                $( ".pCQNButtons > :last-child > :last-child" ).html( freeChanges + " " + lang.getText( "raz" ) );

                // Ставим тип замены. 3 - донат
                $( ".pCQNButtons > :first-child" ).attr( "type-change", "3" );
                // Ставим размер доната
                $( ".pCQNButtons > :first-child > :last-child" ).html( formatNumber( dailyQuiz.donatSum ) + " STARS" );

                // Ставим тип замены. 1 - бесплатно
                $( ".pCQNButtons > :last-child" ).attr( "type-change", "1" );
            }
            else {
                // Ставим тип замены. 3 - донат
                $( ".pCQNButtons > :first-child" ).attr( "type-change", "3" );
                // Ставим размер доната
                $( ".pCQNButtons > :first-child > :last-child" ).html( formatNumber( dailyQuiz.donatSum ) + " STARS" );

                // Делаем альтернативный вариант
                $( ".pCQNButtons > :last-child > :first-child" ).html( lang.getText( "advertizing" ) );
                $( ".pCQNButtons > :last-child > :last-child" ).html( "10 " + lang.getText( "seconds" ) );

                // Ставим тип замены. 2 - реклама
                $( ".pCQNButtons > :last-child" ).attr( "type-change", "2" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Построение задач
    function buildTasks() {
        try {
            let tasks = user.getAvailableTasks();

            let items = $( '<div></div>' );

            for ( let task of tasks ) {
                let item = $( '<div>' +
                    '<div class="earnItem animScale" is_check="0">' +
                    '            <div class="eIIcon">' +
                    '                <img src=""/>' +
                    '            </div>' +
                    '' +
                    '            <div class="eICenter">' +
                    '                <div>' +
                    '                    <span class=""></span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <span class="goldTransparentFontColor smallFontSize"></span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div class="eIRight">' +
                    '                <div class="eIRActive show">' +
                    '                    <img class="eIRANoScaleX" src="/resources/img/rocket_angle.png"/>' +
                    '' +
                    '                    <div>' +
                    '                        <span class="blueGradientFont smallLargerFontSize"></span>' +
                    '                    </div>' +
                    '' +
                    '                    <div>' +
                    '                        <img src="/resources/img/arrow_gray.svg"/>' +
                    '                    </div>' +
                    '                </div>' +
                    '' +
                    '                <div class="eIREnd">' +
                    '                    <div>' +
                    '                        <img src="/resources/img/earn/end.png" />' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>' );

                $( ".earnItem", item ).attr({
                    "task-id" : task.id
                });

                $( ".eIIcon > img", item ).attr( "src", "/resources/img/earn/icons/" + (task.icon !== null ? task.icon : task.type + ".svg") );

                // Тип задачи
                let type = "";

                switch ( task.type ) {
                    case 1 :
                        type = "Change username"

                        break;
                    case 2 :
                        type = "Subscribe"

                        break;
                    case 3 :
                        type = "Subscribe"

                        break;
                    case 4 :
                        type = "Open link"

                        break;
                    case 5 :
                        type = "Retweet"

                        break;
                }

                $( ".eIRActive > div:nth-child(2) > span", item ).html( task.sum );
                $( ".eICenter > div:last-child > span", item ).html( type );
                $( ".eICenter > div:first-child > span", item ).html( task.data.title );

                // Клик на элемент
                $( ".earnItem", item ).on( "click", taskClick );

                // Добавляем элемент к другим
                items.append( item.contents() );
            }

            $( "#earn_page #cItems" ).append( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка данных задач
    function clearTasks() {
        try {
            $( "#earn_page  #cItems > *" ).remove();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на кнопку у задачи
    function taskClick( e ) {
        try {
            // Заменяем содержимое попап-а
            $( "#earn_page .popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupIcon">' +
                '            <img src="/resources/img/earn/icons/2.svg" />' +
                '        </div>' +
                '' +
                '        <div class="popupLabel">' +
                '            <span class="smallLargerFontSize"></span>' +
                '        </div>' +
                '' +
                '        <a href="" target="_blank" class="btn popupBtnLink hide">' +
                '            <span class="">' + lang.getText( "go" ) + '</span>' +
                '        </a>' +
                '' +
                '        <div class="popupSum">' +
                '            <img src="/resources/img/rocket_angle.png" />' +
                '' +
                '            <span class="blueGradientFont smallLargerFontSize">0</span>' +
                '        </div>' +
                '' +
                '        <a href="" target="_blank" class="btn popupBtn">' +
                '            <span>' + lang.getText( 'go' ) + '</span>' +
                '        </a>' );

            let item = $( e.currentTarget );

            let taskID = parseInt( item.attr( "task-id" ) );

            // console.log( taskID );

            let tasks = user.getAvailableTasks();

            let taskData = getItemByKeyValue( tasks, "id", taskID );

            // console.log( taskData );

            if ( taskData === null ) {
                return;
            }

            currentCheckTask = $.extend( {}, true, taskData );

            // Ставим статус проверки.
            // -1 - идёт обмен с сервером
            // 0 - надо нажать на кнопку для перехода или чего-то ещё.
            // 1 - можно показать кнопку проверки.
            // 2 - ошибка после проверки
            currentCheckTask[ "statusCheck" ] = 0;

            $( ".popupIcon > img" ).attr( "src", "/resources/img/earn/icons/" + (currentCheckTask.icon !== null ? currentCheckTask.icon : currentCheckTask.type + ".svg") );

            // Заголовок
            let label = lang.getText( "task_type_" + currentCheckTask.type + "_label" );

            /*switch ( currentCheckTask.type ) {
                case 1 :
                    label = "Измени username"

                    break;
                case 2 :
                    label = "Подпишись на канал"

                    break;
                case 3 :
                    label = "Подпишись на группу"

                    break;
                case 4 :
                    label = "Перейди по ссылке"

                    break;
                case 5 :
                    label = "Сделай ретвитт"

                    break;
            }*/

            // Если тип подписка на канал/группу ИЛИ переход по ссылке ИЛИ ретвитт
            if ( currentCheckTask.type === 2 || currentCheckTask.type === 3 || currentCheckTask.type === 4 || currentCheckTask.type === 5 ) {
                label += "<br/>" + currentCheckTask.data.title;
            }

            // Если тип подписка на канал/группу
            if ( currentCheckTask.type === 2 || currentCheckTask.type === 3 ) {
                // На кнопке ставим ссылку
                $( ".popupBtn, .popupBtnLink" ).attr( "href", currentCheckTask.data.link );
            }

            // Если тип переход по ссылке ИЛИ ретвитт
            if ( currentCheckTask.type === 4 || currentCheckTask.type === 5 ) {
                // На кнопке ставим нужную ссылку
                $( ".popupBtn, .popupBtnLink" ).attr( "href", currentCheckTask.data.link !== undefined && currentCheckTask.data.link !== null ? currentCheckTask.data.link : "#" );
            }

            $( ".popupLabel > span" ).html( label );
            $( ".popupSum > span" ).html( currentCheckTask.sum );

            // Показываем попап
            showHidePopup();
            // Добавляем события попап-у
            addDelEventsPopup();
            // Добавляем события задачи попап-а
            addDelTaskEventsPopup();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий задач попап-а
    function addDelTaskEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBtn" ).on( "click", popupButtonTaskClick );                           // клик на кнопку
            }
            else {
                $( ".popupBtn" ).off( "click", popupButtonTaskClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на кнопку popup-а при выполнении задания
    function popupButtonTaskClick( e ) {
        try {
            // console.log( currentCheckTask );

            // текущий статус проверки
            let currentCheckStatus = currentCheckTask.statusCheck;

            // console.log( currentCheckStatus );

            // Если идёт какой-то обмен с сервером
            if ( currentCheckStatus === -1 ) {
                return;
            }

            // Если статус 0 - надо нажать на кнопку для перехода или чего-то ещё. То есть первый раз нажали на нижнюю кнопку Перейти
            if ( currentCheckStatus === 0 ) {
                // Показываем кнопку перехода
                $( ".popupBtnLink" ).removeClass( "hide" );

                // Меняем кнопку на нужную
                $( ".popupBtn > span" ).html( lang.getText( "check" ) );

                // Ставим статус 1 - можно показать кнопку проверки
                currentCheckTask.statusCheck = 1;

                return;
            }

            // Если статус 1 - можно показать кнопку проверки. То есть было нажатие кнопки проверки
            if ( currentCheckStatus === 1 ) {
                e.stopPropagation();
                e.preventDefault();

                // Ставим статус 1 - общение с сервером
                currentCheckTask.statusCheck = -1;

                // Отправляем выполнение задачи на проверку
                $.ajax({
                    url : "/apprin/v1/user/set_end_task/",
                    data : "id=" + user.getAllUserData().uuid + "&taskID=" + currentCheckTask.id,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                // Показываем оповещение сверху
                                showHideNotifLine( true, lang.getText( "task_no_check" ), "error.png", -1 );

                                return;
                            }

                            // Показываем оповещение сверху
                            showHideNotifLine( true, lang.getText( "task_complete" ), "end.png", currentCheckTask.sum );


                            // Удаляем задание из списка
                            $( "[task-id=\"" + currentCheckTask.id + "\"]" ).remove();

                            // Закрываем окошко
                            closePopup();

                            // Загружаем новые данные юзера
                            user.loadMainData();

                            // У родителя подгружаем новые данные
                            mainPage.reloadMainUserData();
                        }
                        catch ( err ) {
                            console.error(err);
                        }
                    },
                    error : function ( err ) {
                        console.error(err);

                        // Ставим статус обратно
                        currentCheckTask.statusCheck = currentCheckStatus;
                    },
                    complete : function () {
                    }
                });
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // НЕ УНИВЕРСАЛЬНЫЙ КОД
            // TODO: check or delete comment #10
            if ( dailyQuiz?.[ "step" ] >= 0 && !confirm( "Are you shure?" ) ) {
                return;
            }

            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );

            // Удаляем события задачи попап-а
            addDelTaskEventsPopup( false );

            // Скрываем кнопку перехода
            $( ".popupBtnLink" ).addClass( "hide" );
            // Меняем надпись на старую
            $( ".popupBtn > span" ).html( lang.getText( "go" ) );

            // Удаляем стили ненужные. ЭТО НЕ УНИВЕРСАЛЬНЫЙ КОД
            $( "#earn_page .popupContent" ).removeClass( "popupContentSmallPadding" );

            // Срасываем таймер
            dailyQuizResetTimer();
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие всплывающего текста
    function titleShowHide( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".tips" ).addClass( "titleShow" );
            }
            else {
                $( ".tips" ).removeClass( "titleShow" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий с элементов, на которых надо показать подсказку
    function titleAddDelEvents( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( "[title-text]" ).on( "click", titleElementClick );            // Клик на элемент
                $( document ).on( "click", titleDocumentClick );                    // Клик на документ
            }
            else {
                $( "[title-text]" ).off( "click", titleElementClick );            // Клик на элемент
                $( document ).off( "click", titleDocumentClick );                    // Клик на документ
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на элемент, на котором нужно показать всплывающий текст
    function titleElementClick( e ) {
        try {
            // скрываем
            titleShowHide( false );

            let text = $( e.currentTarget ).attr( "title-text" );
            let targetId = $( e.currentTarget ).attr( "target-id" ) || 'title';
            let title = $( `#${targetId}` );

            // Пишем нужный текст
            $( "span", title ).html( text );

            // размеры блока подсказки
            let titleSize = {
                "width" : title.outerWidth(),
                "height" : title.outerHeight()
            };
            // Координаты подсказки
            let coords = {
                "x" : $( e.currentTarget ).offset().left - (titleSize.width * 0.82),
                "y" : $( e.currentTarget ).offset().top - (titleSize.height * 1.1)
            };

            // Если задан отступ слева
            if ( $( e.currentTarget ).attr( "title-left-margin" ) !== undefined ) {
                coords.x = "calc(" + coords.x + "px - " + $( e.currentTarget ).attr( "title-left-margin" ) + ")";
            }
            else {
                coords.x = coords.x + "px"
            }

            // Если задан отступ сверху
            if ( $( e.currentTarget ).attr( "title-top-margin" ) !== undefined ) {
                coords.y = "calc(" + coords.y + "px - " + $( e.currentTarget ).attr( "title-top-margin" ) + ")";
            }
            else {
                coords.y = coords.y + "px"
            }

            title.css( {
                "left" : coords.x,
                "top" : coords.y
            } );

            // Показываем
            titleShowHide();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на документ
    function titleDocumentClick( e ) {
        try {
            // console.log( e );

            // Если объект клика связан с подсказкой
            if ( $( e.target ).attr( "title-text" ) !== undefined || $( e.target ).parents( "[title-text]" ).length > 0 ) {
                return;
            }

            // скрываем
            titleShowHide( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ первой инструкции
    function runFirstInstr( stepInstr = 1 ) {
        try {
            // Пишем контент
            $( "#earn_page .popupContent" ).html( '' +
                '        <div id="pCFirstInstr">' +
                "            <div id=\"pCFIImg\" style=\"background-image: url(/resources/img/instruction/" + stepInstr + ".png);\"></div>" +
                '' +
                '            <span class="smallLargerFontSize">' + lang.getText( "first_instr_text_" + stepInstr ) + '</span>' +
                '        </div>' +
                '' +
                '        <a href="#" target="_blank" class="btn popupBtn" instr-step="' + stepInstr + '">' +
                '            <span>' + ( stepInstr !== 6 ? lang.getText( "next" ) : lang.getText( "fly" ) ) + '</span>' +
                '        </a>' ).addClass( "mb" );

            // Показываем
            showHidePopup();

            // Клик на кнопку
            $( ".popupBtn" ).on( "click", runFirstInstrBtnClick );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на кнопку первой инструкции
    function runFirstInstrBtnClick( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            let stepsItem = {
                "1" : "main",
                "2" : "life",
                "3" : "space",
                "4" : "friends",
                "5" : "earn",
                "6" : "life"
            };
            let stepInstr = parseInt( $( e.currentTarget ).attr( "instr-step" ) );

            stepInstr++;

            // Если последний этап
            if ( stepInstr === 7 ) {
                // Закрываем попап
                closePopup();

                // Записываем настройки
                $.ajax({
                    url : "/apprin/v1/settings/setAllFirst/",
                    data : "id=" + user.getAllUserData().uuid,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            system.setSettings( "isEndFirstInstr", true );

                            // Переходим по нужному адресу
                            window.location.href = $("[nav-item=\"life\"]").attr( "href_custom" );
                        }
                        catch ( err ) {
                            console.error(err);
                        }
                    },
                    error : function ( err ) {
                        console.error(err);
                    },
                    complete : function () {

                    }
                });
            }
            else {
                // Если не последний пункт
                if ( stepInstr !== 6 ) {
                    // Переходим по нужному адресу
                    window.location.href = $("[nav-item=\"" + stepsItem[stepInstr.toString()] + "\"]").attr( "href_custom" );
                }
                else {
                    // Закрываем попап
                    closePopup();

                    setTimeout( function () {
                        // Снова показываем инструкцию
                        runFirstInstr( stepInstr );
                    }, 500 );
                }
            }
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию страницы заработка
$( window ).on( "load", earnPage.init );