let tasksPage = new tasksPageFunc();

function tasksPageFunc () {
    let dailyTask = null;                                   // данные ежедневной задачи. Если null, то доступной к выполнению задачи нет
    let currentModal = 0;                                   // текущая модалка. 0 - ничего, 1 - ежедневная задача, 2 - обычная задача

    function init() {
        try {
            nav.selectMenuItem( "tasks" );

            addEvents();

            // Чистим ежедневную задачу
            clearDailyTask ();

            // Загружаем данные о ежедневной задаче
            loadDailyTask();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( document ).on( "dailyTaskLoadSuccess", buildDailyTask );               // Успешное завершение загрузки ежедневной задачи

            $( document ).on( "modalBuild", buildModal );                             // Построение модального окна, но не показ на странице
            $( document ).on( "modalClose", closedModal );                            // Закрытие модального окна
        }
        catch (e) {
            console.error(e);
        }
    }

    // Очистка ежедневной задачи
    function clearDailyTask() {
        try {
            $( "#cDailyTask" ).remove();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка данных ежедневной задачи
    function loadDailyTask( ) {
        try {
            $.ajax({
                url : "/apprin/v1/tasks/load_daily/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // записываем данные задачи
                        dailyTask = resp.data;

                        $( document ).trigger( "dailyTaskLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);

                        $( document ).trigger( "dailyTaskLoadInvalid" );
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    //рассылаем событие завершения загрузки
                    $( document ).trigger( "dailyTaskLoadEnd" );
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }
    // Построение данных ежедневной задачи
    function buildDailyTask( e ) {
        try {
            let item = $( '<div>' +
                '<div id="cDailyTask">' +
                '<div id="cDTLabel">' +
                '            <span class="smallFontSize">ЕЖЕДНЕВНАЯ ЗАДАЧА</span>' +
                '        </div>' +
                '' +
                '        <div id="cDTData">' +
                '            <img src="/resources/img/earn_larg.png" />' +
                '' +
                '            <span></span>' +
                '' +
                '            <div id="dailyBtnStart" class="btn">' +
                '                <span>start</span>' +
                '            </div>' +
                '        </div>' +
                '</div>' +
                '</div>' );

            $( "#cDTData > span", item ).html( dailyTask.sum );

            // Событие клика на кнопку
            $( "#dailyBtnStart", item ).on( "click", showDaily );

            // Выводим задачу на страницу
            $( "#pageHead" ).after( item.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Показ ежедневной задачи
    function showDaily( e ) {
        try {
            currentModal = 1;

            modal.showModal( null, "", {modal : "task_daily"} );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Построение данных модалки ежедневной задачи
    function buildDailyModal( ) {
        try {
            // Если есть картинка
            if ( dailyTask.img !== null ) {
                $( ".modalContent > [task-step=\"1\"] > .mTImg" ).css( "background", "url(\"/resources/img/tasks/daily/" + dailyTask.img + "\") no-repeat center top" );
            }
            else {
                // Удаляем элемент с картинкой
                $( ".modalContent > [task-step=\"1\"] > .mTImg" ).remove();
            }

            $( ".modalContent > [task-step=\"1\"] > .mTLabel > span" ).html( dailyTask.question );

            let items = $( '<div></div>' );

            // Перебираем варианты ответов
            for ( let answerIndex in dailyTask.answers.answers ) {
                let item = $( '<div>' +
                    '<div class="mTIBtn btn">' +
                    '            <span></span>' +
                    '        </div>' +
                    '</div>' )

                // Если предпоследний элемент
                if ( parseInt( answerIndex ) % 2 === 0 && parseInt( answerIndex ) === dailyTask.answers.answers.length - 2 ) {
                    $( ".mTIBtn", item ).attr( "btn-prelast", "1" );
                }

                // Пишем атрибуты копке
                $( ".mTIBtn", item ).attr( "btn-index", answerIndex );

                // Меняем видимые элементы
                $( ".mTIBtn > span", item ).html( dailyTask.answers.answers[ answerIndex ] );

                $( ".mTIBtn", item ).on( "click", dailyTaskAnswerClick );           // Клик на вариант ответа

                items.append( item.contents() );
            }

            // Выводим кнопки выбора
            $( ".modalContent > [task-step=\"1\"] > .mTItems" ).html( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на вариант ответа
    function dailyTaskAnswerClick( e ) {
        try {
            let answerIndex = parseInt( $(e.currentTarget).attr( "btn-index" ) );

            // Если в текущих ответах нет такого
            if ( !dailyTask.answers.answers.hasOwnProperty( answerIndex ) ) {
                return;
            }

            // console.log( answerIndex );

            // Отправляем на проверку
            $.ajax({
                url : "/apprin/v1/tasks/check_daily/",
                data : "id=" + user.getAllUserData().uuid + "&taskID=" + dailyTask.id + "&answer=" + answerIndex,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        let resultAnswer = resp.data;

                        // Скрываем первый этап
                        $( ".modalContent > [task-step=\"1\"]" ).removeClass( "modalTaskStepShow" );

                        let newStep = 3;

                        // Если ответ правильный
                        if ( resultAnswer.isGood ) {
                            newStep = 2;
                        }

                        // Если есть картинка
                        if ( dailyTask.img !== null ) {
                            $( ".modalContent > [task-step=\"" + newStep + "\"] > .mTImg" ).css( "background", "url(\"/resources/img/tasks/daily/" + dailyTask.img + "\") no-repeat center top" );
                        }
                        else {
                            // Удаляем элемент с картинкой
                            $( ".modalContent > [task-step=\"" + newStep + "\"] > .mTImg" ).remove();
                        }

                        $( ".modalContent > [task-step=\"" + newStep + "\"] > .mTLabel > span" ).html( dailyTask.question );
                        $( ".modalContent > [task-step=\"" + newStep + "\"] > .mTText > span" ).html( newStep === 2 ? dailyTask.goodAnswerResult : dailyTask.badAnswerResult );

                        $( ".modalContent > [task-step=\"" + newStep + "\"] * .mTBComplete" ).on( "click", dailyTaskCompleteClick );           // Клик на закрытие

                        $( ".modalContent > [task-step=\"" + newStep + "\"]" ).addClass( "modalTaskStepShow" );

                        // удаляем задачу
                        clearDailyTask();
                    }
                    catch ( err ) {
                        console.error(err);

                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {

                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на закрытие
    function dailyTaskCompleteClick( e ) {
        try {
            // закрываем модалку
            modal.closeModal();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Построение модалки
    function buildModal( e ) {
        try {
            // Если модалка ежедневной задачи
            if ( currentModal === 1 ) {
                buildDailyModal();
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие модалки
    function closedModal( e ) {
        try {
            currentModal = 0;
        }
        catch (e) {
            console.error(e);
        }
    }

    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию страницы задач
$( window ).on( "load", tasksPage.init );
