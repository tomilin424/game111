let friendsPage = new friendsPageFunc();

function friendsPageFunc () {
    let settingsStorageKey = "settings";
    let referalsPayStorageKey = "referalsPay";

    let page = 1;                                   // Текущая страница рефералов
    let isPageLoad = false;                         // Индикатор того, что сейчас идёт загрузка рефералов страницы

    let payData = null;                             // Данные о вознаграждениях за рефералов

    function init() {
        try {
            nav.selectMenuItem( "friends" );

            // Удаляем рефералов
            clearReferals();
            // Удаляем лиги
            clearLeagues();

            addEvents();

            // запускаем загрузку данных о вознаграждениях
            loadReferalsPayData();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( "#inviteBtn" ).on( "click", inviteClick );                                     // Клик на кнопку инвайта

            $( "#friends_page #cItems" ).on( "scroll", scroll );

            $( "#fTLeaguesBtn" ).on( "click", bonusesShow );                                  // Клик на кнопку перехода к лигам
            $( "#inviteBonuses" ).on( "click", inviteClick );                             // Клик на кнопку приглашения в лигах

            // Готовность ТГ объекта
            $( document ).on( "tgReady", tgReady );

            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", start );                                             // Загрузка данных юзера

            $( document ).on( "userReferalsDataStorageSuccess userReferalsDataLoadSuccess", buildReferals );                 // Успешное завершение загрузки данных рефералов

            $( document ).on( "settingsLoadSuccess", settingsLoad );                    // Загрузились настройки юзера
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузились настройки юзера
    function settingsLoad( e ) {
        try {
            let settings = JSON.parse( localStorage.getItem( settingsStorageKey ) );

            // Если не было первой инструкции
            if ( !settings.isEndFirstInstr ) {
                // Запускаем шаг инструкции
                runFirstInstr( 4 );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Запуск
    function start( e ) {
        try {
            // Запускаем загрузку рефералов первой страницы
            user.loadReferalsData( page );
        }
        catch (e) {
            console.error(e);
        }
    }

    //Готовность ТГ объекта
    function tgReady() {
        try {
            // console.log("TG" , tg );

            tg.BackButton.isVisible = false;
            tg.BackButton.hide();
        }
        catch (e) {
            console.error(e);
        }
    }


    // Клик на кнопку инвайта
    function inviteClick() {
        try {
            let text = "\n\n" + lang.getText( "invite_text" ).replaceAll("<br/>", "\n");
            let link = "https://t.me/musk_crypto_bot?start=" + user.getMainUserData().user_id;
            let shareURL = "https://t.me/share/url?url=" + link + "&text=" + encodeURIComponent( text );

            tg.openTelegramLink( shareURL );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Прокрутка страницы
    function scroll ( e ) {
        try {
            var scrollHeight = $( "#friends_page #cItems" ).prop('scrollHeight');
            var divHeight = $( "#friends_page #cItems" ).height();
            var scrollerEndPoint = scrollHeight - divHeight;

            var divScrollerTop =  $( "#friends_page #cItems" ).scrollTop();

            if ( !isPageLoad && Math.abs( divScrollerTop - scrollerEndPoint ) <= 50 ) {
                isPageLoad = true;

                page++;

                // Загружаем рефералов
                user.loadReferalsData( page );
            }
        }
        catch (e) {
            console.error(e);
        }
    }


    // Загрузка данных о вознаграждениях
    function loadReferalsPayData ( ) {
        try {
            if ( localStorage.getItem( referalsPayStorageKey ) !== undefined && localStorage.getItem( referalsPayStorageKey ) !== null ) {
                let storageData = JSON.parse( localStorage.getItem( referalsPayStorageKey ) );

                // Записываем данные вознаграждений
                payData = storageData;

                // Строим обычное вознаграждение
                parseArrayToElementData( payData.normal );

                // Строим вознаграждения по лигам
                buildLeagues();

                return;
            }

            // Грузим данные рефералов
            $.ajax({
                url : "/apprin/v1/friends/load_referals_pay_data/",
                data : "",
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Записываем данные вознаграждений
                        payData = resp.data;

                        // Строим обычное вознаграждение
                        parseArrayToElementData( payData.normal );

                        // Строим вознаграждения по лигам
                        buildLeagues();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            return null;
        }
    }

    // Построение данных лиг
    function buildLeagues() {
        try {
            let leagues = payData.leagues;

            // console.log( leagues );

            let items = $( '<div></div>' );

            for ( let league of leagues ) {
                let item = $( '<div>' +
                    '<div class="fBIItem">' +
                    '                <div>' +
                    '                    <img src="/resources/img/leagues/1.png" />' +
                    '' +
                    '                    <span>Mars</span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <div>' +
                    '                        <img src="/resources/img/rocket_hor.webp" />' +
                    '' +
                    '                        <span class="blueGradientFont">0</span>' +
                    '                    </div>' +
                    '' +
                    '                    <div>' +
                    '                        <img src="/resources/img/earn_larg.svg" />' +
                    '' +
                    '                        <span class="goldGradientFont">+0</span>' +
                    '                    </div>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <div>' +
                    '                        <img src="/resources/img/rocket_hor.webp" />' +
                    '' +
                    '                        <span class="blueGradientFont">0</span>' +
                    '                    </div>' +
                    '' +
                    '                    <div>' +
                    '                        <img src="/resources/img/earn_larg.svg" />' +
                    '' +
                    '                        <span class="goldGradientFont">+0</span>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '</div>' );

                $( ".fBIItem > :first-child > img", item ).attr( "src", "/resources/img/leagues/" + league.id + ".png" );
                $( ".fBIItem > :first-child > span", item ).html( league.name );

                $( ".fBIItem > :nth-child(2) > :first-child > span", item ).html( league.rockets );
                $( ".fBIItem > :nth-child(2) > :last-child > span", item ).html( "+" + formatNumber( league.currency ) );

                $( ".fBIItem > :last-child > :first-child > span", item ).html( league.rocketsPremium );
                $( ".fBIItem > :last-child > :last-child > span", item ).html( "+" + formatNumber( league.currencyPremium ) );

                // Добавляем элемент к другим
                items.append( item.contents() );
            }

            $( "#fBItems" ).append( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка данных лиг
    function clearLeagues() {
        try {
            $( "#fBItems > *" ).remove();
        }
        catch (e) {
            console.error(e);
        }
    }
    // Показ лиг
    function bonusesShow() {
        try {
            $( "[friends-main]" ).addClass( "hide" );
            $( "[friends-bonuses]" ).addClass( "show" );

            setTimeout( function() {
                $( "[friends-bonuses] > *" ).addClass( "animScale" );
            }, 200 );

            // tg.BackButton.isVisible = true;
            tg.BackButton.show();
            tg.BackButton.onClick( ( ) => {
                // console.log( "CLICK" );

                // Закрываем лиги
                bonusesBack()
            } );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Возвращение назад из лиг
    function bonusesBack() {
        try {
            tg.BackButton.isVisible = false;
            tg.BackButton.hide();

            $( "[friends-bonuses]" ).removeClass( "show" );
            $( "[friends-bonuses] > *" ).removeClass( "animScale" );

            setTimeout( function() {
                $( "[friends-main]" ).removeClass( "hide" );
            }, 300 );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Добавление данных рефералов
    function buildReferals( e ) {
        try {
            // console.log( "Загружены рефералы", e );

            // Если первая страница И была загрузка с сервера
            if ( page === 1 && e.type === "userReferalsDataLoadSuccess" ) {
                // Удаляем старых рефералов
                clearReferals();
            }

            isPageLoad = false;

            let referals = user.getReferalsData();
            let referralsCount = user.getReferralsCount();

            let items = $( '<div></div>' );

            for ( let referal of referals ) {
                let item = $( '<div>' +
                    '<div class="cIItem">' +
                    '            <div class="cIIIcon">' +
                    '                <span class="largerFontSize">T</span>' +
                    '            </div>' +
                    '' +
                    '            <div class="cIIInfo">' +
                    '                <div>' +
                    '                    <span></span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <div style="flex-basis: 33%">' +
                    '                        <img src="/resources/img/rocket_hor.webp" />' +
                    '' +
                    '                        <span class="blueGradientFont" id="rocket_refer">0</span>' +
                    '                    </div>' +
                    '' +
                    '                    <div style="flex-basis: 33%">' +
                    '                        <img src="/resources/img/earn_larg.svg" />' +
                    '' +
                    '                        <span class="goldGradientFont" id="earn_refer">+0</span>' +
                    '                    </div>' +
                    '' +
                    '                    <div id="league_refer">' +
                    '                        <img />' +
                    '' +
                    '                        <span data-input-key="leagueName"></span>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>' );

                let username = referal.username === null ? "Nothing" : referal.username;

                $( ".cIIIcon > span", item ).html( username.substring(0, 1).toUpperCase() );
                $( ".cIIInfo > :first-child > span", item ).html( username.length > 20 ? referal.username.substring(0, 18) + '...' : username );
                $( ".cIIInfo > :last-child span#rocket_refer", item ).html( referal.rockets );
                $( ".cIIInfo > :last-child span#earn_refer", item ).html( "+" + referal.earn );

                $( ".cIIInfo > :last-child > div#league_refer > img", item ).attr( "src", `/resources/img/leagues/${referal.leaguesId}.png` );
                $( ".cIIInfo > :last-child > div#league_refer > span", item ).attr( "league-rating", referal.leaguesId );
                $( ".cIIInfo > :last-child > div#league_refer > span", item ).text( referal.leagueName );

                // console.log( $( ".cIIInfo > :last-child > :first-child > span", item ) );

                // Добавляем элемент к другим
                items.append( item.contents() );
            }

            $( "#friends_page #cItems" ).append( items.contents() );
            $( "#friends_page #friends_count" ).text( referralsCount );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Очистка данных рефералов
    function clearReferals() {
        try {
            $( "#friends_page #cItems > *" ).remove();
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // НЕ УНИВЕРСАЛЬНЫЙ КОД
            currentCheckTask = null;

            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );

            // Удаляем события задачи попап-а
            addDelTaskEventsPopup( false );

            // Скрываем кнопку перехода
            $( ".popupBtnLink" ).addClass( "hide" );
            // Меняем надпись на старую
            $( ".popupBtn > span" ).html( lang.getText( "go" ) );

            // Удаляем стили ненужные. ЭТО НЕ УНИВЕРСАЛЬНЫЙ КОД
            $( ".popupContent" ).removeClass( "popupContentSmallPadding" );

            // Срасываем таймер
            dailyQuizResetTimer();
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ первой инструкции
    function runFirstInstr( stepInstr = 1 ) {
        try {
            // Пишем контент
            $( ".popupContent" ).html( '' +
                '        <div id="pCFirstInstr">' +
                "            <div id=\"pCFIImg\" style=\"background-image: url(/resources/img/instruction/" + stepInstr + ".png);\"></div>" +
                '' +
                '            <span class="smallLargerFontSize">' + lang.getText( "first_instr_text_" + stepInstr ) + '</span>' +
                '        </div>' +
                '' +
                '        <a href="#" target="_blank" class="btn popupBtn" instr-step="' + stepInstr + '">' +
                '            <span>' + ( stepInstr !== 6 ? lang.getText( "next" ) : lang.getText( "fly" ) ) + '</span>' +
                '        </a>' ).addClass( "mb" );

            // Показываем
            showHidePopup();

            // Клик на кнопку
            $( ".popupBtn" ).on( "click", runFirstInstrBtnClick );
        }
        catch (e) {
            console.error(e);
        }
    }
    // Клик на кнопку первой инструкции
    function runFirstInstrBtnClick( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            let stepsItem = {
                "1" : "main",
                "2" : "life",
                "3" : "space",
                "4" : "friends",
                "5" : "earn",
                "6" : "life"
            };
            let stepInstr = parseInt( $( e.currentTarget ).attr( "instr-step" ) );

            stepInstr++;

            // Если последний этап
            if ( stepInstr === 7 ) {
                // Закрываем попап
                closePopup();

                // Записываем настройки
                $.ajax({
                    url : "/apprin/v1/settings/setAllFirst/",
                    data : "id=" + user.getAllUserData().uuid,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            system.setSettings( "isEndFirstInstr", true );

                            // Переходим по нужному адресу
                            window.location.href = $("[nav-item=\"life\"]").attr( "href" );
                        }
                        catch ( err ) {
                            console.error(err);
                        }
                    },
                    error : function ( err ) {
                        console.error(err);
                    },
                    complete : function () {

                    }
                });
            }
            else {
                // Если не последний пункт
                if ( stepInstr !== 6 ) {
                    // Переходим по нужному адресу
                    window.location.href = $("[nav-item=\"" + stepsItem[stepInstr.toString()] + "\"]").attr( "href" );
                }
                else {
                    // Закрываем попап
                    closePopup();

                    setTimeout( function () {
                        // Снова показываем инструкцию
                        runFirstInstr( stepInstr );
                    }, 500 );
                }
            }
        }
        catch (e) {
            console.error(e);
        }
    }



    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию страницы рефералов
$( window ).on( "load", friendsPage.init );
