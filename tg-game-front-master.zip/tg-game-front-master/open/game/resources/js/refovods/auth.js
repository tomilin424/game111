let authPage = new authPageFunc();

function authPageFunc () {
    let isAuth = false;
    let notifLineTimer = null;                  // Таймер скрытия линейного уведомления


    function init() {
        try {
            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( "#authEnter" ).on( "click", authDo );                   // Клик на кнопку входа
		}
        catch (e) {
            console.error(e);
        }
    }

    // Клик на кнопку входа
    function authDo( e ) {
        try {
            if ( isAuth ) {
                return;
            }

            isAuth = true;

            let login = $( "#login" ).val();
            let password = $( "#pass" ).val();

            if ( login.length <= 4 || password.length <= 5 ) {
                showHideNotifLine( true, "Bad login or password", "error.png" );

                isAuth = false;

                return;
            }

            // Авторизуемся
            $.ajax({
                url : "/apprin/v1/refovods/auth/",
                data : "login=" + login + "&pass=" + password,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            showHideNotifLine( true, "Error login", "error.png" );

                            return;
                        }

                        window.location.href = "/ref_adm/";
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isAuth = false;
                }
            });
        }
        catch (e) {
            console.error(e);

            isAuth = false;
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию скрипта
$( window ).on( "load", authPage.init );
