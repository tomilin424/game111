let mainPage = new mainPageFunc();

function mainPageFunc () {
    let isRequest = false;
    let notifLineTimer = null;                  // Таймер скрытия линейного уведомления
    let links = [];


    function init() {
        try {
            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( "#exit" ).on( "click", exit );
            $( "#addlink" ).on( "click", addLink );
		}
        catch (e) {
            console.error(e);
        }
    }

    // Клик на кнопку выхода
    function exit( e ) {
        try {
            if ( isRequest ) {
                return;
            }

            isRequest = true;

            // Выходим
            $.ajax({
                url : "/apprin/v1/refovods/exit/",
                data : "",
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            showHideNotifLine( true, "Error exit", "error.png" );

                            return;
                        }

                        window.location.href = "/ref_adm/auth";
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isRequest = false;
                }
            });
        }
        catch (e) {
            console.error(e);

            isRequest = false;
        }
    }

    // Построение ссылок
    function buildLinks() {
        try {
            // console.log( "Строим" );

            $( "#links > tbody > tr:not(:first-child)" ).remove();
            
            let rows = $( '<div></div>' );
            
            for ( let link of links ) {
                // console.log( link );
                let elem = $( '<table>' +
                    '<tr>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '        <td></td>' +
                    '    </tr>' +
                    '</table>' );

                $( "td:nth-child(1)", elem ).html( '<div class="lButtonLink btn"><span>https://t.me/musk_crypto_bot?start=' + link.key + '</span></div>' );
                $( "td:nth-child(2)", elem ).html( link.referalsCount );
                $( "td:nth-child(3)", elem ).html( link.donats );
                $( "td:nth-child(4)", elem ).html( link.last24hour );
                $( "td:nth-child(5)", elem ).html( link.stars );
                $( "td:nth-child(6)", elem ).html( link.usdt );
                $( "td:nth-child(7)", elem ).html( '<div class="lButtonDelete btn"><span>Delete</span></div>' );

                $( "td:nth-child(1) > .lButtonLink", elem ).on( 'click', copyLink );
                $( "td:nth-child(7) > .lButtonDelete", elem ).on( 'click', deleteLink );

                $( "tr", elem ).attr({
                    "link-id" : link.id
                });

                rows.append( $( "tbody", elem ).contents() );
            }
            
            $( "#links" ).append( rows.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на копирование у ссылки
    function copyLink( e ) {
        try {
            let text = $( "span", e.currentTarget ).text();

            // console.log( "copy text: " + text );

            navigator.clipboard.writeText( text );

            showHideNotifLine( true, "Link copy", "end.png" );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на удаление у ссылки
    function deleteLink( e ) {
        try {
            if ( isRequest ) {
                return;
            }

            if ( !confirm( "Delete link?" ) ) {
                return;
            }

            isRequest = true;

            let linkID = parseInt( $( $( e.currentTarget ).parents( "tr" )[0] ).attr( "link-id" ) );

            if ( isNaN( linkID ) || linkID <= 0 ) {
                showHideNotifLine( true, "Bad link ID", "error.png" );

                isRequest = false;

                return;
            }

            // Удаляем ссылку
            $.ajax({
                url : "/apprin/v1/refovods/removeLink/",
                data : "id=" + linkID,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            showHideNotifLine( true, "Error delete", "error.png" );

                            return;
                        }

                        // Удаляем из таблицы
                        $( "[link-id=\"" + linkID + "\"]" ).remove();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isRequest = false;
                }
            });
        }
        catch (e) {
            console.error(e);

            isRequest = false;
        }
    }

    // Клик на добавление ссылки
    function addLink( e ) {
        try {
            if ( isRequest ) {
                return;
            }

            isRequest = true;

            // Удаляем ссылку
            $.ajax({
                url : "/apprin/v1/refovods/genLink/",
                data : "",
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            showHideNotifLine( true, "Error add link", "error.png" );

                            return;
                        }

                        // Добавляем ссылку в начало
                        links.unshift( resp.data );

                        // строим ссылки снова
                        buildLinks();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isRequest = false;
                }
            });
        }
        catch (e) {
            console.error(e);

            isRequest = false;
        }
    }



    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function() {
            init();
        }
    }
}

// запускаем инициализацию скрипта
$( window ).on( "load", mainPage.init );
