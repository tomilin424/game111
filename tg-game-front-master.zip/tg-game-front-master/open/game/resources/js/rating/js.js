let ratingPage = new ratingPageFunc();

function ratingPageFunc () {
    let ratingStorageKey = "rating";

    let isLoadEnd = false;                          // Индикатор того, что уже была загрузка данных (хранилище или аякс)

    let ratingData = null;                 // Данные рейтинга
    let userRating = null;                  // Данные рейтинга пользователя в лиге
    let activeLeague = null;                // Текущая активная лига

    let isOnlyLoad = false;

    function init() {
        try {
            nav.selectMenuItem( "main" );

            // Сбрасываем данные лиги
            resetRating();

            // Добавляем слушатели событий
            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    function pageOpen() {
        try {
            if (!userRating?.leagueID) {
                return;
            }

            activeLeague = userRating.leagueID;

            buildRating();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( ".rHArrow" ).on( "click", arrowClick );                  // Клик на стрелку

            // Готовность ТГ объекта
            //$( document ).on( "tgReady", tgReady );

            // Загружена основная информация о юзере
            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", loadData );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Обновление данных страницы
    function reload() {
        try {
            isOnlyLoad = true;
            isLoadEnd = false;

            // запускаем загрузку данных
            loadData();
        }
        catch (e) {
            console.error(e);
        }
    }

    /*//Готовность ТГ объекта
    function tgReady() {
        try {
            // console.log( "TG", tg );

            tg.BackButton.isVisible = true;
            tg.BackButton.show();
            tg.BackButton.onClick( function ( ) {
                // console.log( "CLICK" );

                // Кликаем на главную страницу
                parent.mainPage.activeMenuItem( "main" );
                //window.location.href = $( "[nav-item=\"main\"]" ).attr( "href" );
            } );
        }
        catch (e) {
            console.error(e);
        }
    }*/

    // Клик на стрелку
    function arrowClick( e ) {
        try {
            // тип кнопки
            let button = $( e.currentTarget ).attr( "arrow" );
            let newLeagueID = activeLeague;

            // Если стрелка налево
            if ( button === "left" ) {
                newLeagueID--;
            }
            else {
                newLeagueID++;
            }

            // Если ИД меньше 1
            if ( newLeagueID < 1 ) {
                newLeagueID = 1;
            }

            // Если ИД больше максимума
            if ( newLeagueID > ratingData[ ratingData.length - 1 ].id ) {
                newLeagueID = ratingData[ ratingData.length - 1 ].id;
            }

            // Записываем новую лигу
            activeLeague = newLeagueID;

            // Строим данные рейтинга лиги
            buildRating();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Загрузка данных рейтинга
    function loadData( e ) {
        // console.log( "Событие", e );

        try {
            if ( isLoadEnd ) {
                return;
            }

            isLoadEnd = true;

            // Если не только загрузка И есть данные в хранилище
            if ( !isOnlyLoad && localStorage.getItem( ratingStorageKey ) !== undefined && localStorage.getItem( ratingStorageKey ) !== null ) {
                // console.log( "Взяли из хранилища" );
                let storageData = JSON.parse( localStorage.getItem( ratingStorageKey ) );

                // console.log( storageData );

                // записываем данные рейтинга
                ratingData = storageData.ratingData;
                userRating = storageData.userRating;

                // строим первую лигу
                activeLeague = 1;

                buildRating();

                // запускаем загрузку новых данных рейтинга
                system.loadRating();

                return;
            }


            $.ajax({
                url : "/apprin/v1/rating/load_data/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // записываем данные рейтинга
                        ratingData = resp.data.items;
                        userRating = resp.data.userRating;

                        localStorage.setItem( ratingStorageKey, JSON.stringify( {
                            "ratingData" : ratingData,
                            "userRating" : userRating
                        } ) );

                        // строим первую лигу
                        activeLeague = 1;

                        buildRating();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isOnlyLoad = false;
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    // Построение лиги
    function buildRating( ) {
        try {
            // данные лиги
            let leagueData = getItemByKeyValue( ratingData, "id", activeLeague );

            if ( leagueData === null ) {
                throw "Не получены данные лиги";
            }

            // Сбрасываем данные лиги
            resetRating();

            // 0 - лига не юзера, 1 - юзера
            let isCurrent = leagueData.id === userRating.leagueID;
            // Количество скорости в лиге
            let allSpeed = ( leagueData.maxSpeed + 1 ) - leagueData.minSpeed;

            $( "[league-content]" ).attr( "league-content", "league" + activeLeague );
            $( "#ratingHead > :nth-child(2) > img" ).attr( "src", "/resources/img/leagues/" + leagueData.id + ".png" );
            $( "#ratingHead > :nth-child(2) > :last-child > span:first-child" ).html( leagueData.name );
            $( "#ratingHead > :nth-child(2) > :last-child > span:last-child" ).html( ( !isCurrent ?
                lang.getText( "from" ) + " " + formatNumber( leagueData.minSpeed ) :
                formatNumber( userRating.speed - leagueData.minSpeed ) + " " + lang.getText( "from2" ) + " " + formatNumber( allSpeed ) ) + " " + lang.getText( "speed_short" ) );

            // Если лига юзера
            if ( isCurrent ) {
                // Пройденный процент
                let percent = ( userRating.speed - leagueData.minSpeed ) / ( leagueData.maxSpeed + 1 ) * 100;

                // Показываем полоску
                showHideStatus( true, percent );

                // Показываем место
                $( "#ratingUserItem * .rICenter > div:nth-child(2) > span" ).html( userRating.number + " " + lang.getText( "place" ) );
                // Пишем скорость
                $( "#ratingUserItem * .rIRight > div > span:first-child" ).html( userRating.speed );

                // Если юзер не в топ-е
                if ( userRating.number > 3 ) {
                    $( "#ratingUserItem * .rICenter > div:nth-child(2) > span" ).removeClass( "goldTransparentFontColor " ).addClass( "grayFontColor" )
                }

                // Показываем плашку юзера
                showHideUserItem();
            }
            else {
                // Скрываем полоску
                showHideStatus( false );
                // Скрываем плашку юзера
                showHideUserItem( false );
            }

            // Если текущая лига первая
            if ( activeLeague === 1 ) {
                // скрываем левую стрелку
                blockUnblockArrow( "left", true );
            }
            else {
                // показываем левую стрелку
                blockUnblockArrow( "left" );
            }

            // Если текущая лига последняя
            if ( activeLeague === ratingData[ ratingData.length - 1 ].id ) {
                // скрываем правую стрелку
                blockUnblockArrow( "right", true );
            }
            else {
                // показываем правую стрелку
                blockUnblockArrow( "right" );
            }

            // юзеры
            let items = $( '<div></div>' );
            let number = 1;

            // перебираем юзеров
            for ( let user of leagueData.rating ) {
                let userItem = $( '<div>' +
                    '<div class="ratingItem">' +
                    '            <div class="rIIcon">' +
                    '                <span class="largerFontSize"></span>' +
                    '            </div>' +
                    '' +
                    '            <div class="rICenter">' +
                    '                <div>' +
                    '                    <span class=""></span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <span class="goldTransparentFontColor smallFontSize"></span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div class="rIRight">' +
                    '                <img src="/resources/img/speed.png" />' +
                    '' +
                    '                <span class="smallLargerFontSize"></span>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>' );

                let username = user.username === null ? "Nothing" : user.username;

                $( ".rIIcon > span", userItem ).html( username.substring(0, 1).toUpperCase() );
                $( ".rICenter > div:first-child > span", userItem ).html( username );
                $( ".rICenter > div:last-child > span", userItem ).html( number + " " + lang.getText( "place" ) );

                if ( number > 3 ) {
                    $( ".goldTransparentFontColor", userItem ).removeClass( "goldTransparentFontColor" ).addClass( "grayFontColor" );
                }

                $( ".rIRight > span", userItem ).html( formatNumber( user.speed ) );

                number++;

                items.append( userItem.contents() );
            }

            // выводим юзеров на страницу
            $( "#rating_page #cItems" ).html( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Показ/скрытие плашки юзера
    function showHideUserItem( isShow = true ) {
        try {
            if ( isShow ) {
                $( "#ratingUserItem" ).addClass( "show" );
            }
            else {
                $( "#ratingUserItem" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Показ/скрытие статуса в шапке
    function showHideStatus( isShow = true, percent ) {
        try {
            if ( isShow ) {
                $( "#ratingSpeedLine > div" ).css( "width", percent + "%" );
                $( "#ratingSpeedLine" ).addClass( "show" );
            }
            else {
                $( "#ratingSpeedLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Блокировка/разблокировка кнопки навигации
    function blockUnblockArrow( button, isBlock = false ) {
        try {
            if ( isBlock ) {
                $( ".rHArrow[arrow=\"" + button + "\"]" ).addClass( "rHArrowHide" );
            }
            else {
                $( ".rHArrow[arrow=\"" + button + "\"]" ).removeClass( "rHArrowHide" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }

    // Сброс лиги
    function resetRating() {
        try {
            $( "#ratingHead > :nth-child(3) > :last-child > span" ).html( "" );

            $( "#ratingHead > div:nth-child( 2 ) > img" ).attr( "src", "" );

            $( "#rating_page #cItems > *" ).remove();
        }
        catch (e) {
            console.error(e);
        }
    }

    return {
        init: function() {
            init();
        },
        pageOpen: function() {
            pageOpen();
        },
        reload: function () {
            reload();
        }
    }
}

// Обновление данных страницы
window[ "reload" ] = function reload ( ) {
    ratingPage.reload();
}

// запускаем инициализацию страницы рейтинга
$( window ).on( "load", ratingPage.init );

window.pageOpen['rating'] = ratingPage.pageOpen