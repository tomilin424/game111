let settingsPage = new settingsPageFunc();

function settingsPageFunc () {
    let settingsStorageKey = "settings";

    let settings = null;                                         // настройки
    let isSave = false;

    function init() {
        try {
            nav.selectMenuItem( "main" );

            // Удаляем карточки
            //clearCards();

            addEvents();
        }
        catch (e) {
            console.error(e);
        }
    }

    //добавление событий
    function addEvents() {
        try {
            // Готовность ТГ объекта
            //$( document ).on( "tgReady", tgReady );

            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", build );                      // Загрузка данных юзера завершена

            $( document ).on( "settingsLoadSuccess", buildItems );                      // Загрузка данных настроек завершена

            $( "#lang" ).on( "click", langSettingCLick );
            $( "#errorReport" ).on( "click", errorReport );
            $( "#marketingReport" ).on( "click", marketingReport );
        }
        catch (e) {
            console.error(e);
        }
    }

    /*//Готовность ТГ объекта
    function tgReady() {
        try {
            console.log( "TG", tg );

            tg.BackButton.isVisible = true;
            tg.BackButton.show();
            tg.BackButton.onClick( function ( ) {
                console.log( "CLICK" );

                // Кликаем на главную страницу
                parent.mainPage.activeMenuItem( "main" );
                //window.location.href = $( "[nav-item=\"main\"]" ).attr( "href" );
            } );
        }
        catch (e) {
            console.error(e);
        }
    }*/


    // Построение
    function build( ) {
        try {
            $( document ).off( "userMainDataStorageSuccess userMainDataLoadSuccess", build );

            // Если есть данные в хранилище
            if ( localStorage.getItem( settingsStorageKey ) !== undefined && localStorage.getItem( settingsStorageKey ) !== null ) {
                let storageData = JSON.parse( localStorage.getItem( settingsStorageKey ) );

                // console.log( storageData );

                settings = storageData;

                $( document ).trigger( "settingsLoadSuccess" );

                return;
            }

            // Загружаем настройки
            $.ajax({
                url : "/apprin/v1/settings/loadData/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        settings = resp.data;

                        localStorage.setItem( settingsStorageKey, JSON.stringify( settings ) )

                        $( document ).trigger( "settingsLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }


    // Построение настроек
    function buildItems( ) {
        try {
            // Если настроек нет
            if ( settings === null ) {
                // Берём конфиги из локального хранилища
                settings = JSON.parse( localStorage.getItem( settingsStorageKey ) );
            }

            $( ".eIRFlag > img" ).attr( "src", "/resources/img/flags/" + settings.userLangChar + ".png" );
            $( ".eIRText > span" ).html( getItemByKeyValue( settings.langs, "char", settings.userLangChar ).name );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на настройку языка
    function langSettingCLick( e ) {
        try {
            // Пишем контент
            $( ".popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupLabel popupLabelLangs">' +
                '            <span class="largerFontSize">' + lang.getText( "change_lang" ) + '</span>' +
                '        </div>' +
                '' +
                '        <div class="pCItems">' +
                '        </div>' );



            let items = $( '<div></div>' );
            
            for ( let i = 0; i <= settings.langs.length - 1; i++ ) {
                let lang = $( '<div>' +
                    '<div class="earnItem">' +
                    '                <div class="eIRFlag show">' +
                    '                    <img src="" />' +
                    '                </div>' +
                    '' +
                    '                <div class="eILabel">' +
                    '                    <span></span>' +
                    '                </div>' +
                    '' +
                    '                <div class="eIRight">' +
                    '                    <div class="eIREnd">' +
                    '                        <div>' +
                    '                            <img src="/resources/img/earn/end.png"/>' +
                    '                        </div>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '</div>' );

                $( ".eILabel > span", lang ).html( settings.langs[ i ].name + " (" + settings.langs[ i ].char.toLowerCase() + ")" );
                $( ".eIRFlag > img", lang ).attr( "src", "/resources/img/flags/" + settings.langs[ i ].char.toLowerCase() + ".png" );

                $( "> div", lang )
                    .attr({
                        "lang-index" : i
                    })
                    .on( "click", langClick );

                // Если язык это текущий язык юзера
                if ( settings.langs[ i ].char === settings.userLangChar ) {
                    $( ".eIREnd", lang ).addClass( "show" );
                }

                items.append( lang.contents() );
            }

            $( ".pCItems" ).html( items.contents() );

            addDelEventsPopup();
            showHidePopup();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на язык
    function langClick( e ) {
        try {
            if ( isSave ) {
                return;
            }

            isSave = true;

            let langData = settings.langs[ parseInt( $( e.currentTarget ).attr( "lang-index" ) ) ];

            // Загружаем настройки
            $.ajax({
                url : "/apprin/v1/settings/setLang/",
                data : "id=" + user.getAllUserData().uuid + "&lang=" + langData.id,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        localStorage.setItem( settingsStorageKey, JSON.stringify( resp.data ) );

                        system.clearCache();

                        window.location.reload();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                    isSave = false;
                }
            });
        }
        catch (e) {
            console.error(e);

            isSave = false;
        }
    }


    // Клик на сообщение о проблеме
    function errorReport( e ) {
        try {
            let message = "Error report:\n\n";

            let url = settings.error + "?text=" + encodeURIComponent( message );

            tg.openTelegramLink( url );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на сообщение о рекламе
    function marketingReport( e ) {
        try {
            let message = "Marketing:\n\n";

            let url = settings.marketing + "?text=" + encodeURIComponent( message );

            tg.openTelegramLink( url );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function() {
            init();
        }
    }
}

// Запуск действий при старте
window[ "start" ] = function start ( ) {
    // console.log( "START frame" );

    parent.mainPage.tgBackCallback( function () {
        // Кликаем на главную страницу
        parent.mainPage.activeMenuItem( "main" );

        // скрываем кнопку
        parent.mainPage.tgBackShowHide( false );
    } );

    // показываем кнопку
    parent.mainPage.tgBackShowHide( true );
}

// запускаем инициализацию страницы настроек
$( window ).on( "load", settingsPage.init );
