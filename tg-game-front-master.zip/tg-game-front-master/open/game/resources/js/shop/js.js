let shopPage = new shopPageFunc();

function shopPageFunc () {
    let assistents = [];                                        // ассистенты
    let currentAssistIndex = null;                              // Индекс открытого ассистента

    let products = [];                                         // карточки
    let currentItemIndex = null;                                // Индекс открытой карточки для покупки
    let isPay = false;                                          // индикатор активного процесса покупки

    let payCheckOrderUUID = null;                                   // UUID проверяемого заказа
    let payTimer = null;                                            // Таймер во время проверки оплаты
    let maxPayTime = 5;                                         // Максимальное время ожидания оплаты в минутах
    let currPayTime = 0;                                        // Текущее прошеднее время в секундах
    let payTime = 6;                                            // Интервал проверки оплаты в секундах

    let connector = null;                                       // ton ui коннектор к кошельку


    let cell = null;

    function init() {
        try {
            nav.selectMenuItem( "main" );

            // Удаляем карточки
            //clearCards();

            addEvents();

            /*connector = new TON_CONNECT_UI.TonConnectUI({
                manifestUrl : "https://game.ton-musk.com/resources/tonconnect-manifest.json",
                uiOptions : {
                    twaReturnUrl: "https://t.me/crypt_test_game_bot?game=url_crypt_name"
                }
            });

            // Слушатель изменений статуса коннекта кошелька
            connector.onStatusChange(
                walletAndwalletInfo => {
                    console.log( "Новый статус", connector.connected );

                    if ( !connector.connected ) {
                        // Коннектимся к кошельку
                        connector.connectWallet();

                        connector.restoreConnection();
                    }
                }
            );*/
        }
        catch (e) {
            console.error(e);
        }
    }

    function Utf8ArrayToStr(array) {
        var out, i, len, c;
        var char2, char3;

        out = "";
        len = array.length;
        i = 0;
        while(i < len) {
            c = array[i++];
            switch(c >> 4)
            {
                case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
                // 0xxxxxxx
                out += String.fromCharCode(c);
                break;
                case 12: case 13:
                // 110x xxxx   10xx xxxx
                char2 = array[i++];
                out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
                break;
                case 14:
                    // 1110 xxxx  10xx xxxx  10xx xxxx
                    char2 = array[i++];
                    char3 = array[i++];
                    out += String.fromCharCode(((c & 0x0F) << 12) |
                        ((char2 & 0x3F) << 6) |
                        ((char3 & 0x3F) << 0));
                    break;
            }
        }

        return out;
    }

    function writeStringTail(str, cell) {
        const bytes = Math.floor(cell.bits.getFreeBits() / 8); // 1 symbol = 8 bits
        if(bytes < str.length) { // if we can't write all string
            cell.bits.writeString(str.substring(0, bytes)); // write part of string
            const newCell = writeStringTail(str.substring(bytes), new TonWeb.boc.Cell()); // create new cell
            cell.refs.push(newCell); // add new cell to current cell's refs
        } else {
            cell.bits.writeString(str); // write all string
        }

        return cell;
    }

    function readStringTail(slice) {
        const str = new TextDecoder('ascii').decode(slice.array); // decode uint8array to string
        if (cell.refs.length > 0) {
            return str + readStringTail(cell.refs[0].beginParse()); // read next cell
        } else {
            return str;
        }
    }

    //добавление событий
    function addEvents() {
        try {
            // Готовность ТГ объекта
            //$( document ).on( "tgReady", tgReady );

            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", build );                      // Загрузка данных юзера завершена

            $( document ).on( "shopItemsLoadSuccess", buildItems );                      // Загрузка данных товаров завершена
            $( document ).on( "shopAssistentsLoadSuccess", buildAssistents );                      // Загрузка данных ассистентов завершена
        }
        catch (e) {
            console.error(e);
        }
    }

    //Готовность ТГ объекта
    /*function tgReady() {
        try {
            console.log( "TG", tg );

            tg.BackButton.isVisible = true;
            tg.BackButton.show();
            tg.BackButton.onClick( function ( ) {
                console.log( "CLICK" );

                // Кликаем на главную страницу
                parent.mainPage.activeMenuItem( "main" );
                //window.location.href = $( "[nav-item=\"main\"]" ).attr( "href" );
            } );
        }
        catch (e) {
            console.error(e);
        }
    }*/


    // Построение
    function build( ) {
        try {
            $( document ).off( "userMainDataStorageSuccess userMainDataLoadSuccess", build );

            // Загружаем карточки
            $.ajax({
                url : "/apprin/v1/user/byLoadItems/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        products = resp.data;

                        $( document ).trigger( "shopItemsLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                }
            });

            // Загружаем ассистентов
            $.ajax({
                url : "/apprin/v1/user/byLoadAssistents/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        assistents = resp.data;

                        $( document ).trigger( "shopAssistentsLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }


    // Построение ассистентов
    function buildAssistents( ) {
        try {

            $( "#aItems > *" ).remove();                    // Удаляем старые

            let items = $( '<div></div>' );
            let itemIndex = 0;

            for ( let assist of assistents ) {
                let item = $( '<div>' +
                    '<div class="earnItem">' +
                    '            <div class="eIIcon">' +
                    '                <img src="/resources/img/shop/assistent.png"/>' +
                    '            </div>' +
                    '' +
                    '            <div class="eICenter">' +
                    '                <div>' +
                    '                    <span class="smallLargerFontSize">' + lang.getText( "my_assistents" ) + '</span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <img src="/resources/img/shop/xtr.png" />' +
                    '' +
                    '                    <span class="">1 STAR</span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div class="eIRight">' +
                    '                <div class="eIRActive show">' +
                    '                    <div>' +
                    '                        <img src="/resources/img/arrow_gray.svg"/>' +
                    '                    </div>' +
                    '                </div>' +
                    '' +
                    '                <div class="eIREnd">' +
                    '                    <div>' +
                    '                        <img src="/resources/img/earn/end.png" />' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>' );

                $( ".eICenter > div:first-child > span", item ).html( assist.name );
                $( ".eICenter > div:last-child > img", item ).attr( "src", "/resources/img/shop/" + assist.currency[ 0 ].toLowerCase() + ".png" );
                $( ".eICenter > div:last-child > span", item ).html( assist.price[ 0 ] + " " +
                    ( assist.currency[ 0 ].toUpperCase() === "XTR" ? "STARS" : assist.currency[ 0 ].toUpperCase() ) );

                $( ".earnItem", item ).attr({
                    "assist-index" : itemIndex
                });

                // Если юзер не купил ассистента
                if ( !user.getMainUserData().isByAssistent ) {
                    $( ".earnItem", item ).on( "click", assistClick );                  // Добавляем событие клика
                }
                else {
                    $( ".eIRActive", item ).removeClass( "show" );

                    $( ".eIREnd", item ).addClass( "show" );
                }

                itemIndex++;

                items.append( item.contents() );
            }

            $( "#aItems" ).html( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на ассистента
    function assistClick( e ) {
        try {
            let itemIndex = parseInt( $( e.currentTarget ).attr( "assist-index" ) );

            currentAssistIndex = itemIndex;

            // Пишем контент
            $( "#shop_page .popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupIconLarge">' +
                '            <img src="/resources/img/shop/assistent2.png" />' +
                '        </div>' +
                '' +
                '        <div class="popupLabel">' +
                '            <span class="smallLargerFontSize">' + lang.getText( "my_assistents" ) + '</span>' +
                '        </div>' +
                '' +
                '        <div class="popupSublabel">' +
                '            <span class="smallLargerFontSize grayFontColor">' + lang.getText( "cancel_timers" ) + '...</span>' +
                '        </div>' +
                '' +
                '        <div class="popupChoosePayType">' +
                '            <span class="smallFontSize grayFontColor">' + lang.getText( "choose_pay_type" ) + ':</span>' +
                '        </div>' +
                '' +
                '        <div id="popupItemsCurrency"></div>' );

            $( "#shop_page .popupLabel > span" ).html( assistents[ currentAssistIndex ].name );
            $( "#shop_page .popupSublabel > span" ).html( assistents[ currentAssistIndex ].description );

            let currencys = $( '<div></div>' );
            let currCount = 0;

            for ( let i = 0; i <= assistents[ currentAssistIndex ].price.length - 1; i++ ) {
                let currency = $( '<div>' +
                    '<div>' +
                    '                <img src="/resources/img/shop/xtr.png" />' +
                    '' +
                    '                <span>0.14 STARS</span>' +
                    '            </div>' +
                    '</div>' );

                $( "span", currency ).html( assistents[ currentAssistIndex ].price[ i ] + " " +
                    (assistents[ currentAssistIndex ].currency[ i ].toUpperCase() !== "XTR" ? assistents[ currentAssistIndex ].currency[ i ].toUpperCase() : "STARS") );
                $( "img", currency ).attr( "src", "/resources/img/shop/" + assistents[ currentAssistIndex ].currency[ i ].toLowerCase() + ".png" );

                $( "> div", currency )
                    .attr({
                        "currency-index" : i
                    })
                    .on( "click", currencyAssistClick );

                currencys.append( currency.contents() );

                currCount++;
            }

            // Если только одна доступная валюта
            if ( currCount === 1 ) {
                $( "> :first-child", currencys ).css( {
                    "flex-basis" : "100%"
                } );
            }

            $( "#shop_page #popupItemsCurrency" ).html( currencys.contents() );

            addDelEventsPopup();
            showHidePopup();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на валюту для покупки у ассистента
    function currencyAssistClick( e ) {
        try {
            if ( isPay ) {
                return;
            }

            isPay = true;

            let currencyIndex = parseInt( $( e.currentTarget ).attr( "currency-index" ) );
            let itemID = assistents[ currentAssistIndex ].id;
            let currency = assistents[ currentAssistIndex ].currency[ currencyIndex ];

            $.ajax({
                url : "/apprin/v1/user/byAssist/",
                data : "id=" + user.getAllUserData().uuid + "&s=1&itemID=" + itemID + "&curr=" + currency,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если валюта звёзды
                        if ( currency.toUpperCase() === "XTR" ) {
                            // Открываем окошко оплаты
                            tg.openInvoice( resp.data.payLink );
                        }

                        // Если валюта TON или USDT
                        if ( currency.toUpperCase() === "TON" || currency.toUpperCase() === "USDT" ) {
                            // Переходим в бота для оплаты
                            window.location.href = resp.data.payLink;
                        }

                        // записываем UUID заказа
                        payCheckOrderUUID = resp.data.orderData.id;

                        // запускаем проверку оплаты
                        startByCheckAssistTimer();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            isPay = false;
        }
    }

    // Запуск таймера проверки оплаты (ассистент)
    function startByCheckAssistTimer( ) {
        try {
            clearByCheckAssistTimer( );

            currPayTime = 0;

            payTimer = setTimeout( continueByCheckAssistTimer, payTime * 1000 );
        }
        catch (e) {
            console.error(e);

            isPay = false;
        }
    }
    // Очистка таймера проверки оплаты (ассистент)
    function clearByCheckAssistTimer( ) {
        try {
            if ( payTimer !== null ) {
                clearTimeout( payTimer );

                payTimer = null;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение таймера проверки оплаты (ассистент)
    function continueByCheckAssistTimer( ) {
        try {
            clearByCheckAssistTimer( );

            // Проверяем
            $.ajax({
                url : "/apprin/v1/user/byCheckAssist/",
                data : "id=" + user.getAllUserData().uuid + "&orderID=" + payCheckOrderUUID,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если оплата успешна
                        if ( resp.data ) {
                            // Меняем индикатор наличия ассистента
                            user.setMainUserData( "isByAssistent", true );

                            // Перестраиваем ассистентов
                            buildAssistents();

                            // Показываем оповещение
                            showHideNotifLine( true, "Ассистент куплен", "end.png" );

                            // Скрываем попап
                            addDelEventsPopup( false );
                            showHidePopup( false );

                            isPay = false;
                        }
                        else {
                            // Если время меньше или равно максимума
                            if ( currPayTime + payTime <= maxPayTime * 60 ) {
                                // Снова запускаем таймер
                                payTimer = setTimeout( continueByCheckAssistTimer, payTime * 1000 );
                            }
                            else {
                                // Показываем оповещение
                                showHideNotifLine( true, "Error pay", "error.png" );

                                // Скрываем попап
                                addDelEventsPopup( false );
                                showHidePopup( false );

                                isPay = false;
                            }
                        }
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            isPay = true;
        }
    }



    // Построение карточек
    function buildItems( ) {
        try {
            $( "#shop_page #cItems > *" ).remove();                    // Удаляем старые товары

            let items = $( '<div></div>' );
            let itemIndex = 0;

            for ( let product of products ) {
                let item = $( '<div>' +
                    '<div class="earnItem">' +
                    '            <div class="eIIcon">' +
                    '                <img src="/resources/img/rocket_angle.png"/>' +
                    '            </div>' +
                    '' +
                    '            <div class="eICenter">' +
                    '                <div>' +
                    '                    <span class="smallLargerFontSize"></span>' +
                    '                </div>' +
                    '' +
                    '                <div>' +
                    '                    <img src="/resources/img/shop/star.png" />' +
                    '' +
                    '                    <span class="">0.14 STAR</span>' +
                    '                </div>' +
                    '            </div>' +
                    '' +
                    '            <div class="eIRight">' +
                    '                <div class="eIRActive show">' +
                    '                    <div>' +
                    '                        <img src="/resources/img/arrow_gray.svg"/>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '        </div>' +
                    '</div>' );

                $( ".eICenter > div:first-child > span", item ).html( product.earn + " " + lang.getText( "rockets" ) );
                $( ".eICenter > div:last-child > img", item ).attr( "src", "/resources/img/shop/" + product.currency[ 0 ].toLowerCase() + ".png" );
                $( ".eICenter > div:last-child > span", item ).html( product.price[ 0 ] + " " +
                    ( product.currency[ 0 ].toUpperCase() === "XTR" ? "STARS" : product.currency[ 0 ].toUpperCase() ) );

                $( ".earnItem", item ).attr({
                    "product-index" : itemIndex
                }).on( "click", itemClick );

                itemIndex++;

                items.append( item.contents() );
            }

            $( "#shop_page #cItems" ).html( items.contents() );
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на карточку
    function itemClick( e ) {
        try {
            let itemIndex = parseInt( $( e.currentTarget ).attr( "product-index" ) );

            currentItemIndex = itemIndex;

            // Пишем контент
            $( "#shop_page .popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupIconLarge">' +
                '            <img src="/resources/img/rocket_angle.png" />' +
                '        </div>' +
                '' +
                '        <div class="popupLabel">' +
                '            <span class="smallLargerFontSize">500 ракет</span>' +
                '        </div>' +
                '' +
                '        <div class="popupSublabel">' +
                '            <span class="smallLargerFontSize grayFontColor">' + lang.getText( "game_money" ) + '</span>' +
                '        </div>' +
                '' +
                '        <div class="popupChoosePayType">' +
                '            <span class="smallFontSize grayFontColor">' + lang.getText( "choose_pay_type" ) + ':</span>' +
                '        </div>' +
                '' +
                '        <div id="popupItemsCurrency"></div>' );

            $( "#shop_page .popupLabel > span" ).html( products[ currentItemIndex ].earn + " " + lang.getText( "rockets" ) );

            let currencys = $( '<div></div>' );
            let currCount = 0;

            // console.log('products', products)
            // console.log('currentItemIndex', currentItemIndex)

            for ( let i = 0; i <= products[ currentItemIndex ].price.length - 1; i++ ) {
                let currency = $( '<div>' +
                    '<div>' +
                    '                <img src="/resources/img/shop/xtr.png" />' +
                    '' +
                    '                <span>0.14 STARS</span>' +
                    '            </div>' +
                    '</div>' );

                $( "span", currency ).html( products[ currentItemIndex ].price[ i ] + " " +
                    (products[ currentItemIndex ].currency[ i ].toUpperCase() !== "XTR" ? products[ currentItemIndex ].currency[ i ].toUpperCase() : "STARS") );
                $( "img", currency ).attr( "src", "/resources/img/shop/" + products[ currentItemIndex ].currency[ i ].toLowerCase() + ".png" );

                $( "> div", currency )
                    .attr({
                        "currency-index" : i
                    })
                    .on( "click", currencyClick );

                currencys.append( currency.contents() );

                currCount++;
            }

            // Если только одна доступная валюта
            if ( currCount === 1 ) {
                $( "> :first-child", currencys ).css( {
                    "flex-basis" : "100%"
                } );
            }

            $( "#shop_page #popupItemsCurrency" ).html( currencys.contents() );

            addDelEventsPopup();
            showHidePopup();
        }
        catch (e) {
            console.error(e);
        }
    }

    // Клик на валюту для покупки
    function currencyClick( e ) {
        try {
            /*// Если коннекта не было
            if ( !connector.connected ) {
                // Коннектимся к кошельку
                connector.connectWallet();

                return;
            }*/

            if ( isPay ) {
                return;
            }

            isPay = true;

            let currencyIndex = parseInt( $( e.currentTarget ).attr( "currency-index" ) );
            let itemID = products[ currentItemIndex ].id;
            let currency = products[ currentItemIndex ].currency[ currencyIndex ];

            $.ajax({
                url : "/apprin/v1/user/by/",
                data : "id=" + user.getAllUserData().uuid + "&s=1&itemID=" + itemID + "&curr=" + currency,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если валюта звёзды
                        if ( currency.toUpperCase() === "XTR" ) {
                            // Открываем окошко оплаты
                            tg.openInvoice(resp.data.payLink);
                        }

                        /*// Если валюта TON или USDT
                        if ( currency.toUpperCase() === "TON" || currency.toUpperCase() === "USDT" ) {
                            cell = new TonWeb.boc.Cell();

                            let str = "1|" + resp.data.orderData.id;
                            cell = writeStringTail(str, cell);
                            let text = readStringTail(cell.beginParse());

                            cell.toBoc().then(function( resultBoc ) {
                                console.log( "ЗАКОДИРОВАННАЯ СТРОКА", resultBoc, resultBoc.toString( "base64" ), text, btoa(text) );

                                console.log( $.extend([], true, cell.bits) );

                                let transaction = {
                                    validUntil : Math.floor( Date.now() / 1000 ) + 300,
                                    messages : [
                                        {
                                            address : resp.data.wallet,
                                            amount : resp.data.price,
                                            payload : Array.from( resultBoc )
                                        }
                                    ]
                                };

                                connector.uiOptions = {
                                    actionsConfiguration: {
                                        modals: ['before', 'success', 'error'],
                                        notifications: ['before', 'success', 'error']
                                    }
                                };

                                window.addEventListener('ton-connect-ui-transaction-signed', (event) => {
                                    console.log('Событие транзакции', event);
                                });

                                window.addEventListener('ton-connect-ui-transaction-sent-for-signature', (event) => {
                                    console.log('Событие транзакции 2', event.detail);
                                    console.log( JSON.stringify(event.detail) );
                                });

                                let resultTrx = connector.sendTransaction( transaction )/*.then( function ( resultSend ) {
                                    console.log( "Данные транзакции", resultSend, resultSend.boc, resultSend.messageHash );

                                    // Шлём хэш заказа
                                    sendCryptOrderHash( resp.data.orderData.id , resultSend.messageHash );
                                }, function ( resultBad ) {
                                    console.log( "Площие данные транзакции", resultBad, JSON.stringify( resultBad ) );
                                } );*/

                                /*console.log( "Данные транзакции 2", resultTrx, resultTrx.boc, resultTrx.messageHash );
                            })
                        }*/

                        // записываем UUID заказа
                        payCheckOrderUUID = resp.data.orderData.id;

                        // запускаем проверку оплаты
                        startByCheckTimer();
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            isPay = false;
        }
    }

    // Отправка хэш-а заказа
    function sendCryptOrderHash( orderID, hash ) {
        try {
            $.ajax({
                url : "/apprin/v1/user/byOrderHash/",
                data : "id=" + user.getAllUserData().uuid + "&orderID=" + orderID + "&hash=" + hash,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);
        }
    }

    // Запуск таймера проверки оплаты (ракеты)
    function startByCheckTimer( ) {
        try {
            clearByCheckTimer( );

            currPayTime = 0;

            payTimer = setTimeout( continueByCheckTimer, payTime * 1000 );
        }
        catch (e) {
            console.error(e);

            isPay = false;
        }
    }
    // Очистка таймера проверки оплаты (ракеты)
    function clearByCheckTimer( ) {
        try {
            if ( payTimer !== null ) {
                clearTimeout( payTimer );

                payTimer = null;
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Продолжение таймера проверки оплаты (ракеты)
    function continueByCheckTimer( ) {
        try {
            clearByCheckTimer( );

            // Проверяем
            $.ajax({
                url : "/apprin/v1/user/byCheck/",
                data : "id=" + user.getAllUserData().uuid + "&orderID=" + payCheckOrderUUID,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если оплата успешна
                        if ( resp.data ) {
                            // Добавляем на баланс нужное количество ракет
                            user.setMainUserData( "balanceRockets", user.getMainUserData().balanceRockets + products[ currentItemIndex ].earn );

                            // Показываем оповещение
                            showHideNotifLine( true, "Ракеты куплены", "end.png", products[ currentItemIndex ].earn );

                            // У родителя подгружаем новые данные
                            parent.mainPage.reloadMainUserData();

                            // Обновляем данные на зависимых страницах
                            parent.mainPage.reload( "space" );

                            // Скрываем попап
                            addDelEventsPopup( false );
                            showHidePopup( false );

                            isPay = false;
                        }
                        else {
                            // Если время меньше или равно максимума
                            if ( currPayTime + payTime <= maxPayTime * 60 ) {
                                // Снова запускаем таймер
                                payTimer = setTimeout( continueByCheckTimer, payTime * 1000 );
                            }
                            else {
                                // Показываем оповещение
                                showHideNotifLine( true, "Error pay", "error.png" );

                                // Скрываем попап
                                addDelEventsPopup( false );
                                showHidePopup( false );

                                isPay = false;
                            }
                        }
                    }
                    catch ( err ) {
                        console.error(err);
                    }
                },
                error : function ( err ) {
                    console.error(err);

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error(e);

            isPay = true;
        }
    }


    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // НЕ УНИВЕРСАЛЬНЫЙ КОД
            clearByCheckTimer();
            isPay = false;

            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error(e);
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error(e);
        }
    }


    return {
        init: function() {
            init();
        }
    }
}

// // Запуск действий при старте
// window[ "start" ] = function start ( ) {
//     // console.log( "START frame" );
//
//     parent.mainPage.tgBackCallback( function () {
//         // Кликаем на главную страницу
//         parent.mainPage.activeMenuItem( "main" );
//
//         // скрываем кнопку
//         parent.mainPage.tgBackShowHide( false );
//     } );
//
//     // показываем кнопку
//     parent.mainPage.tgBackShowHide( true );
// }

// запускаем инициализацию страницы магазина
$( window ).on( "load", shopPage.init );
