let spacePage = new spacePageFunc();

function spacePageFunc () {
    let settingsStorageKey = "settings";
    let spaceCardsStorageKey = "spaceCards";

    let isLoadCards = false;                          // Индикатор того, что уже была загрузка данных карточек

    let cards = null;                                               // Данные всех карточек
    let byCards = null;                                             // Данные купленных юзером карточек
    let currentRazdelID = 0;                                          // Текущий открытый раздел
    let refCounts = 0;                                              // Количество рефералов юзера
    let navlabels = [lang.getText( "earth_command" ),
        lang.getText( "command_schuttle" ),
    lang.getText( "schuttle_equipment" )];
    let maxKm = 200000000;                                          // Расстояние до Марса
    let maxSpeed = 12300;                                           // Максимальная скорость
    let currCardID = null;                                          // ID карты, которую покупаем
    let currCardLvl = 0;                                            // Уровень покупаемой карточки
    let isBy = false;                                               // Индикатор активного процесса покупки карточки


    function init() {
        try {
            nav.selectMenuItem( "space" );

            // Удаляем карточки
            clearCards();

            // Добавляем слушатели событий
            addEvents();
        }
        catch (e) {
            console.error( e );
        }
    }

    //добавление событие
    function addEvents() {
        try {
            $( document ).on( "spaceCardsDataLoadSuccess", startCards );               // Успешное завершение загрузки данных карточек
            $( document ).on( "userMainDataStorageSuccess userMainDataLoadSuccess", userDataLoad );                 // Успешное завершение загрузки данных юзера

            $( "#navSpace > [nav-space-id]" ).on( "click", navClick );                  // Клик на шапку раздела

            $( document ).on( "settingsLoadSuccess", settingsLoad );                    // Загрузились настройки юзера
        }
        catch (e) {
            console.error( e );
        }
    }

    // Загрузились настройки юзера
    function settingsLoad( e ) {
        try {
            let settings = JSON.parse( localStorage.getItem( settingsStorageKey ) );

            // Если не было первой инструкции
            if ( !settings.isEndFirstInstr ) {
                // Запускаем шаг инструкции
                runFirstInstr( 3 );
            }
        }
        catch (e) {
            console.error( e );
        }
    }

    // Обновление данных страницы
    function reload() {
        try {
            // запускаем загрузку данных юзера
            user.loadMainData();
        }
        catch (e) {
            console.error( e );
        }
    }


    // Успешное завершение загрузки данных юзера
    function userDataLoad ( e ) {
        try {
            // console.error(e);

            if ( !isLoadCards ) {
                // Загружаем данные карточек
                loadCards();
            }

            let userData = user.getMainUserData();

            // Текущее пройденное расстояние
            //let currentKm = userData.km;
            //let startTimeSpeed = new Date( userData.speedStartTime.replace( " ", "T" ) );
            //let now = new Date();

            // Добавляем к расстоянию расстояние при текущей скорости
            //currentKm += parseInt( ( now.getTime() - startTimeSpeed.getTime() ) / ( 1000 * 60 * 60 * 24 ) * userData.speed );

            // Ставим полоску
            $( "#sSLine > div" ).css( {
                "width" : (userData.speed / maxSpeed * 100) + "%"
            } );

            /*let lostKm = maxKm - currentKm;

            // Если меньше 1 мл
            if ( lostKm < 1000000 ) {
                lostKm = formatNumber( lostKm ) + " км";
            }
            else {
                lostKm = ( lostKm / 1000000 ).toFixed( 1 ) + " млн км";
            }*/

            $( ".sSBSpeed > span" ).html( formatNumber( userData.speed ) + " " + lang.getText( "speed_short" ) );
            $( ".sSBRockets > span" ).html( formatNumber( userData.balanceRockets ) + " " + lang.getText( "rockets" ) );

            $( "#nCRockets > div > span" ).html( formatNumber( userData.balanceRockets ) );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Запуск показа карточек
    function startCards () {
        try {
            // Если карточки уже были загружены
            if ( isLoadCards ) {
                return;
            }

            isLoadCards = true;

            // Кликаем на первый раздел или на нужный, если он был задан
            $( "#navSpace > [nav-space-id=\"" + (currentRazdelID <= 0 ? 1 : currentRazdelID) + "\"]" ).trigger( "click" );
        }
        catch (e) {
            console.error( e );
        }
    }

    // Загрузка карточек
    function loadCards ( ) {
        try {
            // console.log( "Локальное хранилище", localStorage.getItem( spaceCardsStorageKey ) );

            // Если есть данные в хранилище
            if ( localStorage.getItem( spaceCardsStorageKey ) !== undefined && localStorage.getItem( spaceCardsStorageKey ) !== null ) {
                let storageData = JSON.parse( localStorage.getItem( spaceCardsStorageKey ) );

                // console.log( storageData );

                // Берём данные карточек
                cards = storageData.cards;
                byCards = storageData.byCards;

                // берём доп. данные
                refCounts = storageData.refCounts

                $( document ).trigger( "spaceCardsDataLoadSuccess" );

                return;
            }

            // Грузим данные
            $.ajax({
                url : "/apprin/v1/space/load_cards_users/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Берём данные карточек
                        cards = resp.data.cards;
                        byCards = resp.data.byCards;

                        // берём доп. данные
                        refCounts = resp.data.refCounts

                        $( document ).trigger( "spaceCardsDataLoadSuccess" );
                    }
                    catch ( err ) {
                        console.error( e );
                    }
                },
                error : function ( err ) {
                    console.error( e );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error( e );
        }
    }

    // Очистка карточек
    function clearCards ( ) {
        try {
            $( "#nCItems > *" ).remove();
        }
        catch (e) {
            console.error( e );
        }
    }

    // Перестроение карточек
    function rebuildCards ( ) {
        try {
            // чистим
            clearCards();

            let items = $( '<div></div>' );
            let userData = user.getMainUserData();

            for ( let card of cards[ currentRazdelID.toString() ] ) {
                let item = $( '<div>' +
                    '<div class="nCItem">' +
                    '                <div class="nCIImg"></div>' +
                    '' +
                    /*'                <div class="nCIBlock">' +
                    '                    <img src="/resources/img/lock.svg" />' +
                    '                </div>' +*/
                    '' +
                    '                <div class="nCIBackground"></div>' +
                    '' +
                    '                <div class="nCILabel">' +
                    '                    <span class="smallLargerFontSize"></span>' +
                    '                </div>' +
                    '' +
                    '                <div class="nCIBottom">' +
                    '                    <div class="nCIBTop">' +
                    '                        <div class="nCIBTLvl">' +
                    '                            <span>lvl 0</span>' +
                    '                        </div>' +
                    '' +
                    '                        <div class="nCIBTLine"></div>' +
                    '' +
                    '                        <div>' +
                    '                            <div class="nCIBTSpeedAdd">' +
                    '                                <img src="/resources/img/speed.png" />' +
                    '' +
                    '                                <span>+ 0</span>' +
                    '                            </div>' +
                    '' +
                    '                            <span class="verySmallFontSize grayFontColor">' + lang.getText( "to_schuttle_speed" ) + '</span>' +
                    '                        </div>' +
                    '                    </div>' +
                    '' +
                    '                    <div class="nCIBBottom">' +
                    '                        <img src="/resources/img/rocket_angle.png" />' +
                    '' +
                    '                        <span class="largerFontSize blueGradientFont">0</span>' +
                    '                    </div>' +
                    '                </div>' +
                    '            </div>' +
                    '</div>' );

                // console.log( card );

                // Данные этой карточки, купленной юзером
                let byCardData = getItemByKeyValue( byCards, "cardID", card.id );
                // Данные карточки для построения
                let buildCardData = {
                    "lvl" : 1,
                    "price" : card.data.prices[ 0 ],
                    "speed" : card.data.speeds[ 0 ],
                    "requirements" : card.data.requirements.hasOwnProperty( 0 ) ? card.data.requirements[ 0 ] : {},
                    "isBlock" : false,
                    "blockText" : "",
                    "isMax" : false
                };

                // Если есть такая купленная карточка
                if ( byCardData !== null ) {
                    // Если уровень карточки максимальный куплен
                    if ( card.data.prices.length === byCardData.lvl ) {
                        buildCardData.isMax = true;
                    }

                    // текущий уровень
                    let currentLvl = byCardData.lvl;

                    // Меняем данные карточки для построения на следующий уровень
                    buildCardData.lvl = currentLvl + 1;
                    buildCardData.price = card.data.prices[ currentLvl ];
                    buildCardData.speed = card.data.speeds[ currentLvl ];
                    buildCardData.requirements = card.data.requirements.hasOwnProperty( currentLvl ) ? card.data.requirements[ currentLvl ] : {}
                }

                // Если есть условия для покупки
                if ( Object.keys( buildCardData.requirements ).length > 0 ) {
                    // Если есть минимум рефералов
                    if ( buildCardData.requirements.hasOwnProperty( "minReferals" ) ) {
                        // Если у юзера меньше минимума рефералов
                        if ( refCounts < buildCardData.requirements.minReferals ) {
                            // Блокируем карточку
                            buildCardData.isBlock = true;
                            buildCardData.blockText = lang.getText( "need_refs" ) +  "<br/>" +
                                buildCardData.requirements.minReferals + " " + lang.getText( "friends" );
                        }
                    }

                    // Если минимальный уровень другой карточки
                    if ( buildCardData.requirements.hasOwnProperty( "cardLvl" ) ) {
                        // данные связанной карточки
                        let needCardLvl = buildCardData.requirements.cardLvl;

                        // ищем в купленных нужную карточку
                        let needByCard = getItemByKeyValue( byCards, "cardID", needCardLvl.cardID );

                        // console.log( needCardLvl, needByCard );

                        // Если карта не куплена или уровень меньше минимума
                        if ( needByCard === null || needByCard.lvl < needCardLvl.minLvl ) {
                            // ищем среди всех нужную карточку
                            let needCard = getItemByKeyValue( cards[ currentRazdelID.toString() ], "id", needCardLvl.cardID );

                            // Блокируем карточку
                            buildCardData.isBlock = true;
                            buildCardData.blockText = needCard.name + "<br/>lvl " + needCardLvl.minLvl
                        }
                    }
                }

                // Если стоимость больше баланса ракет
                if ( buildCardData.price > userData.balanceRockets ) {
                    // Блокируем карточку
                    buildCardData.isBlock = true;
                    buildCardData.blockText = lang.getText( "no_exist" ) + "<br/>" +
                        (buildCardData.price - userData.balanceRockets) + " " + lang.getText( "rockets" );
                }

                // Если золотая
                if ( card.type === 3 ) {
                    $( ".nCItem", item ).addClass( "nCItemGold" );
                }

                // Если максимальный лвл
                if ( buildCardData.isMax ) {
                    buildCardData.lvl--;

                    $( ".nCIBBottom", item ).html( '<span class="">Max lvl</span>' );

                    buildCardData.speed = card.data.speeds[ buildCardData.lvl - 1 ]
                }

                $( ".nCItem", item ).attr({
                    "space-card-id" : card.id,
                    "space-card-lvl" : buildCardData.lvl
                });
                $( ".nCIImg", item ).css({
                    "background-image" : "url(\'/resources/img/space/cards/" + card.img + "\')"
                });
                $( ".nCILabel > span", item ).html( card.name );
                $( ".nCIBTLvl > span", item ).html( "lvl " + buildCardData.lvl );
                $( ".nCIBTSpeedAdd > span", item ).html( buildCardData.speed );

                // Если не заблокирована
                if ( !buildCardData.isBlock ) {
                    $( ".nCIBBottom > span", item ).html( buildCardData.price );

                    // Если не максимальный лвл
                    if ( !buildCardData.isMax ) {
                        // Добавляем события
                        $( ".nCIBBottom", item ).on( "click", cardClick );                              // Клик на покупку карточки
                    }
                }
                else {
                    $( ".nCItem", item ).addClass( "nCItemBlock" );
                    $( ".nCIBBottom", item ).html( '<span class="">' + buildCardData.blockText + '</span>' );
                }

                // Добавляем карточку к другим
                items.append( item.contents() );
            }

            $( "#nCItems" ).append( items.contents() );
        }
        catch (e) {
            console.error( e );
        }
    }

    // Клик на покупку карточки
    function cardClick ( e ) {
        tg?.HapticFeedback?.impactOccurred?.('soft')

        try {
            // Пишем содержимое контента
            $( ".popupContent" ).html( '' +
                '<img class="popupClose" src="/resources/img/exitIcon.svg" />' +
                '' +
                '        <div class="popupImg" style=""></div>' +
                '' +
                '        <div class="popupLabel">' +
                '            <span class="smallLargerFontSize"></span>' +
                '        </div>' +
                '' +
                '        <div class="popupRockets">' +
                '            <img src="/resources/img/rocket_hor.webp" />' +
                '' +
                '            <span class="blueGradientFont largerFontSize"></span>' +
                '        </div>' +
                '' +
                '        <div class="popupCardData">' +
                '            <div id="pCDLvl">' +
                '                <span class="smallLargerFontSize"></span>' +
                '            </div>' +
                '' +
                '            <div class="nCIBTLine"></div>' +
                '' +
                '            <div id="pCDSpeed">' +
                '                <img src="/resources/img/speed.png" />' +
                '' +
                '                <div>' +
                '                    <div>' +
                '                        <span class="smallLargerFontSize"></span>' +
                '                    </div>' +
                '' +
                '                    <span class="grayFontColor smallFontSize">' +
                '                        ' + lang.getText( "to_schuttle_speed" ) +
                '                    </span>' +
                '                </div>' +
                '            </div>' +
                '        </div>' +
                '' +
                '        <a href="" target="_blank" class="btn popupBtn popupBtnCardBy">' +
                '            <span>' + lang.getText( "by" ) + '</span>' +
                '        </a>' );
            
            // ID карты
            let cardID = parseInt( $( e.currentTarget ).parents( "[space-card-id]" ).attr( "space-card-id" ) );
            // Уровень карты
            let lvl = parseInt( $( e.currentTarget ).parents( "[space-card-id]" ).attr( "space-card-lvl" ) );
            // Данные карты
            let cardData = getItemByKeyValue( cards[ currentRazdelID.toString() ], "id", cardID );

            currCardID = cardID;
            currCardLvl = lvl;

            // Меняем данные попап-а
            $( ".popupImg" ).css({
                "background-image" : "url('/resources/img/space/cards/" + cardData.img + "')"
            });
            $( ".popupLabel > span" ).html( cardData.name );
            $( ".popupRockets > span" ).html( cardData.data.prices[ lvl - 1 ] );
            $( "#pCDLvl > span" ).html( "lvl " + lvl );
            $( "#pCDSpeed > div > div:first-child > span" ).html( "+" + cardData.data.speeds[ lvl - 1 ] );

            // Показываем попап
            showHidePopup();

            // Добавляем события попап-у
            addDelEventsPopup();
            $( ".popupBtnCardBy" ).on( "click", byClick );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Клик на кнопку покупки
    function byClick ( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            if ( isBy ) {
                return;
            }

            isBy = true;

            $.ajax({
                url : "/apprin/v1/space/by_card/",
                data : "id=" + user.getAllUserData().uuid + "&cardID=" + currCardID + "&lvl=" + currCardLvl,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        let cardIndex = getItemIndexByKeyValue( byCards, "cardID", resp.data.byCard.cardID );

                        if ( cardIndex === null || cardIndex < 0 ) {
                            // console.log( "Добавили карточку в купленные" );

                            byCards.push( resp.data.byCard );
                        }
                        else {
                            // Меняем данные купленной карточки
                            byCards[ cardIndex ] = resp.data.byCard;

                            // console.log( "Поменяли данные купленной карточки" );
                        }

                        // Показываем оповещение
                        showHideNotifLine( true, lang.getText( "card_success_by" ) );

                        // Скрываем попап
                        showHidePopup( false );

                        // Меняем баланс
                        user.setMainUserData( "balanceRockets", user.getMainUserData().balanceRockets - resp.data.byData.sum );

                        // Меняем скорость
                        user.setMainUserData( "speed", user.getMainUserData().speed + resp.data.byCard.speed );

                        // Перестраиваем элементы на странице, связанные с данными юзера (ракеты, скорость)
                        userDataLoad();

                        let itemsElement = $( "#nCItems" );
                        let scrollTop = itemsElement.scrollTop();

                        // Перестраиваем карточки
                        rebuildCards();

                        // Отматываем как было
                        itemsElement.scrollTop( scrollTop );

                        // Загружаем новые данные
                        system.loadSpaceCards();

                        // У родителя подгружаем новые данные
                        parent.mainPage.reloadMainUserData();

                        // Обновляем данные на зависимых страницах
                        parent.mainPage.reload( "rating" );
                    }
                    catch ( err ) {
                        console.error( e );
                    }
                },
                error : function ( err ) {
                    console.error( e );
                },
                complete : function () {
                    isBy = false;

                    navigator.vibrate( 200 );
                }
            });
        }
        catch (e) {
            console.error( e );

            isBy = false;
        }
    }


    // Клик на шапку раздела
    function navClick ( e ) {
        try {
            // новый ИД раздела
            let newRazdelID = parseInt( $( e.currentTarget ).attr( "nav-space-id" ) );

            if ( newRazdelID === currentRazdelID ) {
                return;
            }

            // Записываем новый раздел
            currentRazdelID = newRazdelID;

            // Выделяем новый раздел
            selectNav( currentRazdelID );

            // Перестраиваем карточки
            rebuildCards();
        }
        catch (e) {
            console.error( e );
        }
    }

    // Выделение нужного раздела
    function selectNav ( razdelID ) {
        try {
            // Скрываем раздел
            $( "[nav-space-id][select=\"1\"]:not([nav-space-id=\"" + razdelID + "\"])" ).attr({
                "select" : "0"
            });

            // Выделяем раздел
            $( "[nav-space-id=\"" + razdelID + "\"]" ).attr({
                "select" : "1"
            });

            // Меняем заголовок
            $( "#navSpaceLabel > span" ).html( navlabels[ razdelID - 1 ] );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );

            // Скрываем кнопку перехода
            $( ".popupBtnLink" ).addClass( "hide" );
            // Меняем надпись на старую
            $( ".popupBtn > span" ).html( "Перейти" );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ первой инструкции
    function runFirstInstr( stepInstr = 1 ) {
        try {
            // Пишем контент
            $( ".popupContent" ).html( '' +
                '        <div id="pCFirstInstr">' +
                "            <div id=\"pCFIImg\" style=\"background-image: url(/resources/img/instruction/" + stepInstr + ".png);\"></div>" +
                '' +
                '            <span class="smallLargerFontSize">' + lang.getText( "first_instr_text_" + stepInstr ) + '</span>' +
                '        </div>' +
                '' +
                '        <a href="#" target="_blank" class="btn popupBtn" instr-step="' + stepInstr + '">' +
                '            <span>' + ( stepInstr !== 6 ? lang.getText( "next" ) : lang.getText( "fly" ) ) + '</span>' +
                '        </a>' ).addClass( "mb" );

            // Показываем
            showHidePopup();

            // Клик на кнопку
            $( ".popupBtn" ).on( "click", runFirstInstrBtnClick );
        }
        catch (e) {
            console.error( e );
        }
    }
    // Клик на кнопку первой инструкции
    function runFirstInstrBtnClick( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            let stepsItem = {
                "1" : "main",
                "2" : "life",
                "3" : "space",
                "4" : "friends",
                "5" : "earn",
                "6" : "life"
            };
            let stepInstr = parseInt( $( e.currentTarget ).attr( "instr-step" ) );

            stepInstr++;

            // Если последний этап
            if ( stepInstr === 6 ) {
                // Закрываем попап
                closePopup();

                // Записываем настройки
                $.ajax({
                    url : "/apprin/v1/settings/setAllFirst/",
                    data : "id=" + user.getAllUserData().uuid,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            system.setSettings( "isEndFirstInstr", true );

                            // Кликаем на нужный пункт меню
                            $( "[nav-item=\"life\"]" ).trigger( "click" );
                        }
                        catch ( err ) {
                            console.error( e );
                        }
                    },
                    error : function ( err ) {
                        console.error( e );
                    },
                    complete : function () {

                    }
                });
            }
            else {
                // Если не предпоследний пункт
                if ( stepInstr !== 5 ) {
                    // Переходим по нужному адресу
                    window.location.href = $("[nav-item=\"" + stepsItem[stepInstr.toString()] + "\"]").attr( "href" );
                }
                else {
                    // Закрываем попап
                    closePopup();

                    setTimeout( function () {
                        // Снова показываем инструкцию
                        runFirstInstr( stepInstr );
                    }, 500 );
                }
            }
        }
        catch (e) {
            console.error( e );
        }
    }


    return {
        init: function() {
            init();
        },
        reload: function () {
            reload();
        }
    }
}

// Обновление данных страницы
window[ "reload" ] = function reload ( ) {
    spacePage.reload();
}

// запускаем инициализацию страницы Space
$( window ).on( "load", spacePage.init );
