let mainPage = new mainPageFunc();

function mainPageFunc () {
    let settingsStorageKey = "settings";
    let isSaveSettings = false;

    let isAssistantModal = false;

    let isMaskClick = false;                       // Индикатор того, что идёт обработка клика на Маск-а

    let queue = new queueFunc();                    // Элемент для работы с очередями на выполнение задач

    let balanceInHourTimer = null;                  // Таймер обновления баланса при пассивном заработке

    let noCryptPayOrdersTimer = null;               // таймер проверки неоплаченных криптой заказов
    let noCryptPayOrders = [];                      // неоплаченные криптой заказы

    let settings = null;                            // настройки юзера

    let isFirst = true;


    function init() {
        try {
            // Удаляем элемент с данными предзагрузки
            $( "#preload" ).remove();

            nav.selectMenuItem( "main" );

            queue.setNeedStartIndicator( 1 );
            queue.setQueueAction([
                [ build, [] ]
            ]);

            addEvents();

            // Анимируем некоторые элементы
            setTimeout( function () {
                $( "#cTop, #cShop" ).addClass( "animScale" );
            }, 1000 );

            // Получаем данные для предзагрузки в фоне
            $.ajax({
                url : "/apprin/v1/preload/get_background/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            isSaveSettings = false;

                            return;
                        }

                        // Запускаем загрузку в фоне
                        $( "#preloadBackground" ).html( resp.data );
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {

                }
            });
        }
        catch (e) {
            console.error( e );
        }
    }

    // Показ/Скрытие слоя загрузки
    function showHideLoading( isShow = true ) {
        try {
            if ( isShow ) {
                $( "#loading" ).addClass( "show" );
            }
            else {
                $( "#loading" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error( e );
        }
    }

    //добавление событие
    function addEvents() {
        try {
            // Готовность ТГ объекта
            $( document ).on( "tgReady", tgReady );

            $( "#cMCSettings" ).on( "click", settingsClick );                   // Клик на настройки

            $( "#cShop" ).on( "click", showShop );

            $( document ).on( "modalShow", modalShow );
            $( document ).on( "modalClose", modalClose );

            // Загружена основная информация о юзере
            $( document ).on( "userMainDataLoadSuccess", setQueue );

            $( "#cTRating" ).on( "click", ratingClick );                        // Клик на рейтинг

            $( "#cPhoto > div:nth-child( 2 )" ).on( "click", maskClick );                        // Клик на Маск-а
            $( "#soundBtn" ).on( "click", maskSoundClick );                                     // Клик на звук у Маск-а

            $( document ).on( "settingsLoadSuccess", settingsLoad );                    // Загрузились настройки юзера
		}
        catch (e) {
            console.error( e );
        }
    }

    // Загрузились настройки юзера
    function settingsLoad( e ) {
        try {
            isSaveSettings = false;

            settings = JSON.parse( localStorage.getItem( settingsStorageKey ) );

            // Если звук выкл
            if ( settings.isSoundMusk !== true ) {
                $( "#soundBtn" ).attr( "src", "/resources/img/sound_off.svg" );
            }
            else {
                $( "#soundBtn" ).attr( "src", "/resources/img/sound_on.svg" );
            }

            // Если не было первой инструкции
            if ( !settings.isEndFirstInstr ) {
                // Запускаем шаг инструкции
                runFirstInstr( 1 );
            }
        }
        catch (e) {
            console.error( e );
        }
    }

    // Клик на настройки
    function settingsClick( e ) {
        try {
            nav.selectMenuItem( "main" );

            // TODO: check or delete comment #2
            $("#content.main-page").hide()
            $(".page-content#settings_page").addClass( "show" );
        }
        catch (e) {
            console.error( e );
        }
    }


    //Готовность ТГ объекта
    function tgReady() {
        try {
            // console.log( "TG", tg );

            tg.BackButton.isVisible = true;
            tg.BackButton.hide();
        }
        catch (e) {
            console.error( e );
        }
    }


    // Установка отметки о достижении одной из целей очереди
    function setQueue( ) {
        try {
            queue.startQueue();
        }
        catch (e) {
            console.error( e );
        }
    }


    // Запуск таймера пассивного заработка
    function startBalanceInHourTimer( ) {
        try {
            clearBalanceInHourTimer( );

            // Если монеты не зарабатываются
            if ( user.getMainUserData().balanceInHour === 0 ) {
                // console.log( "Монеты не зарабатываются" );

                return;
            }

            balanceInHourTimer = setTimeout( continueBalanceInHourTimer, 3000 );
        }
        catch (e) {
            console.error( e );
        }
    }
    // Очистка таймера пассивного заработка
    function clearBalanceInHourTimer( ) {
        try {
            if ( balanceInHourTimer !== null ) {
                clearTimeout( balanceInHourTimer );

                balanceInHourTimer = null;
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Продолжение таймера пассивного заработка
    function continueBalanceInHourTimer( ) {
        try {
            clearBalanceInHourTimer( );

            // Время старта
            let enterTime = new Date( user.getMainUserData().balanceInHourStartTime.replace( " ", "T" ) );
            // Текущее время
            let nowTime = new Date();
            // Текущее московское время
            let nowMoscowTime = new Date( nowTime.getTime() + (180 + nowTime.getTimezoneOffset()) * 60 * 1000 );

            // Из текущего времени вычитаем разницу часовых поясов
            //nowTime.setHours( nowTime.getHours() - 7 );

            // Разница дат во времени
            let diff = ( nowMoscowTime.getTime() - enterTime.getTime() ) / 1000 / 60 / 60;
            // Монет в час
            let moneyInHour = user.getMainUserData().balanceInHour;
            // Надо добавить монет
            let addBalance = parseInt( diff * moneyInHour );

            // console.log( "Время входа " + enterTime, "Сейчас " + nowMoscowTime, "Разница " + diff + " ч.", "В час "  +moneyInHour,
            //     "Добавим на баланс " + addBalance, "Текущий баланс юзера " + user.getMainUserData().balance );

            // Если надо добавить больше или равно 1
            if ( addBalance >= 1 ) {
                // console.log( "new balance " + (user.getMainUserData().balance + addBalance) );

                user.setMainUserData( "balance", user.getMainUserData().balance + addBalance );
                user.setMainUserData( "balanceInHourStartTime", nowMoscowTime.toJSON().replace( "T", " " ) );

                // Выводим новый баланс
                $( '[data-input-key="balance"]' )
                    .removeClass( "animScale" )
                    .html( formatNumber( user.getMainUserData().balance + addBalance - 1 ) );

                setTimeout( function () {
                    $( '[data-input-key="balance"]' ).addClass( "animScale" );
                }, 100 );
            }

            balanceInHourTimer = setTimeout( continueBalanceInHourTimer, 3000 );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Клик на Маск-а
    function maskClick( e ) {
        try {
            if ( isMaskClick ) {
                return;
            }

            isMaskClick = true;

            // Показываем текст
            $( "#cPText" ).addClass( "show" );

            // Запускаем анимацию
            $( "#cPhoto > div:nth-child( 2 )" ).addClass( "photoAnim" );

            // Если стоит звук
            if ( settings.isSoundMusk ) {
                // Запускаем аудио
                $("#muskAudio")[0].play();
            }

            setTimeout( function() {
                // Скрываем текст
                $( "#cPText" ).removeClass( "show" );

                // Удаляем анимацию
                $( "#cPhoto > div:nth-child( 2 )" ).removeClass( "photoAnim" );

                isMaskClick = false;
            }, 4500 );
        }
        catch (e) {
            console.error( e );

            isMaskClick = false;
        }
    }

    // Клик на звук у Маск-а
    function maskSoundClick( e ) {
        try {
            if ( settings === null ) {
                return;
            }

            if ( isSaveSettings ) {
                return;
            }

            isSaveSettings = true;

            settings.isSoundMusk = !settings.isSoundMusk === true;

            // Записываем настройки
            $.ajax({
                url : "/apprin/v1/settings/setAll/",
                data : "id=" + user.getAllUserData().uuid +
                    "&isV=" + ( settings.isVibration === true ? 1 : 0 ) +
                    "&isMS=" + ( settings.isSoundMusk === true ? 1 : 0 ),
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            isSaveSettings = false;

                            return;
                        }

                        // Если звук был вкл
                        if ( settings.isSoundMusk ) {
                            showHideNotifLine( true, lang.getText( "sound_on" ), "volume_on.svg" );
                        }
                        else {
                            showHideNotifLine( true, lang.getText( "sound_off" ), "volume_off.svg" );
                        }

                        system.loadSettings();
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {

                }
            });
        }
        catch (e) {
            console.error( e );

            isSaveSettings = false;
        }
    }

    // Клик на рейтинг
    function ratingClick( e ) {
        try {
            nav.selectMenuItem( "main" );

            // TODO: check or delete comment #3
            $("#content.main-page").hide()
            $(".page-content#rating_page").addClass( "show" );
            window?.pageOpen?.['rating']?.();
        }
        catch (e) {
            console.error( e );
        }
    }

    // Построение стартового экрана
    function build( ) {
        try {
            // Загружена основная информация о юзере
            $( document ).off( "userMainDataStorageSuccess userMainDataLoadSuccess", setQueue );
            $( document ).off( "userMainDataLoadSuccess", build ).on( "userMainDataLoadSuccess", build );

            let mainUserData = user.getMainUserData();

            // Выводим значения на страницу
            if ( parseArrayToElementData( mainUserData ) === false ) {
                return;
            }

            // обновляем Шапку
            updateHead();

            setTimeout( function () {
                // Скрываем слой загрузки
                showHideLoading( false );
            }, 3000 );

            // Если есть баланс для добавления на счёт
            if ( mainUserData.addBalance > 0 ) {
                // Пишем контент
                $( ".popupContent" ).html( '' +
                    '<div class="popupLabel">' +
                    '            <span class="smallLargerFontSize">' + lang.getText( "add_money_background" ) + '</span>' +
                    '        </div>' +
                    '' +
                    '        <div id="pCAddBalance">' +
                    '            <img src="/resources/img/earn.svg" />' +
                    '' +
                    '            <span class="goldGradientFont largFontSize">+' + formatNumber( mainUserData.addBalance ) + '</span>' +
                    '        </div>' +
                    '' +
                    '        <a href="" target="_blank" class="btn popupBtn">' +
                    '            <span>Закрыть</span>' +
                    '        </a>' );

                // Показываем
                showHidePopup();

                // Клик на кнопку Закрыть
                $( ".popupBtn" ).on( "click", closeAddBalance );

                // Перемещаем баланс из добавления на реальный счёт
                $.ajax({
                    url : "/apprin/v1/user/move_balance_to_real/",
                    data : "id=" + user.getAllUserData().uuid,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            // Меняем баланс на новый
                            user.setMainUserData( "balance", resp.data.balance );

                            // Обновляем информаию на странице
                            parseArrayToElementData( user.getMainUserData() );
                        }
                        catch ( err ) {
                            console.error( err );
                        }
                    },
                    error : function ( err ) {
                        console.error( err );
                    },
                    complete : function () {
                    }
                });
            }

            // Запускаем таймер пассивного дохода
            startBalanceInHourTimer();

            // Загружаем данные оповещений о оплаченных заказах
            loadPayOrdersNotif();

            // Загружаем данные заказов, не оплаченных криптой и не старых
            //loadNoPayCryptOrders();
        }
        catch (e) {
            console.error( e );
        }
    }


    // Загрузка данных заказов, не оплаченных криптой и не старых
    /*function loadNoPayCryptOrders( ) {
        try {
            $.ajax({
                url : "/apprin/v1/user/loadNoPayCryptOrders/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        for ( let i = 0; i <= resp.data.rockets.length - 1; i++ ) {
                            resp.data.rockets[ i ][ "itemType" ] = 1;
                        }

                        for ( let i = 0; i <= resp.data.assistents.length - 1; i++ ) {
                            resp.data.assistents[ i ][ "itemType" ] = 2;
                        }

                        noCryptPayOrders.push( resp.data.rockets );
                        noCryptPayOrders.push( resp.data.assistents );

                        // Если есть неоплаченные криптой заказы
                        if ( noCryptPayOrders.length > 0 ) {
                            startNoCryptPayOrdersTimer(); // запускаем проверку
                        }
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error( e );
        }
    }

    // Запуск таймера проверки оплаты криптой
    function startNoCryptPayOrdersTimer( ) {
        try {
            clearNoCryptPayOrdersTimer( );

            noCryptPayOrdersTimer = setTimeout( continueNoCryptPayOrdersTimer, 10000 );
        }
        catch (e) {
            console.error( e );
        }
    }
    // Очистка таймера проверки оплаты криптой
    function clearNoCryptPayOrdersTimer( ) {
        try {
            if ( noCryptPayOrdersTimer !== null ) {
                clearTimeout( noCryptPayOrdersTimer );

                noCryptPayOrdersTimer = null;
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Продолжение таймера проверки оплаты криптой
    function continueNoCryptPayOrdersTimer( ) {
        try {
            clearNoCryptPayOrdersTimer( );

            // Проверяем
            $.ajax({
                url : "/apprin/v1/user/" + (noCryptPayOrders[ noCryptPayOrders.length - 1 ].itemType === 1 ? "byCheck" : "byCheckAssist") + "/",
                data : "id=" + user.getAllUserData().uuid + "&orderID=" + noCryptPayOrders[ noCryptPayOrders.length - 1 ].id +
                    "&hash=" + noCryptPayOrders[ noCryptPayOrders.length - 1 ].hash,
                type : "POST",
                success : function ( responce ) {
                    console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если оплата успешна
                        if ( resp.data ) {
                            // Добавляем на баланс нужное количество ракет
                            user.setMainUserData( "balanceRockets", user.getMainUserData().balanceRockets + products[ currentItemIndex ].earn );

                            // Показываем оповещение
                            showHideNotifLine( true, "Ракеты куплены", "end.png", products[ currentItemIndex ].earn );

                            // Скрываем попап
                            addDelEventsPopup( false );
                            showHidePopup( false );

                            isPay = false;
                        }
                        else {
                            // Если время меньше или равно максимума
                            if ( currPayTime + payTime <= maxPayTime * 60 ) {
                                // Снова запускаем таймер
                                payTimer = setTimeout( continueByCheckTimer, payTime * 1000 );
                            }
                            else {
                                // Показываем оповещение
                                showHideNotifLine( true, "Error pay", "error.png" );

                                // Скрываем попап
                                addDelEventsPopup( false );
                                showHidePopup( false );

                                isPay = false;
                            }
                        }
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );

                    isPay = false;
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error( e );
        }
    }*/


    // Загрузка данных оповещений о оплаченных заказах
    function loadPayOrdersNotif( ) {
        try {
            $.ajax({
                url : "/apprin/v1/user/loadNotifOrders/",
                data : "id=" + user.getAllUserData().uuid,
                type : "POST",
                success : function ( responce ) {
                    // console.log( responce );

                    try {
                        let resp = JSON.parse( responce ); //парсим ответ сервера

                        if ( resp.status !== "ok" ) {
                            return;
                        }

                        // Если есть покупки ракет
                        if ( resp.data.rockets.length > 0 ) {
                            let allSum = 0;

                            for ( let prodItem of resp.data.rockets ) {
                                allSum += prodItem.earn;
                            }

                            showHideNotifLine( true, lang.getText( "byed_rockets" ), "end.png", allSum );
                        }

                        // Если есть покупки ассистентов
                        if ( resp.data.assistents.length > 0 ) {
                            showHideNotifLine( true, lang.getText( "byed_assistent" ), "end.png" );
                        }
                    }
                    catch ( err ) {
                        console.error( err );
                    }
                },
                error : function ( err ) {
                    console.error( err );
                },
                complete : function () {
                }
            });
        }
        catch (e) {
            console.error( e );
        }
    }


    // Клик на кнопку Закрыть в попапе добавления баланса
    function closeAddBalance( e ) {
        try {
            e.preventDefault();
            e.stopPropagation();

            // Закрываем попап
            showHidePopup( false );
        }
        catch (e) {
            console.error( e );
        }
    }

    // Обновление шапки
    function updateHead ( ) {
        try {
            let mainUserData = user.getMainUserData();

            // Меняем данные лиги
            $( "#cTRating > img" ).attr( "src", "/resources/img/leagues/" + mainUserData.userLeague.leagueID + ".png" );
            $( '[league-rating]' ).attr( "league-rating", mainUserData.userLeague.leagueID );

            parseArrayToElementData( mainUserData.userLeague );
        }
        catch (e) {
            console.error( e );
        }
    }

    // была показана модалка
    function modalShow( e ) {
        try {
            // Если была показана не модалка ассистента
            if ( !isAssistantModal ) {
                $( "#shopAssistent" ).on( "click", showAssistant );
            }
        }
        catch (e) {
            console.error( e );
        }
    }

    // была закрыта модалка
    function modalClose( e ) {
        try {
            // Если была показана ассистента
            if ( isAssistantModal ) {
                isAssistantModal = false;

                // показываем магазин
                showShop();
            }
        }
        catch (e) {
            console.error( e );
        }
    }

    //показ магазина
    function showShop( e ) {
        try {
            nav.selectMenuItem( "main" );

            // TODO: check or delete comment #4
            $("#content.main-page").hide()
            $(".page-content#shop_page").addClass( "show" );
            // $( "[nav-frame=\"shop\"]" )[ 0 ].contentWindow.start();
        }
        catch (e) {
            console.error( e );
        }
    }

    //показ ассистента
    function showAssistant( e ) {
        try {
            // закрываем прошлую модалку
            modal.closeModal();

            setTimeout( function () {
                isAssistantModal = true;

                modal.showModal( null, "", {modal : "shop_assistant"} );
            }, 300 );
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ первой инструкции
    function runFirstInstr( stepInstr = 1 ) {
        try {
            // Пишем контент
            $( ".popupContent" ).html( '' +
                '        <div id="pCFirstInstr">' +
                "            <div id=\"pCFIImg\" style=\"background-image: url(/resources/img/instruction/" + stepInstr + ".png);\"></div>" +
                '' +
                '            <span class="smallLargerFontSize">' + lang.getText( "first_instr_text_" + stepInstr ) + '</span>' +
                '        </div>' +
                '' +
                '        <a href="#" target="_blank" class="btn popupBtn" instr-step="' + stepInstr + '">' +
                '            <span>' + ( stepInstr !== 6 ? lang.getText( "next" ) : lang.getText( "fly" ) ) + '</span>' +
                '        </a>' ).addClass( "mb" );

            // Показываем
            showHidePopup();

            // Клик на кнопку
            $( ".popupBtn" ).on( "click", runFirstInstrBtnClick );
        }
        catch (e) {
            console.error( e );
        }
    }
    // Клик на кнопку первой инструкции
    function runFirstInstrBtnClick( e ) {
        try {
            e.stopPropagation();
            e.preventDefault();

            let stepInstr = parseInt( $( e.currentTarget ).attr( "instr-step" ) );

            stepInstr++;

            // console.log( "Новый этап", stepInstr );

            // Если последний этап
            if ( stepInstr === 6 ) {
                // Закрываем попап
                closePopup();

                // Записываем настройки
                $.ajax({
                    url : "/apprin/v1/settings/setAllFirst/",
                    data : "id=" + user.getAllUserData().uuid,
                    type : "POST",
                    success : function ( responce ) {
                        // console.log( responce );

                        try {
                            let resp = JSON.parse( responce ); //парсим ответ сервера

                            if ( resp.status !== "ok" ) {
                                return;
                            }

                            system.setSettings( "isEndFirstInstr", true );

                            // Кликаем на нужный пункт меню
                            $( "[nav-item=\"life\"]" ).trigger( "click" );
                        }
                        catch ( err ) {
                            console.error( err );
                        }
                    },
                    error : function ( err ) {
                        console.error( err );
                    },
                    complete : function () {

                    }
                });
            }
            else {
                // Если не предпоследний пункт
                // if ( stepInstr !== 5 ) {
                    closePopup();

                    if (stepInstr === 2) {
                        $('a[nav-item="life"]').trigger('click');
                        runFirstInstr(2)
                    }

                    if (stepInstr === 3) {
                        $('a[nav-item="space"]').trigger('click');
                        runFirstInstr(3)
                    }

                    if (stepInstr === 4) {
                        $('a[nav-item="friends"]').trigger('click');
                        runFirstInstr(4)
                    }

                    if (stepInstr === 5) {
                        $('a[nav-item="earn"]').trigger('click');
                        runFirstInstr(5)
                    }

                    if (stepInstr === 6) {
                        $('a[nav-item="life"]').trigger('click');
                        runFirstInstr(6)
                    }
                // }
                // else {
                //     // Закрываем попап
                //     closePopup();
                //
                //     setTimeout( function () {
                //         // Снова показываем инструкцию
                //         runFirstInstr( stepInstr );
                //     }, 500 );
                // }
            }
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ/Скрытие попап-а
    function showHidePopup( isShow = true ) {
        try {
            if ( isShow ) {
                $( ".popup" ).addClass( "popupShow" );
            }
            else {
                $( ".popup" ).removeClass( "popupShow" );
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Добавление/Удаление событий попап-а
    function addDelEventsPopup( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".popupBackground, .popupClose" ).on( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).on( "click", popupButtonClick );                           // клик на кнопку
            }
            else {
                $( ".popupBackground, .popupClose" ).off( "click", closePopup );             // Клик на закрывающие элементы
                //$( ".popupBtn" ).off( "click", popupButtonClick );                           // клик на кнопку
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Закрытие попап-а
    function closePopup(  ) {
        try {
            // НЕ УНИВЕРСАЛЬНЫЙ КОД
            currentCheckTask = null;

            // Скрываем
            showHidePopup( false );

            // Удаляем события
            addDelEventsPopup( false );

            // Удаляем события задачи попап-а
            // addDelTaskEventsPopup( false );

            // Скрываем кнопку перехода
            $( ".popupBtnLink" ).addClass( "hide" );
            // Меняем надпись на старую
            $( ".popupBtn > span" ).html( "Перейти" );

            // Удаляем стили ненужные. ЭТО НЕ УНИВЕРСАЛЬНЫЙ КОД
            $( ".popupContent" ).removeClass( "popupContentSmallPadding" );

            // Срасываем таймер
            // dailyQuizResetTimer();
        }
        catch (e) {
            console.error( e );
        }
    }


    // Показ/Скрытие линейного уведомления
    function showHideNotifLine( isShow = true, text = "", icon = "end.png", sum = -1 ) {
        try {
            if ( isShow ) {
                $( ".notifLine > img:first-child" ).attr( "src", "/resources/img/earn/" + icon );
                $( ".notifLine > span:nth-child(2)" ).html( text );

                // Если нет суммы
                if ( sum < 0 ) {
                    // Скрываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).addClass( "hide" );
                }
                else {
                    $( ".notifLine > span:nth-child(4)" ).html( "+" + sum );

                    // показываем поля некоторые
                    $( ".notifLine > span:nth-child(4), .notifLine > img:nth-child(3)" ).removeClass( "hide" );
                }

                // Добавляем события
                addDelEventsNotifLine();

                $( ".notifLine" ).addClass( "show" );

                notifLineTimer = setTimeout(function() {
                    // Закрываем
                    showHideNotifLine( false );
                }, 5000);
            }
            else {
                clearTimeout( notifLineTimer );

                notifLineTimer = null;

                // Удаляем события
                addDelEventsNotifLine( false );

                $( ".notifLine" ).removeClass( "show" );
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Добавление/Удаление событий линейного уведомления
    function addDelEventsNotifLine( isAdd = true ) {
        try {
            if ( isAdd ) {
                $( ".notifLine" ).on( "click", closeNotifLine );            // Клик на уведомление
            }
            else {
                $( ".notifLine" ).off( "click", closeNotifLine );            // Клик на уведомление
            }
        }
        catch (e) {
            console.error( e );
        }
    }
    // Закрытие линейного уведомления
    function closeNotifLine( ) {
        try {
            // Скрываем уведомление
            showHideNotifLine( false );
        }
        catch (e) {
            console.error( e );
        }
    }


    return {
        init: function() {
            init();
        },
        updateMoney: function () {
            // Обновляем данные по балансу и заработку
            user.readStorageMainUserData();

            let mainUserData = user.getMainUserData();

            // console.log( "Обновили данные монет на главной", mainUserData );

            // Выводим значения на страницу
            if ( parseArrayToElementData( mainUserData ) === false ) {
                return;
            }
        },
        updateHead: function () {
            user.readStorageMainUserData();

            // console.log( "Обновили данные шапки на главной", user.getMainUserData() );

            updateHead();
        },
        reload: function ( itemFrame ) {
            // console.log( "Content child", $( "[nav-frame=\"" + itemFrame + "\"]" )[ 0 ].contentWindow );

            // Обновляем данные страницы
            // $( "[nav-frame=\"" + itemFrame + "\"]" )[ 0 ].contentWindow.reload();
        },
        reloadMainUserData: function () {
            // Грузим новые данные юзера
            user.loadMainData();
        },
        tgBackCallback: function ( callback ) {
            // tg.BackButton.onClick( function ( ) {
            //     // console.log( "CLICK" );
            //
            //     // Вызываем функцию нужную
            //     callback();
            // } );
        },
        tgBackShowHide: function ( isShow = true ) {
            if ( isShow ) {
                tg.BackButton.show();
            }
            else {
                tg.BackButton.hide();
            }
        },
        activeMenuItem: function ( itemNav ) {
            $( "[nav-item=\"" + itemNav + "\"]" ).trigger( 'click' );
        }
    }
}

window[ "mainPage" ] = mainPage;

// запускаем инициализацию скрипта главной страницы
$( window ).on( "load", mainPage.init );
