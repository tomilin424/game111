<?php

/*
 * Класс для работы с языком
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "db.php";                              //для работы с базой


class lang
{
    // Получение текста нужного языка
    public function getLangText ( $lang = "ru", $char = null, $dataContent = null, $db = null, $isControlConnect = true ) {
        try {
            if ( is_null( $char ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `text` FROM `lang_" . strtolower( $lang ). "` WHERE `key` = :key";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "key" => strtolower( $char )
            ] );

            if ( is_null( $result ) || count( $result ) != 1 ) {
                throw new Exception( "Не удалось получить текст языка " . strtolower($char) );
            }

            $result = $result[ 0 ][ "text" ];

            // Если переданы данные для заполнения контента (вставок)
            if ( !is_null( $dataContent ) ) {
                foreach ( $dataContent as $key => $value ) {
                    $result = str_replace( "::" . $key . "::", strval( $value ), $result );
                }
            }
            

            return $result;
        }
        catch ( Exception $err ) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получение данных языка по ИД или char
    public function getLangData ( $id = null, $char = null, $db = null, $isControlConnect = true ) {
        try {
            if ( is_null( $char ) && is_null( $id ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `name`, `flag`, `char` 
                                FROM `langs` 
                              WHERE " . ( !is_null($id) ? "`id` = :id" : "`char` = :char" ) .
                ( $id < 0 ? " OR `id` > :id" : "" ). " 
                              ORDER BY `number` ASC";

            $arr = [];

            if ( !is_null( $id ) ) {
                $arr[ "id" ] = $id;
            }
            else {
                $arr[ "char" ] = $char;
            }

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $arr );

            if ( is_null( $result ) || count( $result ) == 0 ) {
                throw new Exception( "Не удалось получить языки" );
            }

            $items = [];

            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "name" => strval( $row[ "name" ] ),
                    "flag" => strval( $row[ "flag" ] ),
                    "char" => strval( $row[ "char" ] )
                ];

                $items[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $items
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }
}