<?php

/*
 * создано 03.02.2024 18:46 НСК
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "db.php";                              //для работы с базой
include_once CLOSE . "users.php";                           //для работы с пользователями


class actions
{
    //Добавление нового действия пользователя
    public static function addAction ( $userID = null, $actionID = null, $ip = null, $userAgentRow = null, $userAgent = null, $countryCode = null, $data = [] ) {
        $db = null;

        try {
            if ( is_null($userID) || is_null($actionID) || is_null($data) ) {
                throw new Exception( "Передан один из параметров в невалидном виде" );
            }

            $db = new db();

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            //запрос вставки данных
            $sqlInsert = "INSERT INTO `actions` (`users_id`, `action_types_id`, `ip`, `agent`, `data`, `country_code`, `agent_row`) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmtInsert = $db->getConnect()->prepare( $sqlInsert );

            $insertData = [
                $userID,
                $actionID,
                $ip,
                $userAgent == null ? $userAgent : json_encode($userAgent),
                json_encode($data),
                $countryCode,
                $userAgentRow
            ];

            //вставляем данные
            $result = $db->updatePrepare( $stmtInsert, "iisssss", $insertData );

            if ( $result !== true ) {
                throw new Exception( "Ошибка при выполнении запроса: " . $db->getLastError() );
            }

            //ответ
            $responce = [
                "status" => "ok"
            ];

            return $responce;
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    //Добавление нового действия пользователя (используя данные запроса)
    public static function addActionFromDirectRequest ( $userID = null, $actionID = null, $data = "{}" ) {
        try {
            $ip = users::GetRealIP();
            $userAgentRow = $_SERVER['HTTP_USER_AGENT'];
            $userAgent = json_encode( users::GetUserAgent() );
            $countryCode = users::GetUserCountryCode( $ip == null ? "" : $ip );

            //возвращаем результат добавления
            return self::addAction( $userID, $actionID, $ip, $userAgentRow, $userAgent, $countryCode, $data );
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
    }
}