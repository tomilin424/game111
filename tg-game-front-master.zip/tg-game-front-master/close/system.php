<?php
/*
 * создано 19.07.2024 19:26 НСК
 * */

include_once "constants.php";

include_once CLOSE . "db.php";                              //для работы с базой


class System
{
    //текст последней ошибки
    private $lastError = "";

    private $role = "";

    // настройки
    private $settings = [];

    function __construct( $role = "zeuspay" ) {
        $db = null;

        try {
            $this->role = $role;

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            //запрос поиска данных
            $sqlSelect = "SELECT * FROM `settings`";

            //ищем в базе
            $result = $db->select( $sqlSelect );

            if ( is_null( $result ) || count( $result ) == 0 ) {
                throw new Exception( "Не найдена информация" );
            }

            // Перебираем строки настроек
            foreach ( $result as $row ) {
                $this->settings[ $row[ "name" ] ] = json_decode( $row[ "data" ], true );
            }
        }
        catch ( Exception $err ) {
            $this->lastError = $err->getTraceAsString();

            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Поиск индекса элемента по значению ключа в массиве
    public function getIndexByKeyValue ( $array, $key, $value ) {
        try {
            //die( print_r($array, true) . " | " . $key . " | " . $value );

            foreach ( $array as $index => $subArr ) {
                if ( isset( $subArr[ $key ] ) && $subArr[ $key ] == $value ) {
                    return $index;
                }


            }

            return null;
        }
        catch ( Exception $err ) {
            return null;
        }
    }
    // Поиск элемента по значению ключа в массиве
    public function getElementByKeyValue ( $array, $key, $value ) {
        try {
            $index = $this->getIndexByKeyValue( $array, $key, $value );

            if ( is_null( $index ) ) {
                return null;
            }

            return $array[ $index ];
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    // Получить конфиги саппорта
    public function getReports ( ) {
        try {
            return $this->settings[ "report" ];
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    // Получить конфиги квиз-а
    public function getConfigsQuiz ( ) {
        try {
            return $this->settings[ "quiz" ];
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    // Получить конфиги вознаграждений за реферала
    public function getConfigsReferals ( ) {
        try {
            return $this->settings[ "referals" ];
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    public function getLastError () {
        return $this->lastError;
    }
}