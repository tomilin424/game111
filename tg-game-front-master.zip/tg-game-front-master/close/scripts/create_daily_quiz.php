<?php

/* СКРИПТ СОЗДАНИЯ ЕЖЕДНЕВНОГО КВИЗ-А И УДАЛЕНИЯ ЗАПИСЕЙ О КВИЗ-АХ СТАРШЕ 5 ДНЕЙ */

ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include_once "../constants.php";

include_once CLOSE . "db.php";                        //для работы с базой
include_once CLOSE . "users.php";                        //для работы с юзерами
include_once CLOSE . "tasks.php";                        //для работы с задачами

$db = null;

try {
    echo "Запуск скрипта " . date( "Y-m-d H:i:s" ) . "\r\n";

    $db = new db( "balancer" );

    if ($db->connect() !== true) {
        throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
    }

    $date = new DateTime(); // For today/now, don't pass an arg.
    $date->modify("-5 days");
    $dateSql = $date->format("Y-m-d H:i:s");

    // Удаляем записи о донатах старше 120 часов
    $sqlUpdate = "DELETE FROM `game_daily_quiz_donats` WHERE `date_create` < :dateCreate";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [
        "dateCreate" => $dateSql
    ] );

    echo "Query1\r\n";


    // Удаляем записи старше 120 часов
    $sqlUpdate = "DELETE FROM `game_daily_quiz_users`  WHERE `date_create` < :dateCreate";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [
        "dateCreate" => $dateSql
    ] );

    echo "Query2\r\n";

    $tasks = new tasks( "balancer" );

    // генерируем ежедневный квиз
    $result = $tasks->genDailyQuiz( $db, false );

    echo "Queries genDailyQuiz\r\n";

    if ( $result[ "status" ] != "ok" ) {
        throw new Exception( "Ошибка при генерации ежедневного квиз-а: " . $result[ "text" ] );
    }

    echo "Удалили старые записи и создали новый ежедневный квиз " . date( "Y-m-d H:i:s" ) . "\r\n";
}
catch (Exception $err) {
    echo "Error: " . $err->getMessage();
}
finally {
    if ( !is_null($db) ) {
        if ($db != null) try {
            $db->close();
        } catch (Exception $e) {
        }
    }
}

?>