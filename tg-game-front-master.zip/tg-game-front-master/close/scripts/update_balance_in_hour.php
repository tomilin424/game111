<?php

/* СКРИПТ ОБНОВЛЕНИЯ БАЛАНСА ЮЗЕРОВ, КОТОРЫЕ ВЫШЛИ, И УСТАНОВКА ИНДИКАТОРА ТОГО, ЧТО ЮЗЕР ВЫШЕЛ */

ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include_once "../constants.php";

include_once CLOSE . "db.php";                        //для работы с базой
include_once CLOSE . "users.php";                        //для работы с юзерами

$db = null;

try {
    $db = new db( "balancer" );

    if ($db->connect() !== true) {
        throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
    }

    // Запрос установки индикатора неактивности и увеличения баланса с момента последней активности до текущего времени
    // у юзеров Которые имеют этот индикатор И
    // у которых с момента последней активности прошло более или ровно 4 минут`
    $sqlUpdate = "UPDATE `users` 
                    SET `is_active` = 0, `exit_time` = NOW(), 
                        `balance` = `balance` + FLOOR( TIME_TO_SEC(TIMEDIFF( NOW(), `date_last_active` )) / 3600 * `balance_in_hour` ) 
                    WHERE `exit_time` IS NULL AND `is_active` = 1 AND TIME_TO_SEC(TIMEDIFF( NOW(), `date_last_active` )) / 60 >= 4";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );

    // Запрос обновления баланса и времени расчёта пассивного дохода тех юзеров, которые вышли И на баланс добавляется число больше или равно 1 И
    // ( (у которых есть ассистент И прошло больше 3-ёх часов с момента выхода) ИЛИ (прошло меньше или равно 3-ёх часов с момента выхода))
    $sqlUpdate = "UPDATE `users` 
                    SET `add_balance` = `add_balance` + FLOOR( TIME_TO_SEC(TIMEDIFF( NOW(), `balance_in_hour_start_time` )) / 3600 * `balance_in_hour` ), `balance_in_hour_start_time` = NOW() 
                    WHERE `exit_time` IS NOT NULL AND TIME_TO_SEC(TIMEDIFF( NOW(), `balance_in_hour_start_time` )) / 3600 * `balance_in_hour` >= 1 AND 
                          ( (`is_by_assistent` = 1 AND TIME_TO_SEC(TIMEDIFF( NOW(), `exit_time` )) / 3600 > 3 ) OR ( TIME_TO_SEC(TIMEDIFF( NOW(), `exit_time` )) / 3600 <= 3 ) )";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );

    echo "Обновили пассивный баланс " . date( "Y-m-d H:m:s" ) . "\r\n";
}
catch (Exception $err) {
    echo "Error: " . $err->getMessage();
}
finally {
    if ( !is_null($db) ) {
        if ($db != null) try {
            $db->close();
        } catch (Exception $e) {
        }
    }
}

?>