<?php

/* СКРИПТ ОБНОВЛЕНИЯ БАЛАНСА ЮЗЕРОВ, КОТОРЫЕ ВЫШЛИ, И УСТАНОВКА ИНДИКАТОРА ТОГО, ЧТО ЮЗЕР ВЫШЕЛ */

ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(-1);

include_once "../constants.php";

include_once CLOSE . "db.php";                        //для работы с базой
include_once CLOSE . "users.php";                        //для работы с юзерами

$db = null;

try {
    $db = new db( "balancer" );

    if ($db->connect() !== true) {
        throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
    }


    // Перемещаем старые запросы (более или равно 48 часов) в таблицу-отстойник
    $sqlUpdate = "INSERT INTO `game_rockets_orders_old` SELECT * FROM `game_rockets_orders` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 48";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );

    // Удаляем старые запросы (более или равно 48 часов)
    $sqlUpdate = "DELETE FROM `game_rockets_orders` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 48";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );


    // Перемещаем старые запросы (более или равно 48 часов) в таблицу-отстойник
    $sqlUpdate = "INSERT INTO `game_assistents_orders_old` SELECT * FROM `game_assistents_orders` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 48";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );

    // Удаляем старые запросы (более или равно 48 часов)
    $sqlUpdate = "DELETE FROM `game_assistents_orders` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 48";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );


    // Удаляем очеь старые заказы из отстойника - более или равно 120 часов
    $sqlUpdate = "DELETE FROM `game_rockets_orders_old` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 120";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );


    // Удаляем очеь старые заказы из отстойника - более или равно 120 часов
    $sqlUpdate = "DELETE FROM `game_assistents_orders_old` 
                    WHERE TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 3600 >= 120";

    //обновляем
    $db->updatePrepare( $sqlUpdate, [] );

    echo "Переместили старые заказы в отстойник и удалили из отстойника ооочень старые заказы " . date( "Y-m-d H:m:s" ) . "\r\n";
}
catch (Exception $err) {
    echo "Error: " . $err->getMessage();
}
finally {
    if ( !is_null($db) ) {
        if ($db != null) try {
            $db->close();
        } catch (Exception $e) {
        }
    }
}

?>