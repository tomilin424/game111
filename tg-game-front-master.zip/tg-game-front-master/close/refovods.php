<?php

/*
 * создано 26.08.2024 15:07 НСК
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "db.php";                              //для работы с базой
include_once CLOSE . "system.php";                          //для работы с системой
include_once CLOSE . "lang.php";                          //для работы с языком


class refovods
{
    // Авторизация
    public function auth( $user_id = null, $password = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $user_id ) || is_null( $password ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Берём записи
            $sqlSelect = "SELECT `password` 
                            FROM `refovods` 
                            WHERE `user_id` = :user_id";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "user_id" => $user_id
            ]);

            if ( is_null($result) ) {
                throw new Exception("Не найдена информация");
            }

            // Генерируем токен
            $token = hash( "sha256", $password . time() . $user_id );

            // Добавляем токен и обновляем дату входа
            $sqlUpdate = "UPDATE `refovods` SET `token` = :token, `date_enter` = NOW() 
                            WHERE `user_id` = :user_id";

            // обновляем
            $db->selectPrepare( $sqlUpdate, [
                "user_id" => $user_id,
                "token" => $token
            ] );

            //Конфиги системы
            $xmlConf = new xmlConfigs();

            //конфиги системы
            $xmlConf = $xmlConf->getSystemConfigs();

            // Пишем токен в куки
            setcookie( "token", $token, 0, "/", $xmlConf[ "domain" ] );

            return [
                "status" => "ok",
                "dff" => $sqlUpdate,
                "rr" => [
                    "user_id" => $user_id,
                    "token" => $token
                ],
                "data" => $token
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Проверка валидности авторизации
    public function isValidSession ( $token = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Берём записи
            $sqlSelect = "SELECT `id` 
                            FROM `refovods` 
                            WHERE `token` = :token";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "token" => $token
            ]);

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Выход
    public function exit ( $token = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            if ( $this->isValidSession( $token, $db, false )[ "status" ] != "ok" ) {
                throw new Exception( "Access denied" );
            }

            // Удаляем токен
            $sqlUpdate = "UPDATE `refovods` SET `token` = NULL 
                            WHERE `token` = :token";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "token" => $token
            ] );

            //Конфиги системы
            $xmlConf = new xmlConfigs();

            //конфиги системы
            $xmlConf = $xmlConf->getSystemConfigs();

            // Удаляем токен из кук
            setcookie( "token", "", time() - 10, "/", $xmlConf[ "domain" ] );

            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получение ИД юзера по токену
    public function getUserID ( $token = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Берём записи
            $sqlSelect = "SELECT `users_id` 
                            FROM `refovods` 
                            WHERE `token` = :token";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "token" => $token
            ]);

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            return intval( $result[ 0 ][ "users_id" ] );
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Генерация новой ссылки
    public function genLink( $token = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            if ( $this->isValidSession( $token, $db, false )[ "status" ] != "ok" ) {
                throw new Exception( "Access denied" );
            }

            $userID = $this->getUserID( $token, $db, false );

            if ( is_null( $userID ) ) {
                throw new Exception( "Не получен ИД пользователя" );
            }

            // Генерируем ссылку
            $link = substr( hash( "sha256", $token . time() . $userID ) , 0, 20 );

            // Добавляем ссылку
            $sqlUpdate = "INSERT INTO `users_ref_links` (`users_id`, `key`) VALUES (:userID, :key)";

            // обновляем
            $db->selectPrepare($sqlUpdate, [
                "userID" => $userID,
                "key" => $link
            ]);

            // Берём запись
            $data = $this->getLinks( $token, $link, null, $db, false );

            if ( $data[ "status" ] != "ok" ) {
                throw new Exception( "Не получена новая ссылка" );
            }

            $data = $data[ "data" ][ 0 ];

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить данные ссылок
    public function getLinks( $token = null, $key = null, $linkID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            if ( $this->isValidSession( $token, $db, false )[ "status" ] != "ok" ) {
                throw new Exception( "Access denied" );
            }

            $userID = $this->getUserID( $token, $db, false );

            if ( is_null( $userID ) ) {
                throw new Exception( "Не получен ИД пользователя" );
            }

            $sqlSelect = "SELECT `id`, `key`, `is_active`, `stars`, `usdt`, `donats` 
                            FROM `users_ref_links` 
                            WHERE `users_id` = :userID";
            $arr = [
                "userID" => $userID
            ];

            if ( !is_null( $key ) ) {
                $arr[ "key" ] = $key;

                $sqlSelect .= " AND `key` = :key";
            }

            if ( !is_null( $linkID ) ) {
                $arr[ "linkID" ] = $linkID;

                $sqlSelect .= " AND `id` = :linkID";
            }

            $sqlSelect .= " ORDER BY `date_create` DESC";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $arr );

            if ( is_null($result) ) {
                throw new Exception("Не найдена информация");
            }

            $data = [];

            // Перебираем ссылки
            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "key" => strval( $row[ "key" ] ),
                    "isActive" => intval( $row[ "is_active" ] ) == 1,
                    "stars" => floatval( $row[ "stars" ] ),
                    "usdt" => floatval( $row[ "usdt" ] ),
                    "donats" => intval( $row[ "donats" ] ),
                    "referalsCount" => 0,
                    "last24hour" => 0
                ];


                // ищем рефералов по ссылке
                $select = "SELECT COUNT(`id`) AS `count` FROM `referals` WHERE `ref_link_id` = :linkID";

                $res = $db->selectPrepare( $select, [
                    "linkID" => $item[ "id" ]
                ] );

                if ( is_null($res) ) {
                    throw new Exception("Не найдена информация");
                }

                $item[ "referalsCount" ] = intval( $res[ 0 ][ "count" ] );


                // ищем рефералов, которые заходили 24 часа назад
                $select = "SELECT COUNT(`a`.`id`) AS `count` 
                            FROM `users` AS `a` 
                                LEFT JOIN `referals` AS `b` 
                                ON `b`.`referal_user_id` = `a`.`id` AND `b`.`ref_link_id` = :linkID 
                            WHERE ( TIME_TO_SEC(TIMEDIFF( NOW(), `a`.`enter_time` )) / 3600 <= 24 OR 
                                  TIME_TO_SEC(TIMEDIFF( NOW(), `a`.`date_last_active` )) / 3600 <= 24 ) AND `b`.`id` IS NOT NULL";

                $res = $db->selectPrepare( $select, [
                    "linkID" => $item[ "id" ]
                ] );

                if ( is_null($res) || count( $res ) != 1 ) {
                    throw new Exception("Не найдена информация 24");
                }

                $item[ "last24hour" ] = intval( $res[ 0 ][ "count" ] );


                // ищем рефералов, которые донатили хотя бы раз
                $select = "SELECT COUNT(`id`) AS `count` FROM `referals` WHERE `ref_link_id` = :linkID AND `is_pay` = 1";

                $res = $db->selectPrepare( $select, [
                    "linkID" => $item[ "id" ]
                ] );

                if ( is_null($res) ) {
                    throw new Exception("Не найдена информация");
                }

                $item[ "donats" ] = intval( $res[ 0 ][ "count" ] );


                $data[] = $item;
            }


            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Удалить ссылку
    public function removeLink( $token = null, $linkID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $token ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            if ( $this->isValidSession( $token, $db, false )[ "status" ] != "ok" ) {
                throw new Exception( "Access denied" );
            }

            $userID = $this->getUserID( $token, $db, false );

            if ( is_null( $userID ) ) {
                throw new Exception( "Не получен ИД пользователя" );
            }

            $sqlUpdate = "DELETE FROM `users_ref_links` 
                            WHERE `users_id` = :userID AND `id` = :linkID";
            $arr = [
                "userID" => $userID,
                "linkID" => $linkID
            ];

            //удаляем
            $db->updatePrepare( $sqlUpdate, $arr );


            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }
}