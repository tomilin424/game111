<?php
/*
 * создано 06.04.2023 09:45 НСК
 * */

include_once "constants.php";


class xmlConfigs
{
    //путь к файлу конфигураций
    private $xmlPath = null;
    //прочитанный файл
    private $xml = null;
    //текст последней ошибки
    private $lastError = "";

    function __construct( $xmlPath = null ) {
        $this->xmlPath = $xmlPath ?? CONFIGS . "configuration.xml";

        //парсим конфиг файл
        $this->readConfFile();
    }

    //Чтение файла настроек
    public function readConfFile ( ) {
        try {
            if ( $this->xmlPath == null || !file_exists( $this->xmlPath ) ) {
                throw new Exception( "Не задан путь к конфигурационному файлу" );
            }

            $xmlContent = file_get_contents( $this->xmlPath );

            if ( $xmlContent === false ) {
                throw new Exception( "Конфигурационный файл не удалось прочитать" );
            }

            //парсим конфиги
            $this->xml = new SimpleXMLElement( $xmlContent );

            return true;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return false;
        }
    }

    //Получение настроек информации
    public function getInformationConfigs ( ) {
        try {
            //конфиги
            $originalConf = $this->xml->information ?? (object) [];
            //итоговые конфиги
            $conf = $this->toAssocArray( $originalConf );

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //Получение настроек системы
    public function getSystemConfigs ( ) {
        try {
            //конфиги
            $originalConf = $this->xml->system ?? (object) [];
            //итоговые конфиги
            $conf = $this->toAssocArray( $originalConf );

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //Получение настроек для коннекта к базе
    public function getDBConfigs ( $userRole = null ) {
        try {
            if ( $userRole == null ) {
                $userRole = "zeuspay";
            }

            //все обязательные конфиги
            $dbAllConf = $this->xml->dataBase->main;
            //конфиги нужной роли
            $dbRoleConf = $this->xml->dataBase->{ $userRole } ?? (object) [];
            //итоговые конфиги
            $conf = [];

            //перебираем все ключи
            foreach ( get_object_vars( $dbAllConf ) as $key => $value ) {
                if ( $key == "comment" && is_object($value) && get_class($value) == SimpleXMLElement::class ) {
                    continue;
                }

                //пишем ключ со значением
                $conf[ $key ] = $value;
            }

            //перебираем ключи роли
            foreach ( get_object_vars( $dbRoleConf ) as $key => $value ) {
                if ( $key == "comment" && is_object($value) && get_class($value) == SimpleXMLElement::class ) {
                    continue;
                }

                //пишем ключ со значением
                $conf[ $key ] = $value;
            }

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //Получение настроек внешнего API игры
    public function getExtendAPIConfigs ( ) {
        try {
            //конфиги
            $originalConf = $this->xml->extendAPI ?? (object) [];
            //итоговые конфиги
            $conf = [];

            //перебираем все ключи
            foreach ( get_object_vars( $originalConf ) as $key => $value ) {
                if ( $key == "comment" && is_object($value) && get_class($value) == SimpleXMLElement::class ) {
                    continue;
                }

                //пишем ключ со значением
                $conf[ $key ] = $value;
            }

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //Получение настроек ТГ бота
    public function getTGBotConfigs ( ) {
        try {
            //конфиги
            $originalConf = $this->xml->botTG ?? (object) [];
            //итоговые конфиги
            $conf = [];

            //перебираем все ключи
            foreach ( get_object_vars( $originalConf ) as $key => $value ) {
                if ( $key == "comment" && is_object($value) && get_class($value) == SimpleXMLElement::class ) {
                    continue;
                }

                //пишем ключ со значением
                $conf[ $key ] = $value;
            }

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //Перевод элемента в ассоцитаивный массив
    private function toAssocArray ( $elem ) {
        try {
            //итоговые конфиги
            $conf = [];

            //перебираем все ключи
            foreach ( get_object_vars( $elem ) as $key => $value ) {
                if ( $key == "comment" ) {
                    continue;
                }

                //Если не элемент, а объект
                if ( is_object($value) ) {
                    //переводим его в ассоциативный массив
                    $value = $this->toAssocArray( $value );
                }

                //пишем ключ со значением
                $conf[ $key ] = $value;
            }

            return $conf;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return null;
        }
    }

    public function getLastError () {
        return $this->lastError;
    }

}