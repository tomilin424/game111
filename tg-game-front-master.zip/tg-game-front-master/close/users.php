<?php

/*
 * создано 29.04.2024 00:25 НСК
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "db.php";                              //для работы с базой
include_once CLOSE . "system.php";                          //для работы с системой
include_once CLOSE . "lang.php";                          //для работы с языком


class users
{
    private $defaultSettings = [
        "isMuskSound" => 1,
        "isVibration" => 1,
        "isEndFirstInstr" => 1
    ];                                              // дефолтные настройки юзеров

    // Сохранить новые настройки
    public function setNewSettings( $uuid = null, $settings = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $settings ) || is_null( $uuid ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            foreach( $this->defaultSettings as $key => $value ) {
                // Если настройки нет в переданных
                if ( !isset( $settings[ $key ] ) ) {
                    // Записываем её
                    $settings[ $key ] = $value;
                }
            }

            $selectSql = "SELECT * FROM user_settings WHERE users_id = :userID";

            $result = $db->selectPrepare($selectSql, [
                "userID" => $userID
            ]);

            // Меняем настройки пользователя
            if (is_null($result)) {
                $sql = "INSERT INTO `user_settings` (`users_id`, `is_musk_sound`, `is_vibration`, `is_end_first_instruction`) 
                VALUES (:userID, :isMuskSound, :isVibration, :isEndFirstInstr)";
            } else {
                $sql = "UPDATE `user_settings` SET `is_musk_sound` = :isMuskSound, `is_vibration` = :isVibration, `is_end_first_instruction` = :isEndFirstInstr, 
                                `date_change` = NOW() WHERE users_id = :userID";
            }

            //меняем
            $db->updatePrepare( $sql, [
                "userID" => $userID,
                "isMuskSound" => $settings[ "isMuskSound" ],
                "isVibration" => $settings[ "isVibration" ],
                "isEndFirstInstr" => $settings[ "isEndFirstInstr" ]
            ] );

            return [
                "status" => "ok",
                "sql" => $sql,
                "arr" => [
                    "userID" => $userID,
                    "isMuskSound" => $settings[ "isMuskSound" ],
                    "isVibration" => $settings[ "isVibration" ],
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Поменять язык
    public function setLangSetting( $uuid = null, $langID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $langID ) || is_null( $uuid ) ) {
                throw new Exception( "Неверные входные параметры" );
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Меняем язык пользователя
            $sqlUpdate = "UPDATE `users` SET `langs_id` = :langID WHERE `uuid` = :uuid";

            //меняем
            $db->updatePrepare( $sqlUpdate, [
                "langID" => $langID,
                "uuid" => $uuid
            ] );

            $newSettings = $this->getSettings( $uuid, $db, false );

            if ( $newSettings[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка получения новых настроек" );
            }

            $newSettings = $newSettings[ "data" ];

            return [
                "status" => "ok",
                "data" => $newSettings
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить данные настроек
    public function getSettings( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $system = new System();

            $data = [
                "error" => $system->getReports()[ "problem" ],
                "marketing" => $system->getReports()[ "marketing" ]
            ];

            $lang = $this->getLangChar( $uuid );

            if ( is_null( $lang ) ) {
                throw new Exception( "Язык пользователя не получен" );
            }

            $langs = new lang();

            $langsData = $langs->getLangData( -1, null, $db, false );

            if ( $langsData[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось получить языки" );
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            // Берём записи
            $sqlSelect = "SELECT `is_musk_sound`, `is_vibration`, `is_end_first_instruction` 
                            FROM `user_settings` 
                            WHERE `users_id` = :userID";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if ( is_null($result) ) {
                throw new Exception("Не найдена информация");
            }

            // Если настройки заданы
            if ( count( $result ) == 1 ) {
                $data[ "isSoundMusk" ] = intval( $result[ 0 ][ "is_musk_sound" ] ) == 1;
                $data[ "isVibration" ] = intval( $result[ 0 ][ "is_vibration" ] ) == 1;
                $data[ "isEndFirstInstr" ] = intval( $result[ 0 ][ "is_end_first_instruction" ] ) == 1;
            }
            else {
                $data[ "isSoundMusk" ] = $this->defaultSettings[ "isMuskSound" ] == 1;
                $data[ "isVibration" ] = $this->defaultSettings[ "isVibration" ] == 1;
                $data[ "isEndFirstInstr" ] = $this->defaultSettings[ "isEndFirstInstr" ] == 1;
            }

            $data[ "userLangChar" ] = $lang;
            $data[ "langs" ] = $langsData[ "data" ];

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    // Получить элементы покупок ассистентов
    public function getShopAssistentItems( $uuid = null, $itemID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Берём записи
            $sqlSelect = "SELECT `price`, `name`, `id`, `currency`, `description` 
                            FROM `game_shop_assistents` 
                            WHERE `id` " . ( !is_null( $itemID ) ? "= :itemID" : "> :itemID" ) . " 
                            ORDER BY `id` ASC";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "itemID" => !is_null( $itemID ) ? $itemID : 0
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $lang = new lang();

            $char = $this->getLangChar($uuid, $db, false);

            if (is_null($char)) {
                throw new Exception("Язык пользователя не получен");
            }

            $items = [];

            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "price" => explode( ",", $row[ "price" ] ),
                    "currency" => explode( ",", $row[ "currency" ] ),
                    "name" => strval( $lang->getLangText( $char, $row["name"] ) ),
                    "description" => strval( $lang->getLangText( $char, $row["description"] ) )
                ];

                for ( $i = 0; $i <= count( $item[ "price" ] ) - 1; $i++ ) {
                    $item[ "price" ][ $i ] = floatval( $item[ "price" ][ $i ] );
                }

                $items[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $items
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить элементы покупок ракет
    public function getShopRocketItems( $uuid = null, $itemID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Берём записи
            $sqlSelect = "SELECT `price`, `earn`, `id`, `currency` 
                            FROM `game_shop_items` 
                            WHERE `id` " . ( !is_null( $itemID ) ? "= :itemID" : "> :itemID" ) . " 
                            ORDER BY `id` ASC";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "itemID" => !is_null( $itemID ) ? $itemID : 0
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $items = [];

            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "price" => explode( ",", $row[ "price" ] ),
                    "currency" => explode( ",", $row[ "currency" ] ),
                    "earn" => intval( $row[ "earn" ] )
                ];

                for ( $i = 0; $i <= count( $item[ "price" ] ) - 1; $i++ ) {
                    $item[ "price" ][ $i ] = floatval( $item[ "price" ][ $i ] );
                }

                $items[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $items
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Начало покупки (ракет)
    public function byStart( $uuid = null, $itemID = null, $currency = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $itemID ) || is_null( $currency ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Данные товара
            $itemData = $this->getShopRocketItems( $uuid, $itemID, $db, false );

            if ( $itemData[ "status" ] != "ok" ) {
                throw new Exception( "Не получены данные товара" );
            }

            $itemData = $itemData[ "data" ];

            if ( count( $itemData ) != 1 ) {
                throw new Exception( "Error 2" );
            }

            $itemData = $itemData[ 0 ];

            $currencyPay = null;
            $priceIndex = null;

            foreach ( $itemData[ "currency" ] as $index => $currItem ) {
                if ( strtoupper( $currItem ) == strtoupper( $currency ) ) {
                    $currencyPay = strtoupper( $currency );
                    $priceIndex = $index;
                }
            }

            // Если не задана валюта для оплаты
            if ( is_null( $currencyPay ) ) {
                throw new Exception( "Неверная валюта" );
            }

            // Данные заказа для вставки в базу
            $orderData = [
                "itemID" => $itemID,
                "currency" => $currencyPay,
                "sum" => $itemData[ "price" ][ $priceIndex ],
                "userID" => $userID
            ];

            // Добавляем новый заказ
            $sqlUpdate = "INSERT INTO `game_rockets_orders` (`item_id`, `currency`, `sum`, `users_id`) 
                            VALUES (:itemID, :currency, :sum, :userID)";

            //добавляем
            $db->updatePrepare( $sqlUpdate, $orderData );

            //запрос поиска нового заказа
            $sqlSelect = "SELECT `uuid` 
                            FROM `game_rockets_orders` 
                            WHERE `users_id` = :userID AND `item_id` = :itemID AND `is_pay` = 0 AND `sum` = :sum AND `currency` = :currency 
                            ORDER BY `date_create` DESC LIMIT 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $orderData );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация: " . count($result) );
            }

            $newOrderData = [
                "id" => $result[ 0 ][ "uuid" ]
            ];

            $configs = new xmlConfigs();

            $configs = $configs->getTGBotConfigs();

            if ( is_null( $configs ) ) {
                throw new Exception( "Не удалось найти настройки" );
            }

            // Если звёзды
            if ( $currencyPay == "XTR" ) {
                $fields = [
                    "title" => "rockets",
                    "description" => "By " . $itemData[ "earn" ] . " rockets",
                    "payload" => "1|" . $newOrderData[ "id" ],
                    "currency" => $currencyPay,
                    "provider_token" => "",
                    "prices" => json_encode( [
                        [
                            "label" => $itemData[ "earn" ] . " rockets",
                            "amount" => intval( $itemData[ "price" ][ $priceIndex ] )
                        ]
                    ] )
                ];

                $ch = curl_init( "https://api.telegram.org/bot" . $configs[ "tokenGame" ] . "/createInvoiceLink?" . http_build_query($fields) );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HEADER, false);

                $resultCurl = json_decode( curl_exec($ch), true );

                // Если ошибка
                if ( !$resultCurl[ "ok" ] ) {
                    throw new Exception( "Ошибка при оплате: " . $resultCurl[ "description" ] );
                }

                $data = [
                    "payLink" => $resultCurl[ "result" ],
                    "orderData" => $newOrderData
                ];
            }

            // Если TON или USDT
            if ( $currencyPay == "TON" || $currencyPay == "USDT" ) {
                /*$fields = [
                    "currency_type" => "crypto",
                    "asset" => $currencyPay,
                    "amount" => floatval( $itemData[ "price" ][ $priceIndex ] ),
                    "description" => "By " . $itemData[ "earn" ] . " rockets",
                    //"hidden_message" => "Pay success",
                    "paid_btn_name" => "callback",
                    "paid_btn_url" => "https://t.me/" . $configs[ "usernameGame" ] . "?game=" . $configs[ "gameName" ],
                    "payload" => "1|" . $newOrderData[ "id" ],
                    "allow_comments" => false,
                    "allow_anonymous" => true,
                    "expires_in" => 300
                ];

                $ch = curl_init( "https://pay.crypt.bot/api/createInvoice?" . http_build_query($fields) );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Crypto-Pay-API-Token: 254309:AAsPjQogC7vV3XXtgl7YC0XPjQ3v0ML0H5Z"
                ]);

                $resultCurl = json_decode( curl_exec($ch), true );

                //die( print_r($resultCurl, true) );

                // Если ошибка
                if ( $resultCurl[ "ok" ] != 1 ) {
                    throw new Exception( "Ошибка при оплате: " . $resultCurl[ "description" ] );
                }*/

                $wallet = "";
                $price = 0;

                if ( $currencyPay == "TON" ) {
                    $wallet = $configs[ "walletTon" ];
                    $price = floatval( $itemData[ "price" ][ $priceIndex ] ) * 1000000000;
                }

                if ( $currencyPay == "USDT" ) {
                    $wallet = $configs[ "walletUSDT" ];
                    $price = floatval( $itemData[ "price" ][ $priceIndex ] ) * 1000000000;
                }

                $data = [
                    "price" => $price,
                    "wallet" => $wallet,
                    //"payLink" => $resultCurl[ "result" ][ "pay_url" ],
                    "orderData" => $newOrderData
                ];
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Установка хэша заказа (ракет)
    public function setOrderHash( $uuid = null, $orderUUID = null, $hash = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $orderUUID ) || is_null( $hash ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Обновляем заказ
            $sqlUpdate = "UPDATE `game_rockets_orders` 
                            SET `hash` = :hash 
                            WHERE `uuid` = :orderUUID AND `users_id` = :userID AND `is_pay` = 0";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "orderUUID" => $orderUUID,
                "userID" => $userID
            ] );

            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Проверка успешной покупки (ракет)
    public function byCheck( $uuid = null, $orderUUID = null, $hash = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $orderUUID ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Если передан хэш транзакции
            if ( !is_null( $hash ) ) {
                $url = 'https://tonapi.io/v2/blockchain/messages/' . urlencode( $hash ) . '/transaction';

                $ch = curl_init( $url );

                curl_setopt($ch, CURLOPT_POST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HEADER, false);

                $resultCurl = json_decode( curl_exec($ch), true );

                if ( isset( $resultCurl[ "success" ] ) && $resultCurl[ "success" ] === true &&
                isset( $resultCurl[ "in_msg" ][ "decoded_body" ][ "actions" ][ 0 ][ "msg" ][ "message_internal" ][ "body" ][ "value" ][ "value" ] ) ) {
                    // Берём внутреннее сообщение
                    $val = $resultCurl[ "in_msg" ][ "decoded_body" ][ "actions" ][ 0 ][ "msg" ][ "message_internal" ][ "body" ][ "value" ][ "value" ];

                    // hex to string декодируем
                    $val = hex2bin( $val );

                    // удаляем лишние символы вначале
                    $val = substr( $val, 13 );

                    // тип товара
                    $itemType = intval( explode( "|", $val )[ 0 ] );
                    // UUID заказа
                    $orderUUID = strval( explode( "|", $val )[ 1 ] );

                    //Если товар это покупка ракет
                    if ( $itemType == 1 ) {
                        //запрос поиска заказа
                        $sqlSelect = "SELECT `item_id` " .
                                     "FROM `game_rockets_orders` " .
                                     "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                        //ищем в базе
                        $result = $db->selectPrepare( $sqlSelect, [
                            "orderUUID" => $orderUUID
                        ] );

                        if ( !is_null($result) && count( $result ) == 1 ) {
                            $itemID = intval( $result[ 0 ][ "item_id" ] );

                            //Ищем данные купленного товара
                            $sqlSelect = "SELECT `earn` " .
                                         "FROM `game_shop_items` " .
                                         "WHERE `id` = :itemID";

                            //ищем в базе
                            $result = $db->selectPrepare( $sqlSelect, [
                                "itemID" => $itemID
                            ] );

                            if ( !is_null( $result ) && count( $result ) == 1 ) {
                                $addValue = intval( $result[ 0 ][ "earn" ] );

                                // Добавляем ракеты юзеру
                                $sqlUpdate = "UPDATE `users` " .
                                          "SET `balance_rockets` = `balance_rockets` + " . $addValue . " WHERE `id` = :userID";

                                //обновляем в базе
                                $db->updatePrepare( $sqlUpdate, [
                                    "userID" => $userID
                                ] );

                                // Ставим статус оплаты заказа
                                $sqlUpdate = "UPDATE `game_rockets_orders` SET `is_pay` = 1 " .
                                          "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                                //обновляем в базе
                                $db->updatePrepare( $sqlUpdate, [
                                    "orderUUID" => $orderUUID
                                ] );
                            }
                        }
                    }

                    //Если товар это покупка ассистента
                    if ( $itemType == 2 ) {
                        //запрос поиска заказа
                        $sqlSelect = "SELECT `item_id` " .
                            "FROM `game_assistents_orders` " .
                            "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                        //ищем в базе
                        $result = $db->selectPrepare( $sqlSelect, [
                            "orderUUID" => $orderUUID
                        ] );

                        if ( !is_null($result) && count( $result ) == 1 ) {
                            $itemID = intval( $result[ 0 ][ "item_id" ] );

                            //Ищем данные купленного товара
                            $sqlSelect = "SELECT `id` " .
                                "FROM `game_shop_assistents` " .
                                "WHERE `id` = :itemID";

                            //ищем в базе
                            $result = $db->selectPrepare( $sqlSelect, [
                                "itemID" => $itemID
                            ] );

                            if ( !is_null( $result ) && count( $result ) == 1 ) {
                                // Ставим индикатор покупки юзеру
                                $sqlUpdate = "UPDATE `users` " .
                                    "SET `is_by_assistent` = 1 WHERE `id` = :userID";

                                //обновляем в базе
                                $db->updatePrepare( $sqlUpdate, [
                                    "userID" => $userID
                                ] );

                                // Ставим статус оплаты заказа
                                $sqlUpdate = "UPDATE `game_assistents_orders` SET `is_pay` = 1 " .
                                    "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                                //обновляем в базе
                                $db->updatePrepare( $sqlUpdate, [
                                    "orderUUID" => $orderUUID
                                ] );
                            }
                        }
                    }
                }
            }

            //запрос поиска нового заказа
            $sqlSelect = "SELECT COUNT(`id`) AS `count` 
                            FROM `game_rockets_orders` 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "orderUUID" => $orderUUID
            ] );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            // Если заказ оплачен
            if ( intval( $result[ 0 ][ "count" ] ) == 1 ) {
                // ставим статус оповещения на 1
                $sqlUpdate = "UPDATE `game_rockets_orders` SET `is_notif` = 1 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1 AND `is_notif` = 0";

                //обновляем в базе
                $db->updatePrepare( $sqlUpdate, [
                    "orderUUID" => $orderUUID
                ] );
            }

            return [
                "status" => "ok",
                "data" => intval( $result[ 0 ][ "count" ] ) == 1
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Начало покупки (ассистента)
    public function byAssistStart( $uuid = null, $itemID = null, $currency = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $itemID ) || is_null( $currency ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Данные товара
            $itemData = $this->getShopAssistentItems( $uuid, $itemID, $db, false );

            if ( $itemData[ "status" ] != "ok" ) {
                throw new Exception( "Не получены данные товара" );
            }

            $itemData = $itemData[ "data" ];

            if ( count( $itemData ) != 1 ) {
                throw new Exception( "Error 2" );
            }

            $itemData = $itemData[ 0 ];

            $currencyPay = null;
            $priceIndex = null;

            foreach ( $itemData[ "currency" ] as $index => $currItem ) {
                if ( strtoupper( $currItem ) == strtoupper( $currency ) ) {
                    $currencyPay = strtoupper( $currency );
                    $priceIndex = $index;
                }
            }

            // Если не задана валюта для оплаты
            if ( is_null( $currencyPay ) ) {
                throw new Exception( "Неверная валюта" );
            }

            // Данные заказа для вставки в базу
            $orderData = [
                "itemID" => $itemID,
                "currency" => $currencyPay,
                "sum" => intval( $itemData[ "price" ][ $priceIndex ] ),
                "userID" => $userID
            ];

            // Добавляем новый заказ
            $sqlUpdate = "INSERT INTO `game_assistents_orders` (`item_id`, `currency`, `sum`, `users_id`) 
                            VALUES (:itemID, :currency, :sum, :userID)";

            //добавляем
            $db->updatePrepare( $sqlUpdate, $orderData );

            //запрос поиска нового заказа
            $sqlSelect = "SELECT `uuid` 
                            FROM `game_assistents_orders` 
                            WHERE `users_id` = :userID AND `item_id` = :itemID AND `is_pay` = 0 AND `sum` = :sum AND `currency` = :currency 
                            ORDER BY `date_create` DESC LIMIT 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $orderData );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            $newOrderData = [
                "id" => $result[ 0 ][ "uuid" ]
            ];

            $configs = new xmlConfigs();

            $configs = $configs->getTGBotConfigs();

            if ( is_null( $configs ) ) {
                throw new Exception( "Не удалось найти настройки" );
            }

            // Если звёзды
            if ( $currencyPay == "XTR" ) {
                $fields = [
                    "title" => "assistent",
                    "description" => "By assistent",
                    "payload" => "2|" . $newOrderData[ "id" ],
                    "currency" => $currencyPay,
                    "prices" => json_encode( [
                        [
                            "label" => "assistent",
                            "amount" => intval( $itemData[ "price" ][ $priceIndex ] )
                        ]
                    ] )
                ];

                $ch = curl_init( "https://api.telegram.org/bot" . $configs[ "tokenGame" ] . "/createInvoiceLink?" . http_build_query($fields) );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HEADER, false);

                $resultCurl = json_decode( curl_exec($ch), true );

                // Если ошибка
                if ( !$resultCurl[ "ok" ] ) {
                    throw new Exception( "Ошибка при оплате: " . $resultCurl[ "description" ] );
                }

                $data = [
                    "payLink" => $resultCurl[ "result" ],
                    "orderData" => $newOrderData
                ];
            }

            // Если TON или USDT
            if ( $currencyPay == "TON" || $currencyPay == "USDT" ) {
                /*$fields = [
                    "currency_type" => "crypto",
                    "asset" => $currencyPay,
                    "amount" => floatval( $itemData[ "price" ][ $priceIndex ] ),
                    "description" => "By assistent",
                    //"hidden_message" => "Pay success",
                    "paid_btn_name" => "callback",
                    "paid_btn_url" => "https://t.me/" . $configs[ "usernameGame" ] . "?game=" . $configs[ "gameName" ],
                    "payload" => "2|" . $newOrderData[ "id" ],
                    "allow_comments" => false,
                    "allow_anonymous" => true,
                    "expires_in" => 300
                ];

                $ch = curl_init( "https://pay.crypt.bot/api/createInvoice?" . http_build_query($fields) );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    "Crypto-Pay-API-Token: 254309:AAsPjQogC7vV3XXtgl7YC0XPjQ3v0ML0H5Z"
                ]);

                $resultCurl = json_decode( curl_exec($ch), true );

                //die( print_r($resultCurl, true) );

                // Если ошибка
                if ( $resultCurl[ "ok" ] != 1 ) {
                    throw new Exception( "Ошибка при оплате: " . $resultCurl[ "description" ] );
                }*/

                $data = [
                    //"payLink" => $resultCurl[ "result" ][ "pay_url" ],
                    "orderData" => $newOrderData
                ];
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Проверка успешной покупки (ассистента)
    public function byAssistCheck( $uuid = null, $orderUUID = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $orderUUID ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            //запрос поиска нового заказа
            $sqlSelect = "SELECT COUNT(`id`) AS `count` 
                            FROM `game_assistents_orders` 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "orderUUID" => $orderUUID
            ] );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            // Если заказ оплачен
            if ( intval( $result[ 0 ][ "count" ] ) == 1 ) {
                // ставим статус оповещения на 1
                $sqlUpdate = "UPDATE `game_assistents_orders` SET `is_notif` = 1 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1 AND `is_notif` = 0";

                //обновляем в базе
                $db->updatePrepare( $sqlUpdate, [
                    "orderUUID" => $orderUUID
                ] );
            }

            return [
                "status" => "ok",
                "data" => intval( $result[ 0 ][ "count" ] ) == 1
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    //Покупка карточки Space
    public function bySpaceCard($uuid = null, $cardID = null, $lvl = null, $db = null, $isControlConnect = true)
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $cardID ) || is_null( $lvl ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Купленные карточки
            $byCards = $this->getUserSpaceCardsData( $uuid, $db, false );

            if ( $byCards[ "status" ] != "ok" ) {
                throw new Exception( "Не получены купленные карточки" );
            }

            $byCards = $byCards[ "data" ];

            // Текущие данные этой купленной карточки (Если была куплена вообще)
            $currByCardData = null;

            // Перебираем купленные карточки
            foreach ( $byCards as $byCard ) {
                if ( $byCard[ "cardID" ] == $cardID ) {
                    $currByCardData = $byCard;

                    break;
                }
            }

            // Все карточки
            $allCards = $this->getSpaceCardsData( $uuid, false, null, $db, false );

            if ( $allCards[ "status" ] != "ok" ) {
                throw new Exception( "Не получены данные карточек" );
            }

            $allCards = $allCards[ "data" ][ "cards" ];

            //Данные покупаемой карточки
            $newByCardData = null;
            // Раздел покупаемой карточки
            $byCardRazdelID = null;

            // Перебираем все карточки
            foreach ( $allCards as $razdelID => $cardsData ) {
                foreach ( $cardsData as $cardData ) {
                    if ( $cardData[ "id" ] == $cardID ) {
                        $newByCardData = $cardData;
                        $byCardRazdelID = $razdelID;

                        break;
                    }
                }
            }

            if ( is_null( $newByCardData ) ) {
                throw new Exception( "Не получены данные карточки" );
            }

            // Основные данные юзера
            $userData = $this->getMainData( $uuid, $db, false );

            if ( $userData[ "status" ] != "ok" ) {
                throw new Exception( "Не получены основне данные юзера" );
            }

            $userData = $userData[ "data" ];

            // Данные карточки на покупаемом уровне
            $lvlCardData = [
                "price" => $newByCardData[ "data" ][ "prices" ][ $lvl - 1 ],
                "speed" => $newByCardData[ "data" ][ "speeds" ][ $lvl - 1 ],
                "requirements" => isset( $newByCardData[ "data" ][ "requirements" ][ $lvl - 1 ] ) ? $newByCardData[ "data" ][ "requirements" ][ $lvl - 1 ] : null
            ];

            // Если есть уже купленная карточка И покупаемый уровень не больше прошлого на 1
            if ( !is_null($currByCardData) && $currByCardData[ "lvl" ] + 1 != $lvl  ) {
                throw new Exception( "Ошибка уровня" );
            }

            // Если баланс ракет не позволяет купить карточку
            if ( $userData[ "balanceRockets" ] < $lvlCardData[ "price" ] ) {
                throw new Exception( "Ракет мало" );
            }

            // Если есть требования
            if ( !is_null( $lvlCardData[ "requirements" ] ) ) {
                // Если минимум рефералов
                if ( isset( $lvlCardData[ "requirements" ][ "minReferals" ] ) ) {
                    // Количество рефералов
                    $allReferals = $this->getCountReferals( $uuid, $db, false );

                    if ( is_null( $allReferals ) ) {
                        throw new Exception( "Не получено количество рефералов" );
                    }

                    // Если рефералов меньше минимума
                    if ( $allReferals < $lvlCardData[ "requirements" ][ "minReferals" ] ) {
                        throw new Exception( "Мало рефералов" );
                    }
                }

                // Если уровень связанной карточки
                if ( isset( $lvlCardData[ "requirements" ][ "cardLvl" ] ) ) {
                    // Нужный уровень связанной карточки
                    $needLvl = $lvlCardData[ "requirements" ][ "cardLvl" ][ "minLvl" ];
                    // Купленные данные связанной карточки
                    $reqCardData = null;

                    // Перебираем купленные карточки
                    foreach ( $byCards as $byCard ) {
                        if ( $byCard[ "cardID" ] == $lvlCardData[ "requirements" ][ "cardLvl" ][ "cardID" ] ) {
                            $reqCardData = $byCard;

                            break;
                        }
                    }

                    // Если нет купленной связанной карточки ИЛИ купленный уровень не равен нужному
                    if ( is_null( $reqCardData ) || $reqCardData[ "lvl" ] < $needLvl ) {
                        throw new Exception( "Нужно прокачать связанную карточку до " . $needLvl . " лвл-а" );
                    }
                }
            }

            // Если раньше не было купленной карточки
            if ( is_null( $currByCardData ) ) {
                //запрос добавления покупки карточки
                $sqlInsert = "INSERT INTO `game_users_space_cards` (`users_id`, `game_space_cards_id`, `speed`, `lvl`, `sum`) 
                                VALUES (:userID, :cardID, :speed, :lvl, :sum)";

                //добавляем
                $db->updatePrepare( $sqlInsert, [
                    "userID" => $userID,
                    "cardID" => $cardID,
                    "speed" => $lvlCardData[ "speed" ],
                    "lvl" => $lvl,
                    "sum" => $lvlCardData[ "price" ]
                ] );
            }
            else {
                //запрос обновления покупки карточки
                $sqlUpdate = "UPDATE `game_users_space_cards` SET `speed` = :speed, `lvl` = :lvl, `sum` = `sum` + :sum, `date_change` = NOW() 
                                WHERE `users_id` = :userID AND `game_space_cards_id` = :cardID";

                //обновляем
                $db->updatePrepare( $sqlUpdate, [
                    "userID" => $userID,
                    "cardID" => $cardID,
                    "speed" => $lvlCardData[ "speed" ],
                    "lvl" => $lvl,
                    "sum" => $lvlCardData[ "price" ]
                ] );
            }

            // Уменьшаем количество ракет юзера и увеличиваем скорость юзера
            $sqlUpdate = "UPDATE `users` AS `u` SET `balance_rockets` = `balance_rockets` - :price, `speed_start_time` = NOW(), `u`.`speed` = (
                    SELECT SUM(`gusc`.`speed`) FROM `game_users_space_cards` AS `gusc` WHERE `gusc`.`users_id` = `u`.`id`
                ) 
                WHERE `u`.`id` = :userID";

//            $sqlUpdate = "UPDATE `users` SET `speed` = `speed` + :speed, `balance_rockets` = `balance_rockets` - :price, `speed_start_time` = NOW()
//                            WHERE `id` = :userID";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "userID" => $userID,
//                "speed" => $lvlCardData[ "speed" ],
                "price" => $lvlCardData[ "price" ]
            ] );

            // Купленные карточки
            $byCards = $this->getUserSpaceCardsData( $uuid, $db, false );

            if ( $byCards[ "status" ] != "ok" ) {
                throw new Exception( "Не получены купленные карточки" );
            }

            $byCards = $byCards[ "data" ];

            // Текущие данные этой купленной карточки (точно должны быть)
            $currByCardData = null;

            // Перебираем купленные карточки
            foreach ( $byCards as $byCard ) {
                if ( $byCard[ "cardID" ] == $cardID ) {
                    $currByCardData = $byCard;

                    break;
                }
            }

            // Если нет данных купленной карточки
            if ( is_null( $currByCardData ) ) {
                throw new Exception( "Нет данных купленной карточки" );
            }

            $result = $this->moveUserNextLeague( $uuid, $userData[ "userLeague" ][ "leagueID" ], $userData[ "speed" ] + $lvlCardData[ "speed" ], $db, false );

            if ( $result[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось сменить лигу: " . $result[ "text" ] );
            }

            return [
                "status" => "ok",
                "data" => [
                    "byCard" => $currByCardData,
                    "byData" => [
                        "sum" => $lvlCardData[ "price" ]
                    ]
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о купленных Space карточках юзера
    public function getUserSpaceCardsData($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `game_space_cards_id`, `speed`, `lvl`, `sum` 
                            FROM `game_users_space_cards` AS `a` WHERE `users_id` = :userID 
                            ORDER BY `a`.`id` ASC";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [];

            // Перебираем карточки
            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "cardID" => intval( $row["game_space_cards_id"] ),
                    "speed" => intval( $row["speed"] ),
                    "lvl" => intval( $row["lvl"] ),
                    "sum" => intval( $row["sum"] )
                ];
                $data[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о Space карточках
    public function getSpaceCardsData($uuid = null, $withByUserCards = false, $cardID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `name`, `razdel_id`, `type`, `data`, `img` 
                            FROM `game_space_cards` AS `a` WHERE `id` " . ( !is_null( $cardID ) ? "= " . $cardID : "> 0" ) . " 
                            ORDER BY `a`.`razdel_id` ASC";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [] );

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $lang = new lang();

            $char = $this->getLangChar($uuid, $db, false);

            if (is_null($char)) {
                throw new Exception("Язык пользователя не получен");
            }

            $data = [];

            // Перебираем карточки
            foreach ( $result as $row ) {
                $razdelID = strval( $row[ "razdel_id" ] );

                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "type" => intval( $row["type"] ),
                    "img" => strval( $row["img"] ),
                    "data" => json_decode( strval( $row[ "data" ] ), true ),
                    "name" => strval( $lang->getLangText( $char, $row["name"] ) ),
                ];

                // Если раздела нет в данных
                if ( !isset( $data[ $razdelID ] ) ) {
                    $data[ $razdelID ] = [];
                }

                $data[ $razdelID ][] = $item;
            }


            $returnData = [
                "cards" => $data
            ];

            $refCounts = $this->getCountReferals( $uuid, $db, false );

            if ( $refCounts[ "status" ] != "ok" ) {
                throw new Exception( "Не получено количество рефералов" );
            }

            $returnData[ "refCounts" ] = $refCounts[ "data" ];

            // Если нужна информация по купленным карточкам юзера
            if ( $withByUserCards ) {
                $byCards = $this->getUserSpaceCardsData( $uuid, $db, false );

                if ( $byCards[ "status" ] != "ok" ) {
                    throw new Exception( "Не удалось получить информацию о купленных карточках" );
                }

                $byCards = $byCards[ "data" ];

                $returnData[ "byCards" ] = $byCards;
            }

            return [
                "status" => "ok",
                "data" => $returnData
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    //Перевод баланса из На добавление в Реальный
    public function moveBalanceToReal($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос обновления данных у пользователя
            $sqlUpdate = "UPDATE `users` 
                            SET `balance` = `balance` + `add_balance`, `add_balance` = 0 
                            WHERE `uuid` = :uuid";

            //Обновляем данные
            $db->updatePrepare($sqlUpdate, [
                "uuid" => $uuid
            ]);

            $userID = $this->getUserIDByUUID( $uuid, $db, false );

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `balance` FROM `users` WHERE `id` = :userID";

            //Выбираем данные
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            return [
                "status" => "ok",
                "data" => [
                    "balance" => intval( $result[ 0 ][ "balance" ] )
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Покупка лайф карточки
    public function byLifeCard($uuid = null, $cardID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            // Если карточка куплена или ошибка
            if ($this->isByLifeCard($userID, $cardID, $db, false) !== false) {
                throw new Exception("Карточка была куплена");
            }

            // Текущий баланс юзера
            $balance = $this->getUserBalance(null, $userID, $db, false);

            if (is_null($balance)) {
                throw new Exception("Не удалось получить баланс пользователя");
            }

            // Данные карточки
            $cardData = $this->getLifeCard(null, $cardID, $db, false);

            if ($cardData["status"] != "ok") {
                throw new Exception("Не получены данные карточки");
            }

            $cardData = $cardData["data"];

            // Если карточка стоит больше баланса
            if ($cardData["sum"] > $balance) {
                throw new Exception("Не хватает средств");
            }

            //запрос вставки данных
            $sqlSelect = "INSERT INTO `game_users_life_cards` (`users_id`, `game_life_cards_id`, `balance`) 
                            VALUES (:userID, :cardID, :balance)";

            //Добавляем в базу данные
            $db->updatePrepare($sqlSelect, [
                "userID" => $userID,
                "cardID" => $cardID,
                "balance" => $balance
            ]);

            // Данные юзера
            $userData = $this->getMainData($uuid, $db, false);

            if ($userData["status"] != "ok") {
                throw new Exception("Не получены данные пользователя");
            }

            $userData = $userData["data"];

            // Данные почасового обновления данных
            $balanceUpdateHistory = $this->getBalanceInHourHistory($uuid, $db, false);

            if (is_null($balanceUpdateHistory)) {
                throw new Exception("Не удалось получить данные обновления баланса");
            }

            // Если были обновления баланса
            if (count($balanceUpdateHistory) > 0) {
                //запрос добавления в историю заработка монет в час
                $sqlSelect = "INSERT INTO `game_money_in_hour_history` (`users_id`, `money_in_hour`, `date_start`) 
                            VALUES (:userID, :moneyInHour, :dateStart)";

                //Добавляем в базу данные
                $db->updatePrepare($sqlSelect, [
                    "userID" => $userID,
                    "moneyInHour" => $userData["balanceInHour"],
                    "dateStart" => $balanceUpdateHistory[0]["dateCreate"]
                ]);
            }

            //запрос обновления данных у пользователя
            $sqlUpdate = "UPDATE `users` 
                            SET `balance` = `balance` - :sum, `balance_in_hour` = `balance_in_hour` + :balanceInHour, 
                                `balance_rockets` = `balance_rockets` + :rockets 
                            WHERE `id` = :userID";

            //Обновляем данные
            $db->updatePrepare($sqlUpdate, [
                "sum" => $cardData[ "sum" ],
                "userID" => $userID,
                "balanceInHour" => $cardData["moneyInHour"],
                "rockets" => $cardData["rockets"]
            ]);

            // Куплена ли была в итоге карточка
            $isBy = $this->isByLifeCard($userID, $cardID, $db, false);

            // Если не куплена
            if ($isBy !== true) {
                throw new Exception("Ошибка при покупке");
            }

            // Ставим индикатор покупки
            $cardData["isBy"] = $isBy;

            return [
                "status" => "ok",
                "data" => [
                    "rockets" => $cardData["rockets"],
                    "cardData" => $cardData
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных почасового обновления баланса
    public function getBalanceInHourHistory($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `date_create` FROM `game_update_balance_in_hour` WHERE `users_id` = :userID
                            ORDER BY `date_create` DESC";

            //Выбираем данные
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $items = [];

            foreach ($result as $row) {
                $item = [
                    "id" => intval($row["id"]),
                    "dateCreate" => strval($row["date_create"])
                ];

                $items[] = $item;
            }

            return $items;
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных карточки
    public function getLifeCard($uuid = null, $cardID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `rockets`, `money_in_hour`, `sum`, `img`, `type`, `text_key` 
                            FROM `game_life_cards` 
                            WHERE `id` = :cardID";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "cardID" => $cardID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [
                "id" => $cardID,
                "text" => strval($result[0]["text_key"]),
                "rockets" => intval($result[0]["rockets"]),
                "moneyInHour" => intval($result[0]["money_in_hour"]),
                "sum" => intval($result[0]["sum"]),
                "type" => intval($result[0]["type"]),
                "img" => !is_null($result[0]["img"]) ? strval($result[0]["img"]) : null
            ];

            // Если передан uuid юзера
            if (!is_null($uuid)) {
                $lang = new lang();

                $char = $this->getLangChar($uuid);

                if (is_null($char)) {
                    throw new Exception("Язык пользователя не получен");
                }

                // Переводим текст
                $data["text"] = strval($lang->getLangText($char, $data["text"]));
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Проверка куплена карточка или нет
    public function isByLifeCard($userID = null, $cardID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT COUNT(`id`) AS `count` 
                            FROM `game_users_life_cards` 
                            WHERE `users_id` = :userID AND `game_life_cards_id` = :cardID";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID,
                "cardID" => $cardID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $isBy = intval($result[0]["count"]) > 0;

            return $isBy;
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о Лайф карточках
    public function getLifeCardsData($uuid = null, $page = 1, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `text_key`, `rockets`, `money_in_hour`, `sum`, `img`, `type`, 
                            (SELECT COUNT(`id`) AS `count` 
                             FROM `game_users_life_cards` AS `b` 
                             WHERE `a`.`id` = `b`.`game_life_cards_id` AND `b`.`users_id` = :userID) AS `is_by` 
                            FROM `game_life_cards` AS `a` 
                            ORDER BY `a`.`id` ASC LIMIT 20 OFFSET " . (($page - 1) * 20);

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $lang = new lang();

            $char = $this->getLangChar($uuid, $db, false);

            if (is_null($char)) {
                throw new Exception("Язык пользователя не получен");
            }

            $data = [];

            // Перебираем карточки
            foreach ($result as $row) {
                $item = [
                    "id" => intval( $row[ "id" ] ),
                    "text" => strval($lang->getLangText($char, $row["text_key"])),
                    "rockets" => intval($row["rockets"]),
                    "moneyInHour" => intval($row["money_in_hour"]),
                    "sum" => intval($row["sum"]),
                    "type" => intval($row["type"]),
                    "img" => !is_null($row["img"]) ? strval($row["img"]) : null,
                    "isBy" => intval($row["is_by"]) == 1
                ];

                $data[] = $item;
            }

            return [
                "status" => "ok",
                "data" => [
                    "page" => $page,
                    "data" => $data
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о Лайф карточках юзера с последней купленной карточки
    public function getLifeCardsDataFromUserFirstOpen($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска последней купленной карточки
            $sqlSelect = "SELECT `game_life_cards_id` 
                             FROM `game_users_life_cards` AS `b` 
                             WHERE `b`.`users_id` = :userID ORDER BY `game_life_cards_id` DESC";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            // ИД последней купленной карточки
            $lastCardBy = count($result) == 0 ? 0 : intval($result[0]["game_life_cards_id"]);

            // Страница для загрузки
            $page = floor( $lastCardBy / 20 );

            // Если страница от 1-ой и при делении получается больше страницы
            if ( $page >= 1 && $lastCardBy / 20 > $page ) {
                $page++;
            }

            if ( $page <= 0 ) {
                $page = 1;
            }

            $data = $this->getLifeCardsData($uuid, $page, $db, false);

            if ($data["status"] != "ok") {
                throw new Exception("Не получены карточки: " . $data["text"]);
            }

            //запрос поиска максимум карточек и сколько из них куплено
            $sqlSelect = "SELECT (SELECT COUNT(`id`) FROM `game_life_cards`) AS `count_all`, 
                            (SELECT COUNT(`id`) FROM `game_users_life_cards` WHERE `users_id` = :userID) AS `count_by`";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            return [
                "status" => "ok",
                "data" => [
                    "page" => $page,
                    "maxPage" => ceil(intval($result[0]["count_all"]) / 20),
                    "maxCards" => intval($result[0]["count_all"]),
                    "byCards" => intval($result[0]["count_by"]),
                    "data" => $data["data"]
                ]
            ];
        } catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        } finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    // Получить рейтинг лиг пользователей
    public function getRatingLeagues( $uuid = null, $db = null, $isControlConnect = true, $withUsersRating = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска лиг
            $sqlSelect = "SELECT `name`, `id`, `min_speed`, `max_speed` 
                            FROM `leagues` 
                            WHERE `is_active` = 1";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, []);

            $items = [];

            // Запрос поиска юзеров для лиги
            $sqlSelect = "SELECT `username`, `speed` FROM `users` WHERE `leagues_id` = :leagueID ORDER BY `speed` DESC LIMIT 100";

            // Перебираем лиги
            foreach ($result as $row) {
                $leagueData = [
                    "name" => strval($row["name"]),
                    "id" => intval($row["id"]),
                    "minSpeed" => intval($row["min_speed"]),
                    "maxSpeed" => intval($row["max_speed"]),
                    "rating" => []
                ];

                // Если нужны данные рейтингов юзеров
                if ( $withUsersRating ) {
                    //ищем в базе
                    $resultItems = $db->selectPrepare($sqlSelect, [
                        "leagueID" => $leagueData["id"]
                    ]);

                    if (is_null($resultItems)) {
                        throw new Exception("Не удалось получить данные рейтинга лиги");
                    }

                    // Перебираем юзеров рейтинга лиги
                    foreach ($resultItems as $rowItem) {
                        // данные юзера
                        $itemData = [
                            "username" => strval($rowItem["username"]),
                            "speed" => intval($rowItem["speed"])
                        ];

                        // Добавляем данные юзера
                        $leagueData["rating"][] = $itemData;
                    }
                }

                $items[] = $leagueData;
            }

            // Если нужны данные рейтингов юзеров
            if ( $withUsersRating ) {
                $userID = $this->getUserIDByUUID($uuid, $db, false);

                if (is_null($userID)) {
                    throw new Exception("Не удалось получить ID пользователя");
                }

                $userRating = $this->getUserLeague($userID, $db, false);

                if ($userRating["status"] != "ok") {
                    throw new Exception("Ошибка получения данных юзера в лиге");
                }

                // берём данные рейтинга юзера
                $userRating = $userRating["data"];

                if ($userRating["number"] == 0) {
                    $userRating["number"] = 1;
                }
            }
            else {
                $userRating = null;
            }

            return [
                "status" => "ok",
                "data" => [
                    "items" => $items,
                    "userRating" => $userRating
                ]
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить данные текущей лиги пользователя
    public function getUserLeague($userID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска юзера в лиге
            $sqlSelect = "SELECT `leagues_id`, `speed`, `username`,  
                                (SELECT COUNT(`id`) FROM `users` AS `b` WHERE `a`.`speed` <= `b`.`speed` AND `b`.`leagues_id` = `a`.`leagues_id` ORDER BY `speed`) AS `number`,
                                (SELECT `name` FROM `leagues` AS `b` WHERE `b`.`id` = `a`.`leagues_id`) AS `league_name` 
                            FROM `users` AS `a` 
                            WHERE `id` = :userID ORDER BY `speed` DESC";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "userID" => $userID
            ]);

            if (is_null($result)) {
                throw new Exception("Не получены данные места пользователя в рейтинге");
            }

            $userRating = [
                "leagueID" => intval($result[0]["leagues_id"]),
                "speed" => intval($result[0]["speed"]),
                "number" => intval($result[0]["number"]),
                "username" => strval($result[0]["username"]),
                "leagueName" => strval($result[0]["league_name"])
            ];

            if ($userRating["number"] == 0) {
                $userRating["number"] = 1;
            }

            return [
                "status" => "ok",
                "data" => $userRating
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    //Если надо, то перевод юзера в другую лигу
    public function moveUserNextLeague ( $uuid = null, $currentLeagueID = null, $newSpeed = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $uuid ) || is_null( $newSpeed ) || is_null( $currentLeagueID ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Данные лиг
            $leagues = $this->getRatingLeagues( $uuid, $db, false, false );

            if ( $leagues[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка получения данных лиг" );
            }

            $leagues = $leagues[ "data" ][ "items" ];
            // Новый Ид лиги
            $newLeagueID = $currentLeagueID;

            //Перебираем лиги
            foreach ( $leagues as $league ) {
                // Если лига не текущая И скорость укладывается в диапазон
                if ( $league[ "id" ] != $currentLeagueID &&
                    $league[ "minSpeed" ] <= $newSpeed && $league[ "maxSpeed" ] >= $newSpeed ) {
                    $newLeagueID = $league[ "id" ];
                }
            }

            // Если ИД новой лиги меньше прошлой или не даёт разницу в одну лигу
            if ( $newLeagueID - $currentLeagueID != 1 ) {
                return [
                    "status" => "ok"
                ];
            }

            // Вознаграждение реферу за переход юзера в новую лигу
            $refPayData = ( new System() )->getConfigsReferals()[ "refererLeaguePay" ];

            // Если текущей лиги нет в вознаграждениях
            if ( !isset( $refPayData[ strval($currentLeagueID) ] ) ) {
                throw new Exception( "Лиги нет в вознаграждениях" );
            }

            $refPayData = $refPayData[ strval($newLeagueID) ];

            // Меняем текущую лигу юзера
            $sqlUpdate = "UPDATE `users` SET `leagues_id` = :leagueID 
                            WHERE `id` = :userID";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "userID" => $userID,
                "leagueID" => $newLeagueID
            ] );

            $refererID = $this->getRefererID( $userID, $db, false );

            // Если есть реферер
            if ( !is_null( $refererID ) ) {
                $addRefData = [
                    "rockets" => $refPayData[ "rockets" ],
                    "money" => $refPayData[ "currency" ],
                    "userID" => $refererID
                ];

                // Если реферал премиум имеет
                if ( $this->isPremium( $uuid, $db, false ) == true ) {
                    $addRefData = [
                        "rockets" => $refPayData[ "rocketsPremium" ],
                        "money" => $refPayData[ "currencyPremium" ]
                    ];
                }

                // Реферу добавляем монеты и ракеты
                $sqlUpdate = "UPDATE `users` SET `balance` = `balance` + :money, `balance_rockets` = `balance_rockets` + :rockets 
                            WHERE `id` = :userID";

                //обновляем
                $db->updatePrepare( $sqlUpdate, $addRefData );

                $addRefData[ "userID" ] = $userID;

                // У реферала меняем данные о доходности для рефера
                $sqlUpdate = "UPDATE `referals` SET `earn` = `earn` + :money, `rockets` = `rockets` + :rockets 
                            WHERE `referal_user_id` = :userID";

                //обновляем
                $db->updatePrepare( $sqlUpdate, $addRefData );
            }

            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить Обычное вознаграждение
    public function getReferalPays()
    {
        try {
            $system = new System();

            $referalConfigs = $system->getConfigsReferals();

            if (is_null($referalConfigs) || !isset($referalConfigs["refererPay"], $referalConfigs["refererPremiumPay"])) {
                throw new Exception("Не получены конфиги рефералов или нет нужного конфига");
            }

            return [
                "status" => "ok",
                "data" => [
                    "refererPay" => intval($referalConfigs["refererPay"]),
                    "refererPremiumPay" => intval($referalConfigs["refererPremiumPay"]),
                    "refererPayRockets" => intval($referalConfigs["refererPayRockets"]),
                    "refererPremiumPayRockets" => intval($referalConfigs["refererPremiumPayRockets"])
                ]
            ];
        } catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
    }

    // Получить Список вознаграждений за лиги
    public function getLeaguesReferalPays($db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска лиг
            $sqlSelect = "SELECT `name`, `id` FROM `leagues` WHERE `is_active` = 1";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, []);

            $system = new System();

            $referalConfigs = $system->getConfigsReferals();

            if (is_null($referalConfigs) || !isset($referalConfigs["refererLeaguePay"])) {
                throw new Exception("Не получены конфиги рефералов или нет нужного конфига");
            }

            $referalConfigs = $referalConfigs["refererLeaguePay"];

            $items = [];

            foreach ($result as $row) {
                $id = strval($row["id"]);

                // Если ИД лиги нет в настройках
                if (!isset($referalConfigs[$id])) {
                    continue;
                }

                $item = [
                    "id" => intval($row["id"]),
                    "name" => strval($row["name"])
                ];

                // Добавляем данные о вознагаждениях за реферала
                $item = array_merge($item, $referalConfigs[$id]);

                $items[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $items
            ];
        } catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        } finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить UUID юзера по user_id
    public function getUUID($user_id = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `uuid` FROM `users` WHERE `user_id` = :user_id";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "user_id" => $user_id
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return [
                "status" => "ok",
                "data" => strval($result[0]["uuid"])
            ];
        } catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        } finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить баланс юзера
    public function getUserBalance($uuid = null, $userID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `balance` FROM `users` WHERE " . (!is_null($uuid) ? "`uuid` = :id" : "`id` = :id");

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "id" => !is_null($uuid) ? $uuid : $userID
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return intval($result[0]["balance"]);
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить баланс юзера в рокетах
    public function getUserBalanceRockets($uuid = null, $userID = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `balance_rockets` FROM `users` WHERE " . (!is_null($uuid) ? "`uuid` = :id" : "`id` = :id");

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "id" => !is_null($uuid) ? $uuid : $userID
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return intval($result[0]["balance_rockets"]);
        } catch (Exception $err) {
            return null;
        } finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить ID юзера по UUID
    public function getUserIDByUUID($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id` FROM `users` WHERE `uuid` = :uuid";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return strval($result[0]["id"]);
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Юзер премиум или нет
    public function isPremium( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `is_premium` FROM `users` WHERE `uuid` = :uuid";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return intval( $result[0]["is_premium"] ) == 1;
        }
        catch (Exception $err) {
            return false;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получение буквенного обозначения выбранного языка пользователем
    public function getLangChar($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `char` FROM `langs` as `a` WHERE `a`.`id` = (SELECT `langs_id` FROM `users` as `b` WHERE `b`.`uuid` = :uuid)";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result) || count($result) != 1) {
                throw new Exception("Не найдена информация");
            }

            return strval($result[0]["char"]);
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о доступных задачах юзера
    public static function getAvailableTasks($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `type`, `data`, `sum`, `icon` 
                          FROM `tasks` AS `a`
                          WHERE `a`.`id` NOT IN (SELECT `tasks_id` FROM `user_end_tasks` WHERE `user_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid)) AND 
                                (`max_counts` = 0 OR `max_counts` > 0 AND `curr_count` < `max_counts`)
                          ORDER BY `a`.`date_create` ASC;";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [];

            foreach ($result as $row) {
                $item = [
                    "id" => intval($row["id"]),
                    "type" => intval($row["type"]),
                    "sum" => intval($row["sum"]),
                    "data" => json_decode($row["data"], true),
                    "icon" => $row["icon"]
                ];

                $data[] = $item;
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Добавление монет, зарабатываемых за час
    public function addBalanceInHour( $uuid = null, $isAddBalance = false, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $uuid ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Текущие данные юзера
            $userData = $this->getMainData( $uuid, $db, false, true, false );

            if ( $userData[ "status" ] != "ok" ) {
                throw new Exception( "Не получены данные пользователя" );
            }

            $userData = $userData[ "data" ];

            // Время начала расчёта пассивного заработка
            $balanceStartTime = DateTime::createFromFormat( "Y-m-d H:i:s", $userData[ "balanceInHourStartTime" ] );
            // Время входа
            //$enterTime = DateTime::createFromFormat( "Y-m-d H:i:s", $userData[ "enterTime" ] );
            // Время выхода
            $exitTime = !is_null( $userData[ "exitTime" ] ) ? DateTime::createFromFormat( "Y-m-d H:i:s", $userData[ "exitTime" ] ) : null;
            // Текущее время
            $nowTime = new DateTime( "now", new DateTimeZone( 'UTC' ) );

            //$nowTime = $nowTime->add( DateInterval::createFromDateString('2 hours') );

            // Если время выхода не задано
            if ( is_null( $exitTime ) ) {
                // Берём текущее время
                $exitTime = $nowTime;
            }

            // Если с момента выхода до текущего времени прошло больше 3-ёх часов И нет ассистента
            if ( ($nowTime->getTimestamp() - $exitTime->getTimestamp()) / 60 / 60 > 3 && !$userData[ "isByAssistent" ] ) {
                return 0;
            }

            // Разница времени в часах
            $diff =  ( $exitTime->getTimestamp() - $balanceStartTime->getTimestamp() ) / 60 / 60;
            // Заработок монет в час
            $moneyInHour = $userData[ "balanceInHour" ];
            // Текущий заработок
            $addBalance = intval( $diff * $moneyInHour );

            // Если текущий заработок ноль или меньше
            if ( $addBalance <= 0 ) {
                //die ( "balance " . $userData[ "balance" ] . " money in hour " . $userData[ "balanceInHour" ] . " new add " . $addBalance );

                return 0;
            }

            // Добавляем баланс (либо в реальный кошель, либо во временный пока отсутствовал юзер) и меняем время начисления на текущее
            $sqlUpdate = "UPDATE `users` SET `balance_in_hour_start_time` = NOW(), " .
                            ( $isAddBalance ? "`add_balance` = `add_balance` +" : "`balance` = `balance` +" ) . " :addBalance 
                            WHERE `uuid` = :uuid";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "uuid" => $uuid,
                "addBalance" => $addBalance
            ] );

            return $addBalance;
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение заказов, которые не оплачены криптой и не старше 3 минут
    public function getCryptNoPayOrders( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `uuid`, `hash` 
                            FROM `game_rockets_orders` 
                            WHERE `users_id` = :userID AND `is_pay` = 0 AND `is_notif` = 0 AND 
                                  `hash` IS NOT NULL AND TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 60 <= 2";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "userID" => $userID
            ] );

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [
                "rockets" => [],
                "assistents" => []
            ];

            // перебираем заказы
            foreach ( $result as $row ) {
                $item = [
                    "id" => intval( $row[ "uuid" ] ),
                    "hash" => strval( $row[ "hash" ] )
                ];

                $data[ "rockets" ][] = $item;
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `uuid`, `hash` 
                            FROM `game_assistents_orders` 
                            WHERE `users_id` = :userID AND `is_pay` = 0 AND `is_notif` = 0 AND 
                                  `hash` IS NOT NULL AND TIME_TO_SEC(TIMEDIFF( NOW(), `date_create` )) / 60 <= 2";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "userID" => $userID
            ] );

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            // перебираем заказы
            foreach ( $result as $row ) {
                $item = [
                    "id" => strval( $row[ "uuid" ] ),
                    "hash" => strval( $row[ "hash" ] )
                ];

                $data[ "assistents" ][] = $item;
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение оповещений о завершённых заказах, но не оповещённых
    public function getNotNotifOrders( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $userID = $this->getUserIDByUUID($uuid, $db, false);

            if (is_nan($userID)) {
                throw new Exception("ID пользователя не найден");
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, (SELECT `earn` FROM `game_shop_items` AS `b` WHERE `b`.`id` = `item_id`) AS `earn` 
                            FROM `game_rockets_orders` 
                            WHERE `users_id` = :userID AND `is_pay` = 1 AND `is_notif` = 0";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "userID" => $userID
            ] );

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [
                "rockets" => [],
                "assistents" => []
            ];

            $idsRockets = [];
            $idsAssistents = [];

            // перебираем заказы
            foreach ( $result as $row ) {
                $item = [
                    "earn" => intval( $row[ "earn" ] )
                ];

                $data[ "rockets" ][] = $item;

                $idsRockets[] = intval( $row[ "id" ] );
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `uuid` 
                            FROM `game_assistents_orders` 
                            WHERE `users_id` = :userID AND `is_pay` = 1 AND `is_notif` = 0";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "userID" => $userID
            ] );

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            // перебираем заказы
            foreach ( $result as $row ) {
                $item = [
                    "id" => strval( $row[ "uuid" ] )
                ];

                $data[ "assistents" ][] = $item;

                $idsAssistents[] = intval( $row[ "id" ] );
            }


            // запрос изменения статуса оповещения
            $sqlUpdate = "UPDATE `game_rockets_orders` 
                            SET `is_notif` = 1 
                            WHERE `id` IN (" . implode( ",", $idsRockets ) . ")";

            //обновляем в базе
            $db->updatePrepare( $sqlUpdate, [] );

            // запрос изменения статуса оповещения
            $sqlUpdate = "UPDATE `game_assistents_orders` 
                            SET `is_notif` = 1 
                            WHERE `id` IN (" . implode( ",", $idsAssistents ) . ")";

            //обновляем в базе
            $db->updatePrepare( $sqlUpdate, [] );


            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение основных данных юзера
    public function getMainData( $uuid = null, $db = null, $isControlConnect = true, $withEnterExitData = false, $isAddBalance = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Если стоит индикатор необходимости добавления на баланс пассивного дохода
            if ( $isAddBalance ) {
                // Добавляем на баланс деньги из пассивного дохода
                $this->addBalanceInHour( $uuid, false, $db, false );
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `balance`, `intellect`, `money_hours`, `balance_rockets`, `speed`, `balance_in_hour`, `add_balance`, 
                            `speed_start_time`, `is_by_assistent`, `balance_in_hour_start_time`, `user_id`" .
                            ( $withEnterExitData ? ", `enter_time`, `exit_time`" : "" ) . " 
                          FROM `users` AS `a` LEFT JOIN (`game_users_data` AS `b`) ON (`a`.id = `b`.`users_id`) 
                          WHERE `a`.`uuid` = :uuid";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $userID = strval( $result[ 0 ][ "user_id" ] );

            $data = [
                "balanceInHourStartTime" => strval( $result[ 0 ][ "balance_in_hour_start_time" ] ),
                "balanceInHour" => intval($result[0]["balance_in_hour"]),
                "balance" => intval($result[0]["balance"]),
                "intellect" => !is_null($result[0]["intellect"]) ? intval($result[0]["intellect"]) : 0,
                "moneyHours" => !is_null($result[0]["money_hours"]) ? intval($result[0]["money_hours"]) : 0,
                "balanceRockets" => intval($result[0]["balance_rockets"]),
                "speed" => intval($result[0]["speed"]),
                //"km" => intval( $result[ 0 ][ "km" ] ),
                "speedStartTime" => strval( $result[ 0 ][ "speed_start_time" ] ),
                "userLeague" => null,
                "addBalance" => intval( $result[ 0 ][ "add_balance" ] ),
                "isByAssistent" => intval( $result[ 0 ][ "is_by_assistent" ] ) == 1,
                "user_id" => $userID
            ];

            // Если нужна инфа по данным о входе/выходе
            if ( $withEnterExitData ) {
                $data[ "enterTime" ] = strval( $result[ 0 ][ "enter_time" ] );
                $data[ "exitTime" ] = !is_null( $result[ 0 ][ "exit_time" ] ) ? strval( $result[ 0 ][ "exit_time" ] ) : null;
            }

            if (is_null($userID)) {
                throw new Exception("Не удалось получить ID пользователя");
            }

            $userRating = $this->getUserLeague($userID);

            if ($userRating["status"] != "ok") {
                throw new Exception("Ошибка получения данных юзера в лиге");
            }

            // берём данные рейтинга юзера
            $userRating = $userRating["data"];

            $data["userLeague"] = $userRating;

            session_start();

            // Если в сессии нет индикатора того, что игра была запущена
            if ( !isset( $_SESSION[ "isStart" ] ) || !$_SESSION[ "isStart" ] ) {
                // Если успешно поставили индикатор запуска игры
                if ( $this->setStartGame( $uuid, $db, false ) == true ) {
                    // Ставим индикатор запуска игры
                    $_SESSION[ "isStart" ] = true;
                }
            }

            session_write_close();
            session_commit();

            // Отмечаем в базе актинность
            $this->setNotifActive( $uuid, $db, false );

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Установка индикатора запуска игры
    public function setStartGame( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $uuid ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Обновляем данные о запуске игры
            $sqlUpdate = "UPDATE `users` SET `enter_time` = NOW(), `is_active` = 1, `date_last_active` = NOW(), `exit_time` = NULL 
                            WHERE `uuid` = :uuid";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "uuid" => $uuid
            ] );

            return true;
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Оповещение о том, что юзер активен
    public function setNotifActive( $uuid = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null( $uuid ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Обновляем данные о том, что юзер в приложении
            $sqlUpdate = "UPDATE `users` SET `date_last_active` = NOW(), `is_active` = 1, `exit_time` = NULL 
                            WHERE `uuid` = :uuid";

            //обновляем
            $db->updatePrepare( $sqlUpdate, [
                "uuid" => $uuid
            ] );

            return [
                "status" => "ok"
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error"
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить ID рефера, если есть
    public function getRefererID( $referalID = null, $db = null, $isControlConnect = true )
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска
            $sqlSelect = "SELECT `referer_user_id` 
                            FROM `referals` 
                            WHERE `referal_user_id` = :referalID";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "referalID" => $referalID
            ]);

            return is_null( $result ) || count( $result ) != 1 ? null : intval( $result[ 0 ][ "referer_user_id" ] );
        }
        catch (Exception $err) {
            return null;
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    //Получение данных о реферелах
    public static function getReferalsData($uuid = null, $page = 1, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `earn`, `rockets`, `intellect`, `username`, `is_premium`, `c`.`leagues_id`, `l`.`name` AS `league_name`
                        FROM `referals` AS `a` 
                            LEFT JOIN (`game_users_data` AS `b`) ON (`a`.`referal_user_id` = `b`.`users_id`) 
                            LEFT JOIN (`users` AS `c`) ON (`c`.`id` = `a`.`referal_user_id`)  
                            LEFT JOIN (`leagues` AS `l`) ON (`l`.`id` = `c`.`leagues_id`)  
                        WHERE `a`.`referer_user_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid) 
                        ORDER BY `c`.`leagues_id` DESC, `a`.`earn` DESC, `a`.`id` ASC LIMIT 100 
                        OFFSET " . (($page - 1) * 100);

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            $data = [];

            foreach ($result as $row) {
                $item = [
                    "earn" => intval($row["earn"]),
                    "rockets" => intval($row["rockets"]),
                    "intellect" => !is_null($row["intellect"]) ? intval($row["intellect"]) : 0,
                    "username" => $row["username"],
                    "isPremium" => intval( $row[ "is_premium" ] ) == 1,
                    "leaguesId" => intval( $row[ "leagues_id" ] ),
                    "leagueName" => strval($row["league_name"])
                ];

                $data[] = $item;
            }

            //запрос поиска данных
            $sqlSelect = "SELECT COUNT(*) AS `count`
                        FROM `referals` AS `a` 
                        WHERE `a`.`referer_user_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid)";

            //ищем в базе
            $resultCount = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            return [
                "status" => "ok",
                "count" => $resultCount[0]['count'],
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получение данных о общем количестве рефералов
    public function getCountReferals($uuid = null, $db = null, $isControlConnect = true)
    {
        try {
            if (is_null($db) && $isControlConnect) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            //запрос поиска данных
            $sqlSelect = "SELECT COUNT(*) AS `count` 
                            FROM `referals` AS `a`
                            WHERE `a`.`referer_user_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid)";

            //ищем в базе
            $result = $db->selectPrepare($sqlSelect, [
                "uuid" => $uuid
            ]);

            if (is_null($result)) {
                throw new Exception("Не найдена информация");
            }

            return [
                "status" => "ok",
                "data" => intval($result[0]["count"])
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }
}