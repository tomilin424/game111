<?php
/*
 * создано 06.04.2023 09:28 НСК
 * */

if (!defined("ROOT")) define( "ROOT", "/var/www/current/" );  //папка со всеми данными ресурса
if (!defined("WWW")) define( "WWW", ROOT . "" );                 //папка с сайтом
if (!defined("CLOSE")) define( "CLOSE", WWW . "close/" );              //закрытая папка с сайтом
if (!defined("OPEN")) define( "OPEN", WWW . "open/" );              //закрытая папка с сайтом
if (!defined("CONFIGS")) define( "CONFIGS", CLOSE . "configs/" );              //закрытая папка с конфигами
if (!defined("RESOURCES")) define( "RESOURCES", OPEN . "game/resources/" );     //папка с ресурсами сайта
if (!defined("MOBILE_ROOT")) define( "MOBILE_WWW_ROOT", WWW . "open/mobile/" );     //папка с ресурсами сайта

if (!defined("CLOSE_OTHER")) define( "CLOSE_OTHER", ROOT . "close/" );                 //закрытая папка, где данные не для сайта


if (!defined("MODULES")) define( "MODULES", CLOSE . "modules/all/" );                           //папка с общими модулями
if (!defined("MODULES_MODALS")) define( "MODULES_MODALS", MODULES . "modals/" );                //папка с общими модалками
if (!defined("MODULES_GAME")) define( "MODULES_GAME", CLOSE . "modules/game/" );                      //папка с общими модулями ПК версии сайта
if (!defined("MODULES_MOBILE")) define( "MODULES_MOBILE", CLOSE . "modules/mobile/" );          //папка с общими модулями мобильной версии сайта