<?php

/*
 * создано 02.07.2024 09:55 НСК
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы
include_once CLOSE . "db.php";                              //для работы с базой
include_once CLOSE . "lang.php";                            //для работы с языком
include_once CLOSE . "system.php";                          //для работы с системой
include_once CLOSE . "users.php";                           //для работы с пользователями


class tasks
{
    private $role = "";

    public function __construct( $role = "zeuspay" )
    {
        $this->role = $role;
    }

    // Начало покупки (ракет)
    public function dailyQuizByStart( $uuid = null, $quizID = null, $questIndex = null, $currency = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $users = new users();

            $userID = $users->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $quizID ) || is_null( $questIndex ) || is_null( $currency ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            $system = new System();

            $quizConf = $system->getConfigsQuiz();

            $currencyPay = strtoupper( $currency );

            // Данные заказа для вставки в базу
            $orderData = [
                "quizID" => $quizID,
                "userID" => $userID,
                "questNumber" => $questIndex + 1,
                "currency" => $currencyPay,
                "sum" => $quizConf[ "donatChangeSum" ]
            ];

            // Добавляем новый заказ
            $sqlUpdate = "INSERT INTO `game_daily_quiz_donats` (`quiz_id`, `users_id`, `quest_number`, `currency`, `sum`) 
                            VALUES (:quizID, :userID, :questNumber, :currency, :sum)";

            //добавляем
            $db->updatePrepare( $sqlUpdate, $orderData );

            //запрос поиска нового заказа
            $sqlSelect = "SELECT `uuid` 
                            FROM `game_daily_quiz_donats` 
                            WHERE `users_id` = :userID AND `quiz_id` = :quizID AND `is_pay` = 0 AND `sum` = :sum AND `currency` = :currency 
                            AND `quest_number` = :questNumber 
                            ORDER BY `date_create` DESC LIMIT 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $orderData );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация: " . count($result) . $sqlUpdate . " " . print_r( $orderData, true ) );
            }

            $newOrderData = [
                "id" => $result[ 0 ][ "uuid" ]
            ];

            $configs = new xmlConfigs();

            $configs = $configs->getTGBotConfigs();

            if ( is_null( $configs ) ) {
                throw new Exception( "Не удалось найти настройки" );
            }

            // Если звёзды
            if ( $currencyPay == "XTR" ) {
                $fields = [
                    "title" => "change quest",
                    "description" => "By change quest",
                    "payload" => "3|" . $newOrderData[ "id" ],
                    "currency" => $currencyPay,
                    "provider_token" => "",
                    "prices" => json_encode( [
                        [
                            "label" => "Change quest",
                            "amount" => $quizConf[ "donatChangeSum" ]
                        ]
                    ] )
                ];

                $ch = curl_init( "https://api.telegram.org/bot" . $configs[ "tokenGame" ] . "/createInvoiceLink?" . http_build_query($fields) );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HEADER, false);

                $resultCurl = json_decode( curl_exec($ch), true );

                // Если ошибка
                if ( !$resultCurl[ "ok" ] ) {
                    throw new Exception( "Ошибка при оплате: " . $resultCurl[ "description" ] );
                }

                $data = [
                    "payLink" => $resultCurl[ "result" ],
                    "orderData" => $newOrderData
                ];
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Проверка успешной покупки (ракет)
    public function dailyQuizByCheck( $uuid = null, $orderUUID = null, $hash = null, $db = null, $isControlConnect = true )
    {
        try {
            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            $users = new users();

            $userID = $users->getUserIDByUUID($uuid, $db, false);

            if ( is_nan($userID) || is_null( $orderUUID ) ) {
                throw new Exception("Переданы невалидные параметры");
            }

            // Если передан хэш транзакции
            if ( !is_null( $hash ) ) {
                $url = 'https://tonapi.io/v2/blockchain/messages/' . urlencode( $hash ) . '/transaction';

                $ch = curl_init( $url );

                curl_setopt($ch, CURLOPT_POST, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_HEADER, false);

                $resultCurl = json_decode( curl_exec($ch), true );

                if ( isset( $resultCurl[ "success" ] ) && $resultCurl[ "success" ] === true &&
                    isset( $resultCurl[ "in_msg" ][ "decoded_body" ][ "actions" ][ 0 ][ "msg" ][ "message_internal" ][ "body" ][ "value" ][ "value" ] ) ) {
                    // Берём внутреннее сообщение
                    $val = $resultCurl[ "in_msg" ][ "decoded_body" ][ "actions" ][ 0 ][ "msg" ][ "message_internal" ][ "body" ][ "value" ][ "value" ];

                    // hex to string декодируем
                    $val = hex2bin( $val );

                    // удаляем лишние символы вначале
                    $val = substr( $val, 13 );

                    // тип товара
                    $itemType = intval( explode( "|", $val )[ 0 ] );
                    // UUID заказа
                    $orderUUID = strval( explode( "|", $val )[ 1 ] );

                    //Если товар это донат для замены вопроса
                    if ( $itemType == 3 ) {
                        //запрос поиска заказа
                        $sqlSelect = "SELECT `quiz_id` " .
                            "FROM `game_daily_quiz_donats` " .
                            "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                        //ищем в базе
                        $result = $db->selectPrepare( $sqlSelect, [
                            "orderUUID" => $orderUUID
                        ] );

                        if ( !is_null($result) && count( $result ) == 1 ) {
                            $itemID = intval( $result[ 0 ][ "quiz_id" ] );

                            //Ищем данные квиз-а
                            $sqlSelect = "SELECT `id` " .
                                "FROM `game_daily_quiz_users` " .
                                "WHERE `id` = :itemID";

                            //ищем в базе
                            $result = $db->selectPrepare( $sqlSelect, [
                                "itemID" => $itemID
                            ] );

                            if ( !is_null( $result ) && count( $result ) == 1 ) {
                                // Ставим статус оплаты заказа
                                $sqlUpdate = "UPDATE `game_daily_quiz_donats` SET `is_pay` = 1 " .
                                    "WHERE `uuid` = :orderUUID AND `is_pay` = 0";

                                //обновляем в базе
                                $db->updatePrepare( $sqlUpdate, [
                                    "orderUUID" => $orderUUID
                                ] );
                            }
                        }
                    }
                }
            }

            //запрос поиска нового заказа
            $sqlSelect = "SELECT `is_notif`, `quiz_id`, `quest_number` 
                            FROM `game_daily_quiz_donats` 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [
                "orderUUID" => $orderUUID
            ] );

            if ( is_null($result) || count( $result ) != 1 ) {
                throw new Exception("Не найдена информация");
            }

            $data[ "isOk" ] = false;

            // Если заказ оплачен И не было оповещения
            if ( count( $result ) == 1 && intval( $result[ 0 ][ "is_notif" ] ) == 0 ) {
                $quizID = intval( $result[ 0 ][ "quiz_id" ] );
                $questIndex = intval( $result[ 0 ][ "quest_number" ] ) - 1;

                // ставим статус оповещения на 1
                $sqlUpdate = "UPDATE `game_daily_quiz_donats` SET `is_notif` = 1 
                            WHERE `uuid` = :orderUUID AND `is_pay` = 1 AND `is_notif` = 0";

                //обновляем в базе
                $db->updatePrepare( $sqlUpdate, [
                    "orderUUID" => $orderUUID
                ] );

                // результат смены
                $data = $this->changeQuestInDailyQuiz( $quizID, $uuid, $questIndex, false, $db, false );

                if ( $data[ "status" ] != "ok" ) {
                    throw new Exception( "Ошибка смены вопроса" );
                }

                // берём чисто данные
                $data = $data[ "data" ];

                $data[ "isOk" ] = true;
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch (Exception $err) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }


    // Установка завершения квиз-а
    public function endDailyQuiz ( $uuid = null, $quizID = null ) {
        $db = null;

        try {
            if ( is_null( $uuid ) || is_null( $quizID ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            $users = new users();

            $userID = $users->getUserIDByUUID( $uuid );

            if ( is_nan( $userID ) ) {
                throw new Exception( "ID пользователя не найден" );
            }

            // Ставим отметку о завершении выполненния квиз-а
            $sqlUpdate = "UPDATE `game_daily_quiz_users` SET `is_end` = 1 
                                    WHERE `id` = :quizID AND `users_id` = :userID AND `is_start` = 1";

            //обновляем в базе
            $result = $db->updatePrepare( $sqlUpdate, [
                "userID" => $userID,
                "quizID" => $quizID
            ] );

            if ( $result !== true ) {
                throw new Exception( "Не удалось обновить отметку о завершении квиз-а" . $db->getLastError() );
            }

            return [
                "status" => "ok"
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Заменить вопрос в ежедневном квизе
    public function changeQuestInDailyQuiz ( $quizID = null, $uuid = null, $questIndex = null, $isFree = false, $db = null, $isControlConnect = true ) {
        try {
            if ( is_null( $uuid ) || is_null( $questIndex ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $users = new users();
            $system = new System( $this->role );

            // Берём конфиги квиз-а
            $settings = $system->getConfigsQuiz();

            // Проверяем есть ли нужное количество рефералов
            $realReferalsCount = $users->getCountReferals( $uuid );

            if ( $realReferalsCount[ "data" ] < $settings[ "minReferalsCount" ] ) {
                return [
                    "status" => "ok",
                    "data" => [
                        "isBadReferals" => true
                    ]
                ];
            }

            if ( is_null($db) && $isControlConnect ) {
                $db = new db();

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // Берём текущие данные квиз-а
            $quizData = $this->getDailyQuiz( $quizID, $uuid, false, false, true );

            if ( $quizData[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось получить данные квиз-а" );
            }

            $quizData = $quizData[ "data" ];

            // Если в вопросах нет того, который надо заменить
            if ( $questIndex + 1 > count( $quizData[ "questions" ] ) ) {
                throw new Exception( "Номер вопроса неверный" );
            }

            // Если бесплатная замена И количество бесплатных + 1 больше максимума
            if ( $isFree && 1 + $quizData[ "freeChangeNumbers" ] > $quizData[ "maxFreeChangeNumbers" ] ) {
                throw new Exception( "Количество бесплатных замен исчерпано" );
            }

            // ID текущих вопросов
            $currentQuestionsIDs = $quizData[ "questionsIDs" ];

            // Берём новый вопрос, исключая текущий
            $newQuestion = $this->getQuizQuestions( 1, [ $currentQuestionsIDs[ $questIndex ] ] );

            if ( $newQuestion[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось получить новый вопрос" );
            }

            // ID нового вопроса
            $newQuestionID = $newQuestion[ "data" ][ "ids" ][ 0 ];

            // Меняем вопрос на новый
            $currentQuestionsIDs[ $questIndex ] = $newQuestionID;

            // Запрос изменения вопроса в базе
            $sqlUpdate = "UPDATE `game_daily_quiz_users` SET `game_daily_quiz_questions_ids` = :newQuestionIDs, 
                                   `free_change_numbers` = `free_change_numbers` + " . ( $isFree ? "1" : "0" ) . ", 
                                   `answer_number` = LEFT( `answer_number`, char_length(`answer_number`) - 2) 
                               WHERE `id` = :quizID AND `users_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid)";
            $sqlArr = [
                "newQuestionIDs" => implode( ",", $currentQuestionsIDs ),
                "quizID" => $quizID,
                "uuid" => $uuid
            ];

            //обновляем в базе
            $result = $db->updatePrepare( $sqlUpdate, $sqlArr );

            if ( !$result ) {
                throw new Exception( "Не удалось обновить данные квиз-а: " . $db->getLastError() );
            }

            // Ставим время ответа на вопрос
            $result = $this->setStartAnswerTimeDailyQuiz( $uuid, $quizID, $questIndex - 1 < -1 ? -1 : $questIndex - 1, false, true );

            if ( $result[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось задать время начала ответа на вопрос: " . $result[ "text" ] );
            }

            // Берём новые данные квиз-а
            $quizData = $this->getDailyQuiz( $quizID, $uuid, false, false );

            if ( $quizData[ "status" ] != "ok" ) {
                throw new Exception( "Не удалось получить данные квиз-а" );
            }

            return [
                "status" => "ok",
                "data" => $quizData[ "data" ]
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Установка времени начала ответа на вопрос (это на тот случай, что юзер может заменить вопрос) ежедневный квиз
    public function setStartAnswerTimeDailyQuiz ( $uuid, $quizID, $nextQuestIndex, $isAddEmptyAnswer = false, $isChangeQuest = false ) {
        $db = null;

        try {
            if ( is_null( $uuid ) || is_null( $quizID ) || is_null( $nextQuestIndex ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            // берём текущий квиз
            $dailyQuiz = $this->getDailyQuiz( $quizID, $uuid, false, false );

            if ( $dailyQuiz[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка при получении данных ежедневной задачи" );
            }

            $dailyQuiz = $dailyQuiz[ "data" ];

            // Если ИД задач не равны
            if ( $dailyQuiz[ "id" ] != $quizID ) {
                throw new Exception( "Daily quiz changed" );
            }

            // Если новый вопрос больше максимального количества вопросов в квиз-е
            if ( $nextQuestIndex + 1 > count( $dailyQuiz[ "questions" ] ) ) {
                throw new Exception( "Quest number invalid" );
            }

            $users = new users();

            $userID = $users->getUserIDByUUID( $uuid );

            if ( is_nan( $userID ) ) {
                throw new Exception( "ID пользователя не найден" );
            }

            // Ищем запись о прохождении квиз-а пользователем
            $result = $db->selectPrepare( "SELECT `number_last_quest`, `is_end`, `answer_number`  
                                                FROM `game_daily_quiz_users` 
                                                WHERE `users_id` = :userID AND `id` = :quizID", [
                "userID" => $userID,
                "quizID" => $quizID
            ] );

            if ( is_null($result) ) {
                throw new Exception( "Не удалось найти запись о прохождении квиз-а" );
            }

            $dailyQuizResult = [
                "numberLastQuest" => intval($result[0]["number_last_quest"]),                      // номер последнего отвеченного вопроса
                "isEnd" => intval( $result[ 0 ][ "is_end" ] ) == 1,                                // 0 - не завершён квиз, 1 - завершён
                "answerNumber" => explode(",", strval($result[0]["answer_number"]))        // номера выбранных вариантов ответов
            ];

            // Если стоит индикатор необходимости добавить пустой ответ
            if ( $isAddEmptyAnswer ) {
                if ( $dailyQuizResult[ "answerNumber" ][ 0 ] == "" ) {
                    $dailyQuizResult[ "answerNumber" ][ 0 ] = 0;
                }
                else {
                    $dailyQuizResult[ "answerNumber" ][] = 0;
                }
            }

            // Если квиз был уже пройден
            if ( $dailyQuizResult[ "isEnd" ] ) {
                throw new Exception( "Quiz ended" );
            }

            // Если не стоит индикатор замены вопроса И номер сохранённого последнего номера вопроса с номером переданного вопроса не равны И не дают разницу 1
            if ( !$isChangeQuest && $dailyQuizResult[ "numberLastQuest" ] != $nextQuestIndex + 1 &&
                $nextQuestIndex + 1 - $dailyQuizResult[ "numberLastQuest" ] != 1 ) {
                throw new Exception( "Invalid quest number" );
            }

            // обновляем отметку о начале ответа на вопрос
            $sqlInsert = "UPDATE `game_daily_quiz_users` 
                        SET `date_last_answer` = NOW(), `number_last_quest` = :questNumber, `answer_number` = :answerNumber 
                        WHERE `users_id` = :userID AND `id` = :quizID";

            //обновляем в базе
            $result = $db->updatePrepare( $sqlInsert, [
                "userID" => $userID,
                "quizID" => $quizID,
                "questNumber" => $nextQuestIndex + 1,
                "answerNumber" => implode( ",", $dailyQuizResult[ "answerNumber" ] )
            ] );

            if ( $result !== true ) {
                throw new Exception( "Не удалось обновить отметку о начале выполнения квиз-а" );
            }

            return [
                "status" => "ok",
                "oldQusetNumber" => $dailyQuizResult[ "numberLastQuest" ],
                "newQuestNumber" => $nextQuestIndex + 1
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Запуск прохождения квиз-а
    public function startDailyQuiz ( $uuid = null, $quizID = null ) {
        $db = null;

        try {
            if ( is_null( $uuid ) || is_null( $quizID ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            // берём квиз
            $dailyQuiz = $this->getDailyQuiz( $quizID, $uuid, true, false );

            if ( $dailyQuiz[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка при получении данных ежедневного квиз-а" );
            }

            $dailyQuiz = $dailyQuiz[ "data" ];

            // Если ИД квизов не равны
            if ( $dailyQuiz[ "id" ] != $quizID ) {
                throw new Exception( "Daily quiz changed" );
            }

            // Если квиз уже был начат
            if ( $dailyQuiz[ "isStart" ] ) {
                throw new Exception( "Quiz started" );
            }

            $users = new users();

            $userID = $users->getUserIDByUUID( $uuid );

            if ( is_nan( $userID ) ) {
                throw new Exception( "ID пользователя не найден" );
            }

            $balance = $users->getUserBalanceRockets( null, $userID );

            if ( is_nan( $balance ) ) {
                throw new Exception( "Баланс пользователя не найден" );
            }

            // Ставим отметку о начале выполненния квиз-а
            $sqlUpdate = "UPDATE `game_daily_quiz_users` SET `sum` = :sum, `balance` = :balance, `is_start` = 1, `date_start` = NOW(), 
                                   `date_last_answer` = NOW() 
                                    WHERE `id` = :quizID AND `users_id` = :userID AND `is_start` = 0";

            //обновляем в базе
            $result = $db->updatePrepare( $sqlUpdate, [
                "userID" => $userID,
                "quizID" => $quizID,
                "sum" => $dailyQuiz[ "sumEnter" ],
                "balance" => $balance
            ] );

            if ( $result !== true ) {
                throw new Exception( "Не удалось обновить отметку о старте квиз-а" . $db->getLastError() );
            }

            // увеличиваем баланс
            $sqlInsert = "UPDATE `users` SET `balance_rockets` = `balance_rockets` + " . $dailyQuiz[ "sumEnter" ] . " WHERE `id` = :userID";

            //добавляем в базе
            $result = $db->updatePrepare( $sqlInsert, [
                "userID" => $userID
            ] );

            if ( $result !== true ) {
                throw new Exception( "Не удалось увеличить баланс" );
            }

            // берём квиз
            $dailyQuiz = $this->getDailyQuiz( $quizID, $uuid, true, false );

            if ( $dailyQuiz[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка при получении данных ежедневного квиз-а" );
            }

            $dailyQuiz = $dailyQuiz[ "data" ];

            return [
                "status" => "ok",
                "data" => $dailyQuiz
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Проверить ежедневный квиз
    public function checkEndDailyQuiz ( $uuid = null, $quizID = null, $answerIndex = null, $questIndex = null, $isCheckAnswerTime = true ) {
        $db = null;

        try {
            if ( is_null( $uuid ) || is_null( $quizID ) || is_null( $answerIndex ) || is_null( $questIndex ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            // берём текущий квиз
            $dailyQuiz = $this->getDailyQuiz( $quizID, $uuid, true, false, false, true );

            if ( $dailyQuiz[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка при получении данных ежедневной задачи" );
            }

            $dailyQuiz = $dailyQuiz[ "data" ];

            // Если ИД задач не равны
            if ( $dailyQuiz[ "id" ] != $quizID ) {
                throw new Exception( "Daily quiz changed" );
            }

            // Если новый вопрос больше максимального количества вопросов в квиз-е
            if ( $questIndex + 1 > count( $dailyQuiz[ "questions" ] ) ) {
                throw new Exception( "Quest number invalid" );
            }

            $users = new users();

            $userID = $users->getUserIDByUUID( $uuid );

            if ( is_nan( $userID ) ) {
                throw new Exception( "ID пользователя не найден" );
            }

            // Ищем запись о прохождении квиз-а пользователем
            $result = $db->selectPrepare( "SELECT `id`, UNIX_TIMESTAMP( `date_last_answer` ) AS `date_last_answer`, `number_last_quest`, `answer_number`, 
                                                    `is_valid_answer`, `is_end` 
                                                FROM `game_daily_quiz_users` 
                                                WHERE `users_id` = :userID AND `id` = :quizID", [
                "userID" => $userID,
                "quizID" => $quizID
            ] );

            if ( is_null($result) ) {
                throw new Exception( "Не удалось найти запись о прохождении квиз-а" );
            }

            $dailyQuizResult = [
                "dateLastAnswer" => intval( $result[0]["date_last_answer"] ),                       // дата и время последнего ответа
                "numberLastQuest" => intval($result[0]["number_last_quest"]),                       // номер последнего отвеченного вопроса
                "answerNumber" => explode(",", strval($result[0]["answer_number"])),        // номера выбранных вариантов ответов
                "isValidAnswer" => intval( $result[ 0 ][ "is_valid_answer" ] ),                     // 0 - невалидный ответ, 1 - валидный
                "isEnd" => intval( $result[ 0 ][ "is_end" ] ) == 1                                  // 0 - не завершён квиз, 1 - завершён
            ];

            // Если квиз был уже пройден
            if ( $dailyQuizResult[ "isEnd" ] ) {
                throw new Exception( "Quiz ended" );
            }

            // Если номер переданного вопроса с сохранённым последним номером вопроса не дают разницу в 1
            if ( $questIndex + 1 - $dailyQuizResult[ "numberLastQuest" ] != 1 ) {
                throw new Exception( "Invalid quest number" );
            }

            // Если с момента последнего вопроса прошло больше отведённого времени на вопрос И стоит индикатор проверки времени
            if ( time() - $dailyQuizResult[ "dateLastAnswer" ] > $dailyQuiz[ "answerTime" ] && $isCheckAnswerTime ) {
                return [
                    "status" => "ok",
                    "data" => [
                        "isGood" => false,
                        "status" => "answerTimeEnd",
                        "current" => time(),
                        "lastAnswer" => $dailyQuizResult[ "dateLastAnswer" ]
                    ]
                ];
            }

            $data = [
                "isGood" => false,
                "isEnd" => false
            ];

            // Если в правильных ответах есть наш
            if ( in_array( $answerIndex + 1, $dailyQuiz[ "validAnswers" ][ $questIndex ] ) ) {
                $data[ "isGood" ] = true;
            }
            else {
                $data[ "goodAnswers" ] = $dailyQuiz[ "validAnswers" ][ $questIndex ];
            }

            if ( $dailyQuizResult[ "answerNumber" ][ 0 ] == "" ) {
                $dailyQuizResult[ "answerNumber" ][ 0 ] = $answerIndex + 1;
            }
            else {
                $dailyQuizResult[ "answerNumber" ][] = $answerIndex + 1;
            }

            // Если новый вопрос был последним и верным
            if ( $questIndex + 1 >= count( $dailyQuiz[ "questions" ] ) && $data[ "isGood" ] ) {
                // ставим отметку о завершении квиз-а
                $this->endDailyQuiz( $uuid, $quizID );

                $data[ "isEnd" ] = true;
            }

            $balance = $users->getUserBalanceRockets( null, $userID );

            if ( is_nan( $balance ) ) {
                throw new Exception( "Баланс пользователя не найден" );
            }

            // обновляем отметку о выполненном задании
            $sqlInsert = "UPDATE `game_daily_quiz_users` 
                        SET `is_valid_answer` = :isValid, `answer_number` = :answerNumber, `date_last_answer` = NOW(), 
                            `number_last_quest` = :numberLastQuest, `sum` = `sum` + :sum, `balance` = :balance, `is_end` = :isEnd 
                        WHERE `users_id` = :userID AND `id` = :quizID";

            //обновляем в базе
            $result = $db->updatePrepare( $sqlInsert, [
                "userID" => $userID,
                "quizID" => $quizID,
                "sum" => $data[ "isGood" ] ? $dailyQuiz[ "sumGoodAnswer" ]  : 0,
                "balance" => $balance,
                "isValid" => $data[ "isGood" ] ? $dailyQuizResult[ "isValidAnswer" ] : 0,
                "answerNumber" => implode( ",", $dailyQuizResult[ "answerNumber" ] ),
                "numberLastQuest" => $questIndex + 1,
                "isEnd" => $data[ "isEnd" ] ? 1 : 0
            ] );

            if ( $result !== true ) {
                throw new Exception( "Не удалось обновить отметку о выполнении квиз-а" );
            }

            $addBalance = $dailyQuiz[ "sumGoodAnswer" ];

            // Если новый вопрос был последним
            if ( $questIndex + 1 >= count( $dailyQuiz[ "questions" ] ) ) {
                $isAllValid = true;

                // Перебираем все ответы на вопросы
                for ( $i = 0; $i <= count( $dailyQuiz[ "validAnswers" ] ) - 1; $i++ ) {
                    // Если вопрос последний
                    if ( $i == count( $dailyQuiz[ "validAnswers" ] ) - 1 ) {
                        // Если ответ был неверный
                        if ( !$data[ "isGood" ] ) {
                            $isAllValid = false;
                        }

                        continue;
                    }

                    // Если ответ неверный
                    if (  !in_array( $dailyQuiz[ "userAnswers" ][ $i ], $dailyQuiz[ "validAnswers" ][ $i ] ) ) {
                        $isAllValid = false;

                        break;
                    }
                }

                // Если все ответы верные
                if ( $isAllValid ) {
                    $config = new System();

                    $config = $config->getConfigsQuiz();

                    $addBalance += ( $dailyQuiz[ "sumEnter" ] + $dailyQuiz[ "sumGoodAnswer" ] * count( $dailyQuiz[ "validAnswers" ] ) ) * $config[ "multGood" ];
                }
            }

            // Если успешный ответ
            if ( $data[ "isGood" ] ) {
                // увеличиваем баланс
                $sqlInsert = "UPDATE `users` SET `balance_rockets` = `balance_rockets` + " . $addBalance . " WHERE `id` = :userID";

                //добавляем в базе
                $result = $db->updatePrepare( $sqlInsert, [
                    "userID" => $userID
                ] );

                if ( $result !== true ) {
                    throw new Exception( "Не удалось увеличить баланс" );
                }
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Получить ежедневный квиз
    public function getDailyQuiz ( $quizID = null, $uuid = null, $withResult = false, $isCheckStart = true, $withQuestionsIDs = false, $withUserAnswers = false ) {
        $db = null;

        try {
            if ( is_null( $uuid ) ) {
                throw new Exception( "Невалидные параметры" );
            }

            $users = new users();
            $system = new System( $this->role );

            // Берём конфиги квиз-а
            $settings = $system->getConfigsQuiz();

            // Проверяем есть ли нужное количество рефералов
            $realReferalsCount = $users->getCountReferals( $uuid );

            if ( $realReferalsCount[ "data" ] < $settings[ "minReferalsCount" ] ) {
                return [
                    "status" => "ok",
                    "data" => [
                        "isBadReferals" => true
                    ]
                ];
            }

            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            //запрос поиска данных
            $sqlSelect = "SELECT `id`, `game_daily_quiz_questions_ids`, `img`, `sum_good_answer`, `sum_enter`, `answer_number`,  
       `answer_time`, `is_start`, `is_end`, `date_start`, `free_change_numbers`, UNIX_TIMESTAMP( `date_create` ) AS `date_create_seconds`  
FROM `game_daily_quiz_users` 
WHERE " . (is_null($quizID) ? "`date_activate` = DATE( NOW() )" : "`id` = :quizID") . " AND " . ( $isCheckStart ? "`is_start` = 0 AND " : "" ) . "`users_id` = (SELECT `id` FROM `users` WHERE `uuid` = :uuid)";

            $sqlArr = [
                "uuid" => $uuid
            ];

            if ( !is_null($quizID) ) {
                $sqlArr[ "quizID" ] = $quizID;
            }

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, $sqlArr );

            if ( is_null( $result ) ) {
                throw new Exception( "Не найдена информация: " . $db->getLastError() );
            }

            $userID = $users->getUserIDByUUID( $uuid );

            if ( is_nan( $userID ) ) {
                throw new Exception( "ID пользователя не найден" );
            }

            // Если кваз-а нет
            if ( count( $result ) == 0 ) {
                throw new Exception( "Нет квиза" );
                /*// получаем вопросы для квиз-а
                $newQuizQuestions = $this->getQuizQuestions( 5 );

                if ( $newQuizQuestions[ "status" ] != "ok" ) {
                    throw new Exception( "Вопросы для квиз-а не получены" );
                }

                $balance = $users->getUserBalanceRockets( null, $userID );

                if ( is_nan( $balance ) ) {
                    throw new Exception( "Баланс пользователя не найден" );
                }

                // Запрос поиска дневной картинки квиз-а
                $sqlSelectImg = "SELECT `img` FROM `game_daily_quiz_imgs` WHERE `date` = DATE( NOW() )";

                //ищем картинку для квиз-а
                $result = $db->selectPrepare( $sqlSelectImg, [] );

                if ( is_null( $result ) || count( $result ) != 1 ) {
                    throw new Exception( "Картинка не найдена" );
                }

                // картинка для квиз-а
                $quizImg = $result[ 0 ][ "img" ];

                // Запрос добавления квиз-а
                $sqlInsert = "INSERT INTO `game_daily_quiz_users` ( `users_id`, `game_daily_quiz_questions_ids`, `sum`, 
                                     `balance`, `date_activate`, `img`, `sum_good_answer`, `sum_enter`, `answer_time` ) 
                                VALUES (:userID, :questionsID, :sum, :balance, NOW(), :img, :sumGoodAnswer, :sumEnter, :answerTime)";

                // Добавляем квиз
                $db->updatePrepare( $sqlInsert, [
                    "userID" => $userID,
                    "questionsID" => implode( ",", $newQuizQuestions[ "data" ][ "ids" ] ),
                    "sum" => $settings[ "sumGoodAnswer" ],
                    "balance" => $balance,
                    "img" => $quizImg,
                    "sumGoodAnswer" => $settings[ "sumGoodAnswer" ],
                    "sumEnter" => $settings[ "sumEnter" ],
                    "answerTime" => $settings[ "answerTime" ]
                ] );

                //ищем в базе добавленный квиз
                $result = $db->selectPrepare( $sqlSelect, $sqlArr );

                if ( is_null( $result ) || count( $result ) != 1 ) {
                    throw new Exception( "Не найдена информация о квиз-е: " . $db->getLastError() );
                }*/
            }

            $data = [
                "id" => intval( $result[ 0 ][ "id" ] ),
                "questions" => [],
                "answers" => [],
                "img" => !is_null( $result[ 0 ][ "img" ] ) ? strval( $result[ 0 ][ "img" ] ) : null,
                "sumGoodAnswer" => intval( $result[ 0 ][ "sum_good_answer" ] ),
                "sumEnter" => intval( $result[ 0 ][ "sum_enter" ] ),
                "answerTime" => intval( $result[ 0 ][ "answer_time" ] ),
                "isStart" => intval( $result[ 0 ][ "is_start" ] ) == 1,
                "dateStart" => strval( $result[ 0 ][ "date_start" ] ),
                "isBadReferals" => false,
                "freeChangeNumbers" => intval( $result[ 0 ][ "free_change_numbers" ] ),
                "maxFreeChangeNumbers" =>  $settings[ "maxFreeChangeQuestNumbers" ],
                "dateNewQuizSeconds" => 0,                                                                   // Оставшееся время до нового квиз-а
                "donatSum" => $settings[ "donatChangeSum" ],                                                 // Донат для замены вопроса
                "goodMult" => $settings[ "multGood" ]                                                       // Множитель при верном ответе
            ];

            // Если нужны ответы пользователя
            if ( $withUserAnswers ) {
                $data[ "userAnswers" ] = explode( ",", $result[ 0 ][ "answer_number" ] );

                for ( $i = count( $data[ "userAnswers" ] ) - 1; $i >= 0; $i-- ) {
                    $data[ "userAnswers" ][ $i ] = intval( $data[ "userAnswers" ][ $i ] );
                }
            }

            // Текущее время
            $now = new DateTime();

            //$quizCreateTime->setTimestamp( intval( $result[ 0 ][ "date_create_seconds" ] ) );

            // Время до конца дня (до полуночи)
            $midnight = new DateTime( );

            $midnight->setTimestamp( intval( $result[ 0 ][ "date_create_seconds" ] ) );
            $midnight->modify( "+1 day" );
            $midnight->setTime( 0, 1, 0 );          // время Московское

            // Пишем оставшееся время в секундах до смены квиз-а
            $data [ "dateNewQuizSeconds" ] = $midnight->getTimestamp() - $now->getTimestamp();
            $data [ "now" ] = $now;

            // ID вопросов
            $questionsIDs = explode( ",", $result[ 0 ][ "game_daily_quiz_questions_ids" ] );

            // запрос поиска данных о вопросах
            $sqlSelect = "SELECT * FROM `game_daily_quiz_questions` WHERE `id` IN (" . implode( ",", $questionsIDs ) . ")";

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [] );

            if ( is_null( $result ) ) {
                throw new Exception( "Не найдена информация о вопросах: " . $sqlSelect );
            }

            $lang = new lang();

            $char = $users->getLangChar( $uuid );

            if ( is_null($char) ) {
                throw new Exception( "Язык пользователя не получен" );
            }

            // Все верные ответы
            $allValidAnswers = [];

            // Перебираем вопросы
            foreach( $questionsIDs as $questionID ) {
                // ищем вопрос в поисковой выдаче
                $row = $system->getElementByKeyValue( $result, "id", intval( $questionID ) );

                if ( is_null( $row ) ) {
                    throw new Exception( "Не найден вопрос" );
                }

                // Текст вопроса на нужном языке
                $question = $lang->getLangText( $char, $row[ "question" ] );

                // Ответы
                $answers = json_decode( $row[ "answers" ], true );

                // Верные ответы
                $validAnswers = json_decode( $row[ "valid_answers" ], true );

                // перебираем ответы
                for ( $x = count( $answers[ "answers" ] ) - 1; $x >= 0; $x-- ) {
                    // Переписываем на язык пользователя
                    $answers[ "answers" ][ $x ] = $lang->getLangText( $char, $answers[ "answers" ][ $x ]  );
                }

                // Записываем вопрос
                $data[ "questions" ][] = $question;

                // записываем ответы
                $data[ "answers" ][] = $answers;

                // записываем верные ответы
                $allValidAnswers[] = $validAnswers[ "answers" ];
            }

            // Если нужны верные ответы
            if ( $withResult === true ) {
                $data[ "validAnswers" ] = $allValidAnswers;
            }

            // Если нужны ИД вопросов
            if ( $withQuestionsIDs ) {
                $data[ "questionsIDs" ] = $questionsIDs;
            }

            return [
                "status" => "ok",
                "data" => $data
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }

    // Сгенерировать ежедневный квиз для всех юзеров
    public function genDailyQuiz ( $db = null, $isControlConnect = true ) {
        try {
            $users = new users();
            $system = new System( $this->role );

            // Берём конфиги квиз-а
            $settings = $system->getConfigsQuiz();

            if (is_null($db) && $isControlConnect) {
                $db = new db( $this->role );

                if ($db->connect() !== true) {
                    throw new Exception("Не удалось соединиться с базой: " . $db->getLastError());
                }
            }

            // получаем вопросы для квиз-а
            $newQuizQuestions = $this->getQuizQuestions( 5 );

            echo "Queries getQuizQuestions\r\n";

            if ( $newQuizQuestions[ "status" ] != "ok" ) {
                throw new Exception( "Вопросы для квиз-а не получены" );
            }

            // Запрос поиска дневной картинки квиз-а
            $sqlSelectImg = "SELECT `img` FROM `game_daily_quiz_imgs` WHERE `date` = DATE( NOW() )";

            //ищем картинку для квиз-а
            $result = $db->selectPrepare( $sqlSelectImg, [] );

            echo "SELECT `img` FROM `game_daily_quiz_imgs\r\n";

            if ( is_null( $result ) || count( $result ) != 1 ) {
                echo "!!!Не найдена картинка\r\n";
//                throw new Exception( "Картинка не найдена" );
            }

            // картинка для квиз-а
            $quizImg = $result[ 0 ][ "img" ];

//            $db->startTransaction();

            $q = "START TRANSACTION;";
            $db->updatePrepare($q);

            $q = "SET SESSION TRANSACTION LEVEL READ UNCOMMITTED;";
            $db->updatePrepare($q);

            // Запрос добавления квиз-ов
            $sqlInsert = "INSERT INTO `game_daily_quiz_users` ( `users_id`, `game_daily_quiz_questions_ids`, `sum`, 
                                     `balance`, `date_activate`, `img`, `sum_good_answer`, `sum_enter`, `answer_time` ) 
                                SELECT `id`, :questionsID, :sum, `balance`, NOW(), :img, :sumGoodAnswer, :sumEnter, :answerTime FROM `users`";

            // Добавляем квизы
            $db->updatePrepare( $sqlInsert, [
                "questionsID" => implode( ",", $newQuizQuestions[ "data" ][ "ids" ] ),
                "sum" => 0,
                "img" => $quizImg,
                "sumGoodAnswer" => $settings[ "sumGoodAnswer" ],
                "sumEnter" => $settings[ "sumEnter" ],
                "answerTime" => $settings[ "answerTime" ]
            ] );

            $q = "COMMIT;";
            $db->updatePrepare($q);

//            $db->saveTransaction();

            echo "INSERT INTO `game_daily_quiz_users\r\n";

            return [
                "status" => "ok"
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if (!is_null($db) && $isControlConnect) {
                if ($db != null) try {
                    $db->close();
                } catch (Exception $e) {
                }
            }
        }
    }

    // Получить нужное количество вопросов квиз-а
    private function getQuizQuestions ( $needQuestions = 5, $expludeQuestions = [] ) {
        $db = null;

        try {
            $db = new db( $this->role );

            if ( $db->connect() !== true ) {
                throw new Exception( "Не удалось соединиться с базой: " . $db->getLastError() );
            }

            // Выбираем все вопросы, доступные в системе
            $sqlSelect = "SELECT * 
                            FROM game_daily_quiz_questions 
                            WHERE `id` > 0 " . ( count($expludeQuestions) > 0 ? "AND `id` NOT IN (" . implode( ",", $expludeQuestions ) . ")" : "" );

            //ищем в базе
            $result = $db->selectPrepare( $sqlSelect, [] );

            if ( is_null( $result ) ) {
                throw new Exception( "Не найдена информация" );
            }

            // массив вопросов
            $questions = [];
            // ID вопросов
            $ids = [];

            for ( $x = 1; $x <= $needQuestions; $x++ ) {
                $questIndex = random_int( 0, count($result) - 1 );

                $question = [
                    "id" => intval( $result[ $questIndex ][ "id" ] ),
                    "question" => $result[ $questIndex ][ "question" ],
                    "answers" => json_decode( $result[ $questIndex ][ "answers" ], true ),
                    "validAnswers" => json_decode( $result[ $questIndex ][ "valid_answers" ], true )
                ];

                // Добавляем вопрос к другим
                $questions[ ] = $question;

                // Записываем ИД вопросов
                $ids[] = $question[ "id" ];
            }

            return [
                "status" => "ok",
                "data" => [
                    "questions" => $questions,
                    "ids" => $ids
                ]
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage() . " | " . $db->getLastError()
            ];
        }
        finally {
            if ( $db != null ) try {$db->close();} catch (Exception $e) {}
        }
    }
}