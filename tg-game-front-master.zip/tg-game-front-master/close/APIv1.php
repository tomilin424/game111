<?php

include_once "constants.php";

include_once CLOSE . "users.php";                      //для работы с юзерами
include_once CLOSE . "xmlConfigs.php";                 //для работы с XML конфигами системы
include_once CLOSE . "tasks.php";                      //для работы с задачами

include_once CLOSE . "refovods.php";                      //для работы с рефоводами

class Resources {
    private $resourcesPath = RESOURCES;
    private $items = [
        "start" => [],              // картинки при загрузке подгружаемые
        "all" => []                 // все картинки для предзагрузки в фоне
    ];

    // Функция для получения всех ресурсов для предзагрузки
    public function getResources ( $key = "start" ) {
        $this->getItems( $this->resourcesPath );

        return $this->items[ $key ];
    }

    private function getItems ( $dir ) {
        // Перебираем папку
        foreach( scandir( $dir ) as $key => $value ) {
            $path = realpath($dir . DIRECTORY_SEPARATOR . $value );

            if ( !is_dir( $path ) ) {
                // TODO: check or delete comment #11
//                $urlPath = "/resources/" . substr( $path, strlen( $this->resourcesPath ) );
                $urlPath = substr($path, strpos($path, "/resources/"));
                $urlPath = str_replace('/resources/resources/', '/resources/', $urlPath);
                $imgKey = "all";

                // Если картинка
                if ( stripos( $value, ".svg" ) !== false || stripos( $value, ".png" ) !== false ||
                    stripos( $value, ".jpg" ) !== false || stripos( $value, ".gif" ) !== false ) {

                    $tag = '<img src="' . $urlPath . '" />';

                    // Если картинка для старта
                    if ( strpos( $urlPath, "leagues" ) !== false ) {
                        $imgKey = "start";
                    }
                    else {
                        $imgKey = "all";
                    }
                }
                else {
                    continue;
                }

                if ( !is_null( $tag ) ) {
                    $this->items[ $imgKey ][] = $tag;
                }
            }
            else if ( $value != "." && $value != ".." ) {
                $this->getItems( $path );
            }
        }
    }
}

class APIv1
{

    function __construct( ) {
    }

    // Добавление ссылки
    function RefovodsGenLink () {
        try {
            $token = $_COOKIE[ "token" ];

            if ( !isset( $token ) || strlen( $token ) <= 5 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $refovods = new refovods();

            $result = $refovods->genLink( $token );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Удаление ссылки
    function RefovodsRemoveLink () {
        try {
            $token = $_COOKIE[ "token" ];
            $linkID = intval( $_POST[ "id" ] );

            if ( !isset( $token, $linkID ) || strlen( $token ) <= 5 || is_null( $linkID ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $refovods = new refovods();

            $result = $refovods->removeLink( $token, $linkID );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение данных ссылок
    function RefovodsGetLinks () {
        try {
            $token = $_COOKIE[ "token" ];

            if ( !isset( $token ) || strlen( $token ) <= 5 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $refovods = new refovods();

            $result = $refovods->getLinks( $token );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Авторизация рефоводов
    function RefovodsAuth () {
        try {
            $login = $_POST[ "login" ];
            $password = $_POST[ "pass" ];

            if ( !isset( $login, $password ) || strlen( $login ) <= 4 || strlen( $password ) <= 5 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $refovods = new refovods();

            $result = $refovods->auth( $login, $password );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Выход рефоводов
    function RefovodsExit () {
        try {
            $token = $_COOKIE[ "token" ];

            if ( !isset( $token ) || strlen( $token ) <= 5 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $refovods = new refovods();

            $result = $refovods->exit( $token );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }




    // Получение данных предзагрузки
    function PreloadGetBackground () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            //$users = new users();              //элемент для работы с юзерами

            $resItem = new Resources();

            $data = '';

            foreach ( $resItem->getResources( "all" ) as $item ) {
                $data .= $item;
            }

            //возвращаем результат
            echo json_encode( [
                "status" => "ok",
                "data" => $data
            ] );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Установка настроек
    function SettingsSetAll () {
        try {
            $uuid = $_POST[ "id" ];
            $isVibration = intval( $_POST[ "isV" ] );
            $isMuskSound = intval( $_POST[ "isMS" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $isVibration ) || is_null($isMuskSound) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();              //элемент для работы с юзерами

            //результат
            $result = $users->setNewSettings( $uuid, [
                "isMuskSound" => $isMuskSound,
                "isVibration" => $isVibration
            ] );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Установка настроек при первом запуске
    function SettingsSetAllFirst () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();              //элемент для работы с юзерами

            //результат
            $result = $users->setNewSettings( $uuid, [
                "isEndFirstInstr" => 1
            ] );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Загрузка данных настроек
    function SettingsLoadData () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();              //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getSettings( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Установка языка
    function SettingsSetLang () {
        try {
            $uuid = $_POST[ "id" ];
            $id = intval( $_POST[ "lang" ] );

            if ( !isset( $uuid, $id ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $id ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();              //элемент для работы с юзерами

            //результат
            $result = $users->setLangSetting( $uuid, $id );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Покупка карточки space
    function SpaceCardsBy () {
        try {
            $uuid = $_POST[ "id" ];
            $cardID = intval( $_POST[ "cardID" ] );
            $lvl = intval( $_POST[ "lvl" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $cardID ) || is_null( $lvl ) ||
            $cardID <= 0 || $lvl <= 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат покупки
            $result = $users->bySpaceCard( $uuid, $cardID, $lvl );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Загрузка данных о карточках Space с данными купленных карточек юзера
    function SpaceCardsUsersLoad () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getSpaceCardsData( $uuid, true );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Покупка карточки Лайф
    function LifeCardBy () {
        try {
            $uuid = $_POST[ "id" ];
            $cardID = intval( $_POST[ "cardID" ] );

            if ( !isset( $uuid, $cardID ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $cardID ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат
            $result = $users->byLifeCard( $uuid, $cardID );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Загрузка данных о карточках Лайф
    function LifeCardsLoad () {
        try {
            $uuid = $_POST[ "id" ];
            $page = intval( $_POST[ "page" ] );

            if ( !isset( $uuid, $page ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $page ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getLifeCardsData( $uuid, $page );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Загрузка данных о карточках Лайф с последней купленной карточки юзера
    function LifeCardsFromByLoad () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getLifeCardsDataFromUserFirstOpen( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Загрузка данных рейтинга лиг
    function RatingLoadData () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();              //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getRatingLeagues( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Завершение выполнения ежедневного квиз-а
    function QuizEndDaily () {
        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "quizID" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_nan($quizID) || $quizID <= 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат остановки
            $result = $tasks->endDailyQuiz( $uuid, $quizID );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Загрузка данных о ежедневном квиз-е
    function QuizLoadDaily () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат получения данных
            $result = $tasks->getDailyQuiz( null, $uuid, false, false );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Запуск выполнения ежедневного квиз-а
    function QuizStartDaily () {
        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "quizID" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_nan($quizID) || $quizID <= 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат проверки данных
            $result = $tasks->startDailyQuiz( $uuid, $quizID );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Проверка выполнения ежедневного квиз-а
    function QuizCheckDaily () {
        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "quizID" ] );
            $questIndex = intval( $_POST[ "quest" ] );
            $answerIndex = intval( $_POST[ "answer" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ||
                is_nan($quizID) || is_nan( $answerIndex ) || is_nan( $questIndex ) ||
                $quizID <= 0 || $answerIndex < 0 || $questIndex < 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат проверки данных
            $result = $tasks->checkEndDailyQuiz( $uuid, $quizID, $answerIndex, $questIndex );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Замена вопроса в ежедневном квиз-е
    function QuizChangeQuestDaily () {
        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "quizID" ] );
            $questIndex = intval( $_POST[ "quest" ] );
            $isFree = isset( $_POST[ "isFree" ] ) && intval( $_POST[ "isFree" ] ) == 1;
            $hash = isset( $_POST[ "str" ] ) ? $_POST[ "str" ] : null;

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ||
                is_nan($quizID) || is_nan( $questIndex ) ||
                $quizID <= 0 || $questIndex < 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            // Если есть хэш И он не совпадает
            if ( !is_null( $hash ) && $hash != hash( "sha256", $quizID . $uuid . $questIndex ) ) {
                throw new Exception( "Неверный запрос " . hash( "sha256", $quizID . $uuid . $questIndex ) );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат смены
            $result = $tasks->changeQuestInDailyQuiz( $quizID, $uuid, $questIndex, $isFree );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Установка времени начала ответа на вопрос (это на тот случай, что юзер может заменить вопрос) ежедневного квиз-а
    function QuizSetStartAnswerDaily () {
        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "quizID" ] );
            $nextQuestIndex = intval( $_POST[ "quest" ] );
            $isAddEmptyAnswer = isset( $_POST[ "isEmpty" ] ) && intval( $_POST[ "isEmpty" ] ) == 1;

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ||
                is_nan($quizID) || is_nan( $nextQuestIndex ) || is_nan( $nextQuestIndex ) ||
                $quizID <= 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат
            $result = $tasks->setStartAnswerTimeDailyQuiz( $uuid, $quizID, $nextQuestIndex, $isAddEmptyAnswer );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Донат (ракет)
    function QuizByStart () {
        try {
            $uuid = $_POST[ "id" ];
            $step = intval( $_POST[ "s" ] );

            if ( !isset( $uuid, $step ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $step ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами
            $result = [
                "status" => "error",
                "text" => "Bad request"
            ];

            // Если этап 1 - Начало покупки
            if ( $step == 1 ) {
                // ID квиз-а
                $quizID = intval( $_POST[ "quizID" ] );
                // индекс вопроса
                $questIndex = intval( $_POST[ "quest" ] );
                // Валюта
                $currency = strval( $_POST[ "curr" ] );

                //результат
                $result = $tasks->dailyQuizByStart( $uuid, $quizID, $questIndex, $currency );
            }

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Проверка доната (ракет)
    function QuizByCheck () {
        try {
            $uuid = $_POST[ "id" ];
            $orderUUID = $_POST[ "orderID" ];
            $hash = isset( $_POST[ "hash" ] ) ? $_POST[ "hash" ] : null;

            if ( !isset( $uuid, $orderUUID ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $orderUUID ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $tasks = new tasks();               //элемент для работы с задачами

            //результат
            $result = $tasks->dailyQuizByCheck( $uuid, $orderUUID, $hash );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Получение данных о вознаграждениях
    function FriendsLoadReferalsPayData () {
        try {
            $users = new users();               //элемент для работы с юзерами

            //результат получения данных выплаты по лигам
            $resultLegaue = $users->getLeaguesReferalPays( );

            if ( $resultLegaue[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка получения данных о выплате по лигам" );
            }

            //результат получения данных обычных выплат
            $resultNormal = $users->getReferalPays();

            if ( $resultNormal[ "status" ] != "ok" ) {
                throw new Exception( "Ошибка получения данных о обычных выплатах" );
            }

            $result = [
                "status" => "ok",
                "data" => [
                    "normal" => $resultNormal[ "data" ],
                    "leagues" => $resultLegaue[ "data" ]
                ]
            ];

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Перевод баланса из добавленного в текущий
    function UserMoveBalanceToReal () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат
            $result = $users->moveBalanceToReal( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение UUID юзера
    function UserGetUUID () {
        try {
            $user_id = $_POST[ "user_id" ];

            if ( !isset( $user_id ) || strlen( $user_id ) <= 5 || is_null( $user_id ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getUUID( $user_id );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение основных данных юзера
    function UserLoadMainData () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getMainData( $uuid, null, true, true );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение данных о реферелах
    function UserLoadReferalsData () {
        try {
            $uuid = $_POST[ "id" ];
            $page = intval( $_POST[ "page" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_nan( $page ) || is_null( $page ) || $page < 1 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getReferalsData( $uuid, $page );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Отметка о том, что юзер активен
    function UserNotifActive () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат
            $result = $users->setNotifActive( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }


    // Получение данных о доступных задачах юзера
    function UserGetAvailableTasks () {
        try {
            $uuid = $_POST[ "id" ];
            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getAvailableTasks( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Отметка о выполнении задания
    function UserSetEndTask () {
        $ch = null;

        try {
            $uuid = $_POST[ "id" ];
            $quizID = intval( $_POST[ "taskID" ] );

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $quizID ) || $quizID <= 0 ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            $configs = new xmlConfigs();

            $configs = $configs->getExtendAPIConfigs();

            if ( is_null( $configs ) ) {
                throw new Exception( "Не удалось найти настройки" );
            }

            $fields = [
                "id" => $uuid,
                "taskID" => $quizID
            ];

            $ch = curl_init( $configs[ "host" ] . ":" . $configs[ "port" ] . $configs[ "setEndTask" ] );

            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields, '', '&'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);

            $result = curl_exec($ch);

            //возвращаем результат
            echo $result;
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
        finally {
            if ( !is_null( $ch ) ) {
                curl_close( $ch );
            }
        }
    }


    // Покупка юзером (ракет)
    function UserBy () {
        try {
            $uuid = $_POST[ "id" ];
            $step = intval( $_POST[ "s" ] );

            if ( !isset( $uuid, $step ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $step ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами
            $result = [
                "status" => "error",
                "text" => "Bad request"
            ];

            // Если этап 1 - Начало покупки
            if ( $step == 1 ) {
                // ID товара
                $itemID = intval( $_POST[ "itemID" ] );
                // Валюта
                $currency = strval( $_POST[ "curr" ] );

                //результат получения данных
                $result = $users->byStart( $uuid, $itemID, $currency );
            }

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Установка хэш-а заказа (ракет)
    function UserByOrderHash () {
        try {
            $uuid = $_POST[ "id" ];
            $orderUUID = $_POST[ "orderID" ];
            $hash = $_POST[ "hash" ];

            if ( !isset( $uuid, $orderUUID, $hash ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ||
                strlen( $orderUUID ) <= 20 || is_null( $orderUUID ) || strlen( $hash ) <= 20 || is_null( $hash ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат
            $result = $users->setOrderHash( $uuid, $orderUUID, $hash );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Проверка покупки (ракет)
    function UserByCheck () {
        try {
            $uuid = $_POST[ "id" ];
            $orderUUID = $_POST[ "orderID" ];
            $hash = isset( $_POST[ "hash" ] ) ? $_POST[ "hash" ] : null;

            if ( !isset( $uuid, $orderUUID ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $orderUUID ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->byCheck( $uuid, $orderUUID, $hash );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Покупка юзером (ассистента)
    function UserByAssist () {
        try {
            $uuid = $_POST[ "id" ];
            $step = intval( $_POST[ "s" ] );

            if ( !isset( $uuid, $step ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $step ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами
            $result = [
                "status" => "error",
                "text" => "Bad request"
            ];

            // Если этап 1 - Начало покупки
            if ( $step == 1 ) {
                // ID товара
                $itemID = intval( $_POST[ "itemID" ] );
                // Валюта
                $currency = strval( $_POST[ "curr" ] );

                //результат получения данных
                $result = $users->byAssistStart( $uuid, $itemID, $currency );
            }

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Проерка покупки (ассистента)
    function UserByCheckAssist () {
        try {
            $uuid = $_POST[ "id" ];
            $orderUUID = $_POST[ "orderID" ];

            if ( !isset( $uuid, $orderUUID ) || strlen( $uuid ) <= 20 || is_null( $uuid ) || is_null( $orderUUID ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->byAssistCheck( $uuid, $orderUUID );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Подгрузка данных о товарах магазина (ракеты)
    function UserByLoadItems () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getShopRocketItems( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Подгрузка данных о товарах магазина (ассистенты)
    function UserByLoadAssistents () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getShopAssistentItems( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение данных о заказах, который оплачены, но по которым не было оповещений
    function UserLoadNotifOrders () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getNotNotifOrders( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }

    // Получение данных о заказах, которые не оплачены криптой и по которым не прошло 2 минуты
    function UserLoadNoPayCryptOrders () {
        try {
            $uuid = $_POST[ "id" ];

            if ( !isset( $uuid ) || strlen( $uuid ) <= 20 || is_null( $uuid ) ) {
                throw new Exception( "Переданы невалидные параметры" );
            }

            $users = new users();               //элемент для работы с юзерами

            //результат получения данных
            $result = $users->getCryptNoPayOrders( $uuid );

            //возвращаем результат
            echo json_encode( $result );
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }



    //Запросы модалок
    function GetModal () {
        try {
            //массив имеющихся модалок
            $availableModals = $GLOBALS[ "modals" ];

            //Если нет запроса или модалки
            if ( !isset($_GET["ajax"], $_GET["request"]) || !in_array($_GET["ajax"], array_keys($availableModals)) ) {
                throw new Exception( "Bad request" );
            }

            //данные запрошенной модалки
            $modalData = searchModal( $availableModals, $_GET["ajax"], $_GET["request"] );

            //Если не получены данные модалки
            if ( $modalData == null ) {
                 throw new Exception( "No exist modal" );
            }

            $workData = [
                "twig" => $GLOBALS[ "twig" ]
            ];
            $defaultTwigConfigs = [
                "auto_reload" => true
            ];          //взято из URLListeners

            $loader = new \Twig\Loader\FilesystemLoader( );

            //перебираем переменные окружения
            foreach ( $workData[ "twig" ][ "environments" ] as $envData ) {
                //Если задано пространство имён
                if ( count($envData) == 2 ) {
                    $loader->addPath( $envData[0], $envData[1] );
                }
                else {
                    $loader->addPath( $envData[0] );
                }
            }

            //конфиги шаблонизатора
            $configs = $defaultTwigConfigs;

            //Если заданы конфиги в обработчике
            if ( isset($workData[ "twig" ][ "configs" ]) ) {
                //перебираем конфиги
                foreach ( $workData[ "twig" ][ "configs" ] as $key => $value ) {
                    //записываем конфиг
                    $configs[ $key ] = $value;
                }
            }

            //переменные контекста
            $context = [];

            //Если заданы переменные контекста
            if ( isset($workData[ "twig" ][ "context" ]) ) {
                //перебираем переменные
                foreach ( $workData[ "twig" ][ "context" ] as $key => $value ) {
                    //записываем переменную
                    $context[ $key ] = $value;
                }
            }

            //создаём твиг
            $twig = new \Twig\Environment( $loader, $configs );
            //загружаем нужную модалку
            $template = $twig->load( $modalData[ "path" ] );

            //рендерим шаблон в заданном контексте
            $return = $template->render( $context );

            echo json_encode([
                "status" => "ok",
                "data" => $return
            ]);
        }
        catch ( Exception $err ) {
            echo json_encode([
                "status" => "error",
                "text" => $err->getMessage()
            ]);
        }
    }
}