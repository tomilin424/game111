<?php
/*
 * создано 06.04.2023 09:30 НСК
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы


class db
{
    private $settings = []; //настройки
    private $connect = null; //коннект с бд
    //текст последней ошибки
    private $lastError = "";

    function __construct( $userRole = "zeuspay" ) {
        $xmlConf = new xmlConfigs();
        $settings = $xmlConf->getDBConfigs( $userRole );

        if ( $settings != null ) {
            $this->settings = $settings;
        }
    }

    //выполнение обычного select запроса
    public function select ( $query ) {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            $result = $this->connect->query( $query );

            $array = $result->fetchAll();

            return $array;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getMessage() . "_" . $err->getTraceAsString() . "\n";

            return null;
        }
    }

    //выполнение подготовленного select запроса
    public function selectPrepare ( $query, $array ) {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            //подготавливаем запрос
            $stmt = $this->connect->prepare( $query );

            $result = $stmt->execute( $array );

            if ( $result === false ) {
                throw new Exception( "Не удалось выполнить запрос" );
            }

            $rows = $stmt->fetchAll();

            return $rows;
        }
        catch ( Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n::" . $err->getMessage() . "\n";

            return null;
        }
    }

    //выполнение обычного update запроса
    public function update ( $query ) {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            $result = mysqli_query( $this->connect, $query );

            if ( $result === false ) {
                throw new Exception("Не удалось выполнить запрос");
            }

            return true;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n";

            return false;
        }
    }

    //выполнение подготовленного update запроса
    public function updatePrepare ( $query, $array = [] ) {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            //подготавливаем запрос
            $stmt = $this->connect->prepare( $query );

            $result = $stmt->execute( $array );

            if ( $result === false ) {
                throw new Exception( "Не удалось выполнить запрос" );
            }

            return true;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . "\n::" . $err->getMessage() . "\n";

            return false;
        }
    }

    //установка коннекта
    public function setConnect ( $newConnect = null ) {
        try {
            //Если не передан коннект
            if ( $newConnect == null ) {
                throw new \Exception( "не передан коннект" );
            }

            $this->connect = $newConnect; //записываем коннект

            return true;
        }
        catch ( \Exception $err ) {
            return $err;
        }
    }

    //получение коннекта
    public function getConnect () {
        if ( $this->connect == null ) {
            return false;
        }

        return $this->connect;
    }

    //коннект к бд
    public function connect () {
        try {
            //Если коннект уже есть
            if ( $this->connect != null ) {
                return true;
            }

            $options = [
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ];

            //коннектимся к базе
            $this->connect = new PDO( "mysql:host=" . $this->settings[ "host" ] . ";port=" . $this->settings[ "port" ] . ";dbname=" . $this->settings[ "dbName" ] . ";charset=utf8mb4", $this->settings[ "user" ], $this->settings[ "password" ], $options );

            return true;
        }
        catch ( \Exception $err ) {
            $this->lastError .= $err->getTraceAsString() . " | " . print_r( is_null($this->connect) ? [] : $this->connect->errorInfo(), true ) . "\n";

            return $err;
        }
    }

    //запускаем транзакцию
    public function startTransaction () {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            $this->connect->autocommit( false ); //запускаем транзакцию

            return true;
        }
        catch ( \Exception $err ) {
            return false;
        }
    }
    //отменяем транзакцию
    public function cancelTransaction () {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            $this->connect->rollback(); //отменяем транзакцию
            $this->connect->autocommit( true );

            return true;
        }
        catch ( \Exception $err ) {
            return false;
        }
    }
    //сохраняем транзакцию
    public function saveTransaction () {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                throw new \Exception( "нет коннекта" );
            }

            $this->connect->commit(); //сохраняем транзакцию
            $this->connect->autocommit( true );

            return true;
        }
        catch ( \Exception $err ) {
            return false;
        }
    }

    //дисконнект с бд
    public function close () {
        try {
            //Если нет коннекта
            if ( $this->connect == null ) {
                return true;
            }

            $this->connect = null; //сброс

            return true;
        }
        catch ( \Exception $err ) {
            return false;
        }
    }

    public function getLastError () {
        return $this->lastError;
    }
}