<?php

/*
 * создано 23.02.2023 17:41 НСК
 *
 * ДЛЯ РАБОТЫ С МОДАЛКАМИ
 *
 * */

include_once "constants.php";

include_once CLOSE . "xmlConfigs.php";                      //для работы с XML конфигами системы


//Поиск модалки по запросу. Массив модалок, нужное имя, контрольный запрос (токен)
function searchModal($modals, $needModalName, $needRequest)
{
    try {
        $needModalData = null;

        //перебираем модалки
        foreach ($modals as $modalName => $modalData) {
            //Если это наша модалка
            if ($modalName == $needModalName && $modalData["request"] == $needRequest) {
                $needModalData = $modalData;

                break;
            }
        }

        return $needModalData;
    } catch (Exception $err) {
        return null;
    }
}

//Получение модалок из структуры папок
function getFolderModals( $startPath, $rootPath = "", $prefix = "" )
{
    try {
        $modals = [];

        $rootPath = str_replace( "//", "/", $rootPath );

        //перебираем модалки в папке
        foreach (array_diff(scandir($startPath), array('.', '..')) as $index => $fileName) {
            //абсолютный путь до файла
            $filePath = $startPath . "/" . $fileName;

            //Если это папка
            if (is_dir($filePath)) {
                //получаем модалки папки
                $dirResult = getFolderModals( $filePath, $rootPath . $fileName . "/", $prefix );

                //Если модалки есть
                if (count($dirResult) > 0) {
                    //записываем её содержимое в массив
                    $modals = array_merge($modals, $dirResult);
                }

                continue;
            }

            //данные модалки
            $modalData = [
                "request" => substr(hash("sha256", date("m") . $filePath), 0, 12),
                "path" => $prefix . $rootPath . $fileName
            ];

            //открываем файл
            $file = fopen($filePath, "r");

            //название модалки для web-а (в первой строке модалки между разделителями)
            $modalName = fgets($file);

            //закрываем файл
            fclose($file);

            //получаем название модалки по регулярке
            preg_match_all("/.+?\b|||(\b.+?\b)|||/", $modalName, $matches);

            //Если нет результатов
            if (count($matches) == 0) {
                continue;
            }

            //берём название модалки
            $modalName = $matches[0][1];

            //Если строка коротка
            if (strlen($modalName) <= 3) {
                continue;
            }

            //записываем модалку
            $modals[$modalName] = $modalData;
        }

        return $modals;
    } catch (Exception $err) {
        return [];
    }
}