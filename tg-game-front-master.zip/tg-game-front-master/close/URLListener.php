<?php

/*
 * Класс для организации слушателя событий с их обработчиками
 *
 * Для нормальной работы класса необходимо настроить серверное ПО на перенаправление запросов в нужный php файл, в котором будет
 * экземпляр этого класса с заданными слушателями и который будет передавать URL путь на проверку в этот класс
 * */

class URLListener
{
    const TYPE_PAGE = "page";
    const TYPE_METHOD = "method";
    const TYPE_DIRECTLY = "directly";

    private $defaultTwigConfigs = [
        "auto_reload" => true
    ];
    private $isGlobal = true;           //true - в GLOBAL-с переменной. false - нет

    /*
     * Слушатели
     *
     * Массив состоит из ключей, которые являются регулярными выражениями обрабатываемых адресов
     *
     * например, ключ /api/* обрабатывает все адреса начинающиеся с /api/ (/api/users, /api/auth и т.д.). Слэш важен!
     *
     * данные обработчика содержат следующие обязательные ключи (содержимое некоторых ключей бывает разное, исходя из типа):
     *
     * worker - обработчик пути. Тут может быть разное значение, зависящее от типа (type). Если type=page, то worker должен быть страницей (html, php и т.д.).
     *          Если type=method, то worker должен содержать класс метода, в котором будет вызван метод, указанный в ключе method, пример значения \project\api::class.
     *          Если type=directly, то worker должен содержать папку, к которой будет добавлен запрашиваемый адрес, например, запрашивается путь /res/img/file.png, а
     *          worker равен /opt/www, то в итоге будет отдан локальный файл по пути /opt/www/res/img/file.png
     *
     * type - тип обработчика. page - страница (html, php и т.д.), method - будет вызван метод класса, directly - прямая отдача запрашиваемого файла
     *
     * необязательные данные обработчика:
     *
     * isDownload - true если нужно отдать файл на скачивание, false - если просто отдать файл. Обязательно при type == directly
     * method - строковое название метода класса, который будет вызван в обработчике worker. Обязательно при type == method
     * twig - если для обработки нужен шаблонизатор twig, то задаются его конфиги. environments - места для поиска шаблонов,
     *        configs - конфиги twig-а, context - переменные контекста, которые будут переданы при рендеринге страницы
     * */
    private $listeners = [
        /*"/" => [
            "worker" => "index.php",
            "type" => "page"
        ],
        "/manager/auth/" => [
            "worker" => "manager/auth.html",
            "type" => "page",
            "twig" => [
                "environments" => [
                    ["/websites/sait.ru/close/templates"],
                    ["/websites/sait.ru/close/admin/templates", "admin"]
                ],
                "configs" => [
                    "auto_reload" => false
                ],
                "context" => [
                    "user" => $user,
                    "constants" => get_defined_constants( true )[ "user" ]
                ]
            ]
        ],
        "/manager/admins/" => [
            "worker" => "manager/admins.php",
            "type" => "page"
        ],
        "/manager/requests/" => [
            "worker" => "manager/requests.php",
            "type" => "page"
        ],
        "/resources/*" => [
            "worker" => RESOURCES,
            "isDownload" => true,
            "type" => "directly"
        ],
        "/manager/apprin/admin/users/get/" => [
            "worker" => \project\api::class,
            "method" => "AdminUsersGet",
            "type" => "method"
        ]*/
    ];

    /*Методы для обработки запроса для каждого типа обработчика*/
    private $workTypeFunctions = [
        "page" => "workPage",
        "method" => "workMethod",
        "directly" => "workDirectly"
    ];

    /*Страницы HTTP статусов
     *
     * Ключ это код ошибки, 404, 500 и т.д.
     * Значение это массив с ключами:
     *          page (адрес страницы)
     *          text (текст сообщения, если нет или не задана страница). В текст можно вставлять текст ошибки, для этого надо добавить ::err_message:: в нужное
     *              место в тексте.
     *
     * Код 000 используется по дефолту, если для кода явно не определены данные
    */
    private $errHttpPages = [
        "404" => [
            "text" => "Страница не найдена"
        ],
        "500" => [
            "text" => "Внутренняя ошибка сервера"
        ],
        "000" => [
            "text" => "Возникла ошибка: ::err_message::"
        ]
    ];

    /*
     * isGlobal - true значит экземпляр слушателя запишется в глобальную переменную, false не запишется.
     * Каждый новый вызов с isGlobal = true будет перезаписывать старый слушатель!
     * */
    function __construct( $newTwigDefaultConfigs = [], $isGlobal = true ) {
        $GLOBALS[ get_class($this) ] = $this;

        //записываем индикатор
        $this->isGlobal = $isGlobal;

        //перебираем ключи конфигов twig-а
        foreach ( $newTwigDefaultConfigs as $key => $value ) {
            $this->defaultTwigConfigs[ $key ] = $value;
        }
    }

    //поиск обработчика адреса
    private function getWorker ( $needPath, $array ) {
        try {
            $workerSearch = null;

            //перебираем ключи массива
            foreach ( $array as $key => $data ) {
                //echo "/" . str_replace("/", "\\/", $key) . "/";

                //Если есть принимаемые символы из регулярки
                if ( stripos( $key, ".*" ) !== false ) {
                    //результат поиска соответствия
                    $result = preg_match( "/^" . str_replace( ["/", "?", "#"], ["\/", "\?", "\#"], $key ) . "/", $needPath );

                    if ( !$result || $key == "/" && $key != $needPath ) {
                        continue;
                    }

                    $workerSearch = $data;

                    break;
                }
                else {
                    //Если пути не равны
                    if ( $key != $needPath ) {
                        continue;
                    }

                    $workerSearch = $data;

                    break;
                }

                //echo "Совпадение " . "/^" . str_replace("/", "\/", $key) . "$/" . " | " . $needPath;
            }

            return $workerSearch;
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    //Добавить/Заменить HTTP код ошибки
    function addHTTPCode ( $code, $text = null, $page = null ) {
        try {
            if ( is_null($text) && is_null($page) ) {
                throw new Exception( "Нужно задать страницу или текст" );
            }

            $this->errHttpPages[ strval($code) ] = [];

            if ( !is_null($text) ) {
                $this->errHttpPages[ strval($code) ][ "text" ] = $text;
            }

            if ( !is_null($page) ) {
                $this->errHttpPages[ strval($code) ][ "page" ] = $page;
            }

            return true;
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    //Добавить/Заменить HTTP коды ошибок
    function addHTTPCodes ( $codes ) {
        try {
            foreach ( $codes as $index => $code ) {
                $code = $code["code"];
                $text = $code["text"] ?? null;
                $page = $code["page"] ?? null;

                //добавляем код
                if ( !$this->addHTTPCode( $code, $text, $page ) ) {
                    return false;
                }
            }

            return true;
        }
        catch ( Exception $err ) {
            return null;
        }
    }

    //Добавить слушателя
    function addListener ( $path, $listenerData ) {
        try {
            //Если путь есть уже
            if ( array_key_exists($path, $this->listeners) ) {
                return true;
            }

            //добавляем слушатель
            $this->listeners[ $path ] = $listenerData;

            return true;
        }
        catch ( Exception $err ) {
            return false;
        }
    }

    //Добавить слушателей
    function addListeners ( $listenersData ) {
        try {
            foreach ( $listenersData as $index => $listenerData ) {
                $paths = explode( "||", $listenerData["path"] );

                unset( $listenerData["path"] );

                foreach( $paths as $path ) {
                    //добавляем слушатель
                    if ( !$this->addListener( $path, $listenerData ) ) {
                        return false;
                    }
                }
            }

            return true;
        }
        catch ( Exception $err ) {
            return false;
        }
    }

    /*
     * Обработка адреса
     *
     * path - обрабатываемый путь URL адреса
     * isReturnResult - true вовзаращать результат обработки, false не возвращать
     * isSingleWork - true ответ клиенту будет предоставлен по полной программе, включая ошибки, то есть не надо обрабатывать результат этой функции.
     * false будет дан ответ клиенту (будет попытка дать ответ), но если ошибка, то нужно самостоятельно обработать её и выдать ответ клиенту
     * */
    function workPath ( $path, $isReturnResult = false, $isSingleWork = true ) {
        try {
            if ( $path == "" ) {
                $path = "/";
            }

            //данные обработчика
            $workerData = $this->getWorker( $path, $this->listeners );

            //Если нет обработчика
            if ( is_null($workerData) ) {
                throw new Exception( "Нет обработчика", 404 );
            }

            //Если нет функции для обработки данного типа
            if ( !array_key_exists($workerData["type"], $this->workTypeFunctions) ) {
                throw new Exception( "Не функции для обработки" );
            }

            $funcName = $this->workTypeFunctions[ $workerData["type"] ];

            //вызываем функцию для обработки
            $result = $this->$funcName( $workerData, $path );

            //Если полная обработка запроса
            if ( $isSingleWork ) {
                //Если не успех
                if ( $result["status"] != "ok" ) {
                    throw new Exception( $result["text"], isset($result["code"]) ? $result["code"] : 500 );
                }
                else {
                    //Если есть информация
                    if ( isset( $result["data"] ) ) {
                        //выводим данные
                        echo $result[ "data" ];
                    }
                }
            }

            //Если нужно возвращать результат
            if ( $isReturnResult ) {
                return $result;
            }
        }
        catch ( Exception $err ) {
            $result = [
                "status" => "error",
                "text" => $err->getMessage(),
                "code" => $err->getCode()
            ];

            //Если нужно возвращать результат
            if ( $isReturnResult ) {
                return $result;
            }

            //Если полная обработка запроса
            if ( $isSingleWork ) {
                //Если задан код ошибки
                if ( isset($result["code"]) ) {
                    header('HTTP/1.0 ' . $result["code"] . ' ' . $result["text"]);
                }

                $errPageData = null;

                //Если есть данные страницы с ошибкой
                if ( array_key_exists( strval($result["code"]), $this->errHttpPages) ) {
                    $errPageData = $this->errHttpPages[ strval($result["code"]) ];
                }
                else {
                    //берём данные по дефолту
                    $errPageData = $this->errHttpPages["000"];
                }

                //Если задана страница и она есть
                if ( !is_null($errPageData) && isset($errPageData["page"]) && file_exists($errPageData["page"]) ) {
                    //отдаём станицу
                    echo file_get_contents($errPageData["page"]);
                }
                else {
                    $messageShow = $err->getMessage();

                    //Если задан текст
                    if ( isset($errPageData["text"]) ) {
                        //вставляем в текст текст ошибки (может там и нет места для вставки, но на всякий случай)
                        $messageShow = str_replace( "::err_message::", $err->getMessage(), $errPageData["text"] );
                    }
                }
                echo $messageShow;
            }
        }
    }

    //Обработка типа - page
    private function workPage ( $workData, $path ) {
        try {
            $return = "";

            //Если есть файл и нет конфигов сборщиков
            if ( !isset($workData["twig"]) && is_file($workData[ "worker" ]) ) {
                ob_start();

                include( $workData["worker"] );

                $return = ob_get_clean();
            }
            else {
                //Если шаблонизатор twig
                if ( isset($workData[ "twig" ]) ) {
                    $loader = new \Twig\Loader\FilesystemLoader( );

                    //перебираем переменные окружения
                    foreach ( $workData[ "twig" ][ "environments" ] as $envData ) {
                        //Если задано пространство имён
                        if ( count($envData) == 2 ) {
                            $loader->addPath( $envData[0], $envData[1] );
                        }
                        else {
                            $loader->addPath( $envData[0] );
                        }
                    }

                    //конфиги шаблонизатора
                    $configs = $this->defaultTwigConfigs;

                    //Если заданы конфиги в обработчике
                    if ( isset($workData[ "twig" ][ "configs" ]) ) {
                        //перебираем конфиги
                        foreach ( $workData[ "twig" ][ "configs" ] as $key => $value ) {
                            //записываем конфиг
                            $configs[ $key ] = $value;
                        }
                    }

                    //переменные контекста
                    $context = [];

                    //Если заданы переменные контекста
                    if ( isset($workData[ "twig" ][ "context" ]) ) {
                        //перебираем переменные
                        foreach ( $workData[ "twig" ][ "context" ] as $key => $value ) {
                            //Если в глобалс и этот ключ равен нашему классу
                            if ( $this->isGlobal && $key == get_class($this) ) {
                                //пропускаем переменную
                                continue;
                            }

                            //записываем переменную
                            $context[ $key ] = $value;
                        }
                    }

                    //создаём твиг
                    $twig = new \Twig\Environment( $loader, $configs );

                    // Если есть функции
                    if ( isset( $workData[ "twig" ][ "functions" ] ) && count( $workData[ "twig" ][ "functions" ] ) > 0 ) {
                        // Перебираем функции
                        foreach ( $workData[ "twig" ][ "functions" ] as $function ) {
                            $function = new \Twig\TwigFunction( $function[ 0 ], $function[ 1 ] );
                        }

                        // Добавляем функцию в твиг
                        $twig->addFunction( $function );
                    }

                    //загружаем нужный шаблон
                    $template = $twig->load( $workData["worker"] );

                    //рендерим шаблон в заданном контексте
                    $return = $template->render( $context );
                }
            }

            if ( $return === false ) {
                throw new Exception( "Не удалось открыть страницу" );
            }

            return [
                "status" => "ok",
                "data" => $return
            ];
        }
        catch ( Exception $err ) {
            echo $err->getMessage();

            die();

            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
    }

    //Обработка типа - method
    private function workMethod ( $workData, $path ) {
        try {
            //экземпяр класса
            $worker = new $workData["worker"]();
            $workerMethod = $workData["method"];

            //вызываем метод класса
            $worker->$workerMethod();

            return [
                "status" => "ok"
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
    }

    //Обработка типа - directly
    private function workDirectly ( $workData, $path ) {
        try {
            $filePath = $workData["worker"] . $path;

            if ( !file_exists($filePath) ) {
                throw new Exception( "Файла нет" );
            }

            //сбрасываем буфер
            if (ob_get_level()) {
                ob_end_clean();
            }

            //отдаём файл
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');

            if ( $workData["isDownload"] ) {
                header('Content-Disposition: attachment; filename=' . basename($filePath) );
            }

            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filePath) );

            //отдаём файл клиенту
            readfile($filePath);

            return [
                "status" => "ok"
            ];
        }
        catch ( Exception $err ) {
            return [
                "status" => "error",
                "text" => $err->getMessage()
            ];
        }
    }
}