#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""
Класс для работы с пользователями
"""
import json
import logging
import re
import traceback
from time import sleep

import validators
from aiogram.types import *

from bd import BD
from settings import Settings
from telegram import Telegram
from requests.utils import quote

class Users:
    bd = None
    lang = None
    logger = logging.getLogger(__name__)
    def __init__(self, lang, bd=None):
        try:
            if bd is None:
                self.bd = BD()
            else:
                self.bd = bd
            self.lang = lang
        except Exception as err:
            traceback.print_exc()

    # Установка индикатора премиума
    async def setIsPremium(self, uuid=None, isPremium=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")

            if uuid is None or isPremium is None:
                raise Exception("Не переданы параметры")

            await self.bd.queryPrepareUpdate(
                "UPDATE `users` SET `is_premium` = %s WHERE `uuid` = %s",
                [isPremium, uuid])

            return True
        except Exception as err:
            print(str(err))
            traceback.print_exc()

            return None

    # Получение публичного ИД юзера
    async def getUUID(self, user_id=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if user_id is None:
                raise Exception("Не переданы параметры")

            # Берём публичный uuid юзера
            result = await self.bd.queryPrepare(
                "SELECT `uuid`, `is_blocked`  FROM `users` WHERE `user_id` = %s", [user_id])

            if result is None or len(result) != 1:
                raise Exception("Ошибка или пользователь не найден")

            # if result[0]["is_blocked"] == 1:
            #     raise Exception(f"Пользователь заблокирован {str(user_id)}")

            return str(result[0]["uuid"])
        except Exception as err:
            print(str(err))
            traceback.print_exc()

            return None

    # Получение общего количества юзеров
    async def getAllUsersCount(self):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")

            # Добавляем данные в таблицу хронологии клейма
            result = await self.bd.query(
                "SELECT COUNT(*) AS `count` FROM `users`")

            if result is None:
                raise Exception("Ошибка получения общего количества юзеров")

            return int(result[0]["count"])
        except Exception as err:
            print(str(err))
            traceback.print_exc()

            return None

    # Получение буквенного обозначения выбранного языка пользователем
    async def getLangChar(self, userID=None, user_id=None):
        try:
            if await  self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")

            if userID is None and user_id is None:
                raise Exception("Не переданы параметры")

            # Добавляем данные в таблицу хронологии клейма
            result = await self.bd.query(
                "SELECT `char` FROM `langs` as `a` WHERE `a`.`id` = (SELECT `langs_id` FROM `users` as `b` WHERE " +
                ("`b`.`id` = " + str(
                    userID) if userID is not None else "`b`.`user_id` = \"" + str(
                    user_id) + "\"") + ")")

            if result is None or len(result) != 1:
                raise Exception("Не получен язык пользователя")

            return result[0]["char"]
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

    # Получение буквенного обозначения выбранного языка пользователем
    async def getLangID(self, userID=None, user_id=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None and user_id is None:
                raise Exception("Не переданы параметры")

            # Добавляем данные в таблицу хронологии клейма
            result = await self.bd.query(
                "SELECT `langs_id` FROM `users` as `b` WHERE " + (
                    "`b`.`id` = " + str(
                        userID) if userID is not None else "`b`.`user_id` = \"" + str(
                        user_id) + "\""))

            if result is None or len(result) != 1:
                raise Exception("Не получен язык пользователя")

            return result[0]["langs_id"]
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

    # Поиск задачи в выполненных

    async def isEndTask(self, userID=None, taskID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None or taskID is None:
                raise Exception("Не переданы параметры")

            result = await self.bd.queryPrepare(
                "SELECT `id` FROM `user_end_tasks` WHERE `user_id` = %s AND `tasks_id` = %s",
                [userID, taskID])

            if result is None:
                raise Exception("Не получены данные о выполнении задания")

            return False if len(result) == 0 else True
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

    async def getTasks(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Не переданы параметры")

            result = await self.bd.query(
                "SELECT * FROM `tasks` AS `a` WHERE `date_start` <= NOW() AND (`date_end` IS NULL OR `date_end` >= NOW()) AND "
                "`a`.`id` NOT IN (SELECT `tasks_id` FROM `user_end_tasks` AS `b` WHERE `b`.`user_id` = " + str(
                    userID) + ") "
                              "ORDER BY `number` ASC, `date_create` DESC")

            if result is None:
                raise Exception("Не получены доступные задачи юзера")

            items = []

            for row in result:
                item = {
                    "type": int(row["type"]),
                    "data": json.loads(row["data"]),
                    "link": None if "link" not in row else str(row["link"]),
                    "id": int(row["id"]),
                    "sum": int(row["sum"])
                }

                items.append(item)

            return items
        except Exception as err:
            print(str(err))

            traceback.print_exc()

        return None

    # Получение данных задачи

    async def getTask(self, taskID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if taskID is None:
                raise Exception("Не переданы параметры")

            result = await self.bd.query(
                "SELECT * FROM `tasks` AS `a` WHERE `id` = " + str(taskID))

            if result is None:
                raise Exception("Не получены данные задачи")

            item = {
                "type": int(result[0]["type"]),
                "data": json.loads(result[0]["data"]),
                "id": int(result[0]["id"]),
                "sum": int(result[0]["sum"])
            }

            return item
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Добавление задачи в выполненные

    async def addEndTask(self, userID=None, taskID=None, data={}):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None or taskID is None:
                raise Exception("Не переданы параметры")

            await self.bd.queryPrepareUpdate(
                "INSERT INTO `user_end_tasks` (`user_id`, `tasks_id`, `data`) VALUES (%s, %s, %s)",
                [userID, taskID, json.dumps(data)])

            result = await self.bd.query(
                "SELECT COUNT(`id`) AS `count` FROM `user_end_tasks` WHERE `user_id` = " + str(
                    userID) + " AND `tasks_id` = " + str(taskID))

            if result is None or len(result) != 1 or int(
                    result[0]["count"]) != 1:
                raise Exception("Не найдена добавленная выполненная задача")

            # Увеличиваем баланс пользователя
            await self.bd.queryUpdate(
                "UPDATE `users` SET `balance` = `balance` + " + str(
                    data["sum"]) + " WHERE `id` = " + str(userID))

            return True
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Добавление задачи в выполненные (начисляются ракеты)

    async def addEndTaskRockets(self, userID=None, taskID=None, data={}):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None or taskID is None:
                raise Exception("Не переданы параметры")

            await  self.bd.queryPrepareUpdate(
                "INSERT INTO `user_end_tasks` (`user_id`, `tasks_id`, `data`) VALUES (%s,%s, %s)",
                [userID, taskID, json.dumps(data)])

            result = await self.bd.query(
                "SELECT COUNT(`id`) AS `count` FROM `user_end_tasks` WHERE `user_id` = " + str(
                    userID) + " AND `tasks_id` = " + str(taskID))

            if result is None or len(result) != 1 or int(
                    result[0]["count"]) != 1:
                raise Exception("Не найдена добавленная выполненная задача")

            # Увеличиваем баланс пользователя
            await self.bd.queryUpdate(
                "UPDATE `users` SET `balance_rockets` = `balance_rockets` + " + str(
                    data["sum"]) + " WHERE `id` = " + str(userID))

            # Увеличиваем количество юзеров, которые выполнили задание
            await self.bd.queryPrepareUpdate(
                "UPDATE `tasks` SET `curr_count` = `curr_count` + 1 WHERE `id` = %s",
                [taskID])

            return True
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Смена языка пользователя

    async def changeLang(self, userID=None, langID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None and langID is None:
                raise Exception("Не переданы параметры")

            await self.bd.queryUpdate(
                "UPDATE `users` SET `langs_id` = " + str(
                    langID) + " WHERE `id` = " + str(userID))

            return True
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Проверка можно ли клеймить

    async def isDoClaim(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Не переданы параметры")

            settings = Settings(self.bd)

            cleimSettings = await settings.getCleimSettings()

            if cleimSettings is None:
                raise Exception("Ошибка при получении настроек клейма")

            # интервал клейма в часах
            cleimInterval = int(cleimSettings["interval"])

            result = await self.bd.query(
                "SELECT IF(DATE_ADD(`date_create`, INTERVAL " + str(
                    cleimInterval) + " hour) <= NOW(), 1, 0) AS `is_end` "
                                     "FROM `users_sum_wallet` "
                                     "WHERE `user_id` = " + str(
                    userID) + " ORDER BY `date_create` DESC LIMIT 1")

            if result is None:
                raise Exception("Не удалось получить данные последнего клейма")

            # Если последний клейм завершён (можно клеймить ещё)
            if len(result) == 1 and int(result[0]["is_end"] == 1):
                result = {
                    "status": "ok"
                }
            else:
                # Выбираем общее количество записей о клейме
                result = await self.bd.query(
                    "SELECT COUNT(`id`) AS `count` FROM `users_sum_wallet` WHERE `user_id` = " + str(
                        userID))

                if result is None:
                    raise Exception(
                        "Не удалось получить данные всех клеймов юзера")

                # Если клейма вообще не было
                if int(result[0]["count"]) == 0:
                    result = {
                        "status": "ok"
                    }
                else:
                    # Определяем разницу во времени, чтобы узнать сколько осталось до следующего клейма
                    result = await self.bd.query(
                        "SELECT TIMESTAMPDIFF(SECOND, NOW(), DATE_ADD(`date_create`, INTERVAL " + str(
                            cleimInterval) + " hour)) AS `date_cleim` FROM `users_sum_wallet` WHERE `user_id` = " + str(
                            userID) + " ORDER BY `date_create` DESC LIMIT 1")

                    if result is None or len(result) != 1:
                        raise Exception(
                            "Не удалось получить данные последнего клейма 2")

                    result = {
                        "date": result[0]["date_cleim"],
                        "status": "noDo"
                    }

            return result
        except Exception as err:
            print(str(traceback.format_exc()))

            traceback.print_exc()

            return {
                "status": "error"
            }

        # Клейм крипты

    async def claim(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Не переданы параметры")

            result = await self.isDoClaim(userID=userID)

            if result["status"] != "ok":
                return {
                    "status": "noDoCleim",
                    "date": result["date"]
                }

            # количество рефералов
            refCounts = await self.getReferralsStatistic(userID=userID)

            if refCounts is None:
                raise Exception("Не получена статистика рефералов")

            settings = Settings(self.bd)

            cleimSettings = await settings.getCleimSettings()

            if cleimSettings is None:
                raise Exception("Ошибка при получении настроек клейма")

            # количество активированных рефералов
            activeRefCounts = refCounts["active"]
            # сумма добавления
            sum = cleimSettings["sum"]["0"]

            # Если есть активированные рефералы
            if activeRefCounts > 0:
                # Перебираем количество рефералов по убывающей
                for number in reversed(range(activeRefCounts)):
                    # Если номера нет в заданных
                    if str(number) not in cleimSettings["sum"]:
                        continue

                    # Берём новую сумму за количество активированных рефералов
                    sum = int(cleimSettings["sum"][str(number)])

                    break

            # Добавляем данные в таблицу хронологии клейма
            await self.bd.queryUpdate(
                "INSERT INTO `users_sum_wallet` (`user_id`, `sum`) VALUES (" + str(
                    userID) + ", " + str(sum) + ")")

            # print("INSERT INTO `users_sum_wallet` (`user_id`, `sum`) VALUES (" + str( userID ) + ", " + str( sum ) + ")")

            # Увеличиваем баланс пользователя
            await self.bd.queryUpdate(
                "UPDATE `users` SET `balance` = `balance` + " + str(
                    sum) + " WHERE `id` = " + str(userID))

            result = {
                "status": "ok",
                "addBalance": sum,
                "interval": cleimSettings["interval"]
            }

            return result
        except Exception as err:
            print(str(err))
            traceback.print_exc()
            self.logger.error(traceback.format_exc())

            return None

        # Получение статистики по рефералам

    async def getReferralsStatistic(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Не переданы параметры")

            result = await self.bd.query(
                "SELECT (SELECT COUNT(`id`) FROM `referals` WHERE `referer_user_id` = " + str(
                    userID) + ") AS `all`, "
                              "(SELECT COUNT(`id`) FROM `referals` AS `a` WHERE `a`.`referer_user_id` = " + str(
                    userID) + " AND "
                              "(SELECT COUNT(`id`) FROM `user_main_subsribe` AS  `b` WHERE `a`.`referal_user_id` = `b`.`user_id`) > 0) AS `active`")

            if result is None or len(result) != 1:
                raise Exception("Не удалось найти статистику пользователя")

            result = {
                "all": result[0]["all"],
                "active": result[0]["active"]
            }

            return result
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Получение баланса

    async def getBalance(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Не переданы параметры")

            result = await self.bd.query(
                "SELECT `balance` FROM `users` WHERE `id` = \"" + str(
                    userID) + "\"")

            if result is None or len(result) != 1:
                raise Exception("Не удалось найти баланс пользователя")

            return result[0]["balance"]
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Получение реферальной ссылки

    async def getRefLink(self, userID=None, botUsername=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None or botUsername is None:
                raise Exception("Не переданы параметры")

            user_id = await self.getUser_id(userID=userID)

            if user_id is None:
                raise Exception("Ошибка при получении user_id")

            link = "https://t.me/" + str(botUsername) + "?start=" + str(user_id)

            return link
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return None

        # Регистрация юзера (если его не было)

    async def regUser(self, message: Message = None, projectID=None,
                      projectType=None, tg=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if message is None:
                raise Exception("Не передано сообщение")

            print("Message", str(message))

            user_id = message.from_user.id
            username = str(
                message.from_user.username) if message.from_user.username is not None else str(
                message.from_user.first_name)

            if validators.url(
                    username) or 'http:/' in username or '<script' in username:
                username = quote(username, safe='')

            linkKey = message.text.split("/start ")
            isPremium = message.from_user.is_premium is True

            print("Username " + str(username))
            print("From" + str(message.from_user))

            if len(linkKey) == 2:
                linkKey = str(linkKey[1])
            else:
                linkKey = None

            print("Ключ ссылки " + str(linkKey))

            await self.bd.queryPrepareUpdate(
                "INSERT INTO `users` (`username`, `user_id`, `chat_id`, `is_premium`) "
                "VALUES (%s, %s, %s, %s) ON DUPLICATE KEY UPDATE `username` = %s, `is_premium` = %s",
                [
                    username, str(user_id), str(message.chat.id),
                    1 if isPremium is True else 0, username,
                    1 if isPremium is True else 0
                ]
            )



            result = await self.bd.query(
                "SELECT `id`, `username`, (IF(`date_create` < NOW(), 0, 1)) AS `is_new` FROM `users` WHERE `user_id` = \"" + str(
                    user_id) + "\"")

            # пауза перед выгрузкой
            sleep(1)

            if result is None:
                return None
            try:
                userID = int(result[0]["id"])
            except Exception as e:
                return None

            userID = int(result[0]["id"])

            try:
                last_quiz = await self.bd.query(
                    "select * from game_daily_quiz_users order by id desc  limit 1")

                await self.bd.queryPrepareUpdate(
                    "INSERT INTO game_daily_quiz_users (users_id, game_daily_quiz_questions_ids, sum, balance, date_activate, img, sum_good_answer, sum_enter, answer_time)"
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    [
                        userID,
                        last_quiz[0]["game_daily_quiz_questions_ids"],
                        0,
                        0,
                        last_quiz[0]["date_activate"],
                        last_quiz[0]["img"],
                        last_quiz[0]["sum_good_answer"],
                        last_quiz[0]["sum_enter"],
                        last_quiz[0]["answer_time"],
                    ]
                )
            except:
                pass

            userData = {
                "id": int(result[0]["id"]),
                "username": result[0]["username"],
                "isNew": int(result[0]["is_new"]) == 1
            }

            # Если есть ключ ссылки И юзер новый
            if linkKey is not None and userData["isNew"] is True:
                print("Добавляем реферала")

                # Индикатор того, что юзер уже является рефералом
                isReferal = await self.isReferal(userID=int(result[0]["id"]))

                # Если юзер не реферал ещё
                if isReferal is False:
                    pattern = re.compile("[a-zA-Z]+")
                    # ID реферера
                    refererID = None
                    # ID ссылки
                    linkID = 0

                    # Если в строке есть буквы
                    if pattern.search(linkKey) is not None:
                        # Ищем активную ссылку с таким ключом
                        result = await self.bd.queryPrepare(
                            "SELECT `users_id`, `id` FROM `users_ref_links` WHERE `key` = %s AND `is_active` = 1",
                            [linkKey]
                        )

                        # Если удалось найти активную ссылку
                        if result is not None and len(result) == 1:
                            refererID = int(result[0]["users_id"])
                            linkID = int(result[0]["id"])

                            print("Реф. ссылка найдена " + str(
                                refererID) + " " + str(linkID))
                        else:
                            print("Реф. ссылка не найдена")
                    else:

                        refererID = await self.getUserID(user_id=int(linkKey))

                    if refererID is None:
                        raise Exception(
                            "Ошибка получения userID при добавлении реферала")

                    # Добавляем реферала
                    await self.addReferal(refererID=refererID, referalID=userID,
                                    linkID=linkID)

                    # print("Активируем реферала")

                    # активируем реферала
                    await self.activeReferal(referalID=userID,
                                             isPremium=isPremium, tg=tg)
                else:
                    print("Реферал уже является рефералом")
            else:
                print(
                    "Ключа нет или юзер не новый " + str(linkKey) + " | " + str(
                        userData))

            # Если есть ключ ссылки И юзер не новый
            if linkKey is not None and userData["isNew"] is not True:
                userData["noWorkLink"] = True

            return userData
        except Exception as err:
            print(str(err))
            traceback.print_exc()
            self.logger.error(traceback.format_exc())

            return None

        # Добавление обязательных подписок

    async def addMainSubscribers(self, userID=None, subscribers=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None or subscribers is None:
                raise Exception("Переданы невалидные значения")

            currentSubscribers = await self.getCurrentMainSubscribers(
                userID=userID)

            if currentSubscribers is None:
                raise Exception(
                    "Не найдены обязательные текущие подписки " + str(userID))

            # ID ресурсов для вставки
            insertIDS = []

            print("Нужны для подписи " + str(subscribers))
            print("Имеются подписанные " + str(currentSubscribers))

            # Перебираем нужные ресурсы для подписки
            for needSubscribeID in subscribers:
                isSubscribe = False

                # Перебираем ресурсы, на которые уже подписан пользователь
                for currentSubscribe in currentSubscribers:
                    if str(currentSubscribe["chatID"]) == str(needSubscribeID):
                        isSubscribe = True

                        break

                if isSubscribe is True:
                    continue

                insertIDS.append(needSubscribeID)

            print("Будут вставлены " + str(insertIDS))

            # Если есть данные для вставки
            if len(insertIDS) > 0:
                for chatID in insertIDS:
                    await self.bd.queryUpdate(
                        "INSERT INTO `user_main_subsribe` (`user_id`, `chat_id`) VALUES (" + str(
                            userID) + ", \"" + str(chatID) + "\")")

            return True
        except Exception as err:
            print(traceback.print_exc())

            return False

        # Добавление реферала

    async def addReferal(self, refererID=None, referalID=None, linkID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if refererID is None or referalID is None:
                raise Exception("Переданы невалидные значения")

            if refererID == referalID:
                raise Exception("ИД реферала и рефера равны")

            isExistReferal = await self.isExistReferal(refererID=refererID,
                                                 referalID=referalID)

            if isExistReferal is True or isExistReferal is None:
                raise Exception(
                    "Реферал " + str(referalID) + " у рефера " + str(
                        refererID) + " уже есть или ошибка")

            # Добавляем
            await self.bd.queryPrepareUpdate(
                "INSERT INTO `referals` (`referal_user_id`, `referer_user_id`, `ref_link_id`) VALUES (%s, %s, %s)",
                [
                    str(referalID),
                    str(refererID),
                    linkID if linkID is not None else 0
                ])

            return True
        except Exception as err:
            print(traceback.print_exc())

            return None

        # Проверка является ли юзер рефералом

    async def isReferal(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Переданы невалидные значения")

            # Ищем
            result = await self.bd.query(
                "SELECT `id` FROM `referals` WHERE `referal_user_id` = " + str(
                    userID))

            if result is None:
                raise Exception(
                    "Ошибка определения юзера как реферала " + str(userID))

            if len(result) != 0:
                return True

            return False
        except Exception as err:
            print(traceback.print_exc())

            return None

        # Проверка наличия реферала

    async def isExistReferal(self, referalID=None, refererID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if referalID is None or refererID is None:
                raise Exception("Переданы невалидные значения")

            # Ищем
            result = await self.bd.query(
                "SELECT * FROM `referals` WHERE `referal_user_id` = " + str(
                    referalID) + " AND `referer_user_id` = " + str(refererID))

            if result is None:
                raise Exception(
                    "Ошибка поиска реферала у рефера " + str(referalID))

            if len(result) != 1:
                return False

            return True
        except Exception as err:
            print(traceback.print_exc())

            return None

    # Получение суммы, которая положена юзеру за рефералла

    async def getRefererPaySumForReferal(self, refererID=None,
                                         isPremiumReferal=False):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if refererID is None:
                raise Exception("Переданы невалидные значения")

            # Выбираем множитель юзера
            result = await self.bd.queryPrepare(
                "SELECT * FROM `referal_multi` WHERE `user_id` = %s AND is_active = 1",
                [refererID])

            if result is None:
                raise Exception(
                    "Ошибка поиска вознаграждения реферу " + str(refererID))

            # конфиги множителя юзера
            refMultConfig = {}

            # Если есть данные множителя
            if len(result) > 0:
                refMultConfig = {
                    "mult": float(result[0]["mult"]),
                    "condition": int(result[0]["condition"]),
                    "conditionData": json.loads(result[0]["condition_data"]),
                    "isActive": True if int(
                        result[0]["is_active"]) == 1 else False
                }

            # print( "КОНФИГИ рефералки " + str( refMultConfig ) )

            settings = Settings(bd=self.bd)
            settingsRef = await settings.getReferalsSettings()

            # вознаграждение реферу
            refPay = settingsRef[
                "refererPay"] if "refererPay" in settingsRef else 100
            # вознаграждение реферу - ракеты
            refPayRockets = settingsRef[
                "refererPayRockets"] if "refererPayRockets" in settingsRef else 1

            # Если реферал премиумный
            if isPremiumReferal is True:
                # вознаграждение реферу
                refPay = settingsRef[
                    "refererPremiumPay"] if "refererPremiumPay" in settingsRef else 200
                # вознаграждение реферу - ракеты
                refPayRockets = settingsRef[
                    "refererPremiumPayRockets"] if "refererPremiumPayRockets" in settingsRef else 2

            # Если есть конфиги множителя
            if "mult" in refMultConfig:
                # Если условий нет
                if refMultConfig["condition"] == 0:
                    refPay *= refMultConfig["mult"]
                    refPayRockets *= refMultConfig["mult"]

                # Если условие это максимум юзеров в системе
                if refMultConfig["condition"] == 1:
                    # Если в данных условия нет обязательных параметров
                    if "maxCount" not in refMultConfig["conditionData"]:
                        raise Exception(
                            "Нет обязательных параметров в конфигах")

                    allUsersCount = await self.getAllUsersCount()

                    if allUsersCount is None:
                        raise Exception("Не получено общее количество юзеров")

                    # Если текущее количество юзеров меньше или равно максимуму
                    if allUsersCount <= refMultConfig["conditionData"][
                        "maxCount"]:
                        refPay *= refMultConfig["mult"]
                        refPayRockets *= refMultConfig["mult"]

            refPay = int(refPay)
            refPayRockets = int(refPayRockets)

            return {
                "money": refPay,
                "rockets": refPayRockets
            }
        except Exception as err:
            # print( "Ошибка " + str(err) )

            print(traceback.print_exc())

            return None

        # Активация реферала (добавление бонусов)

    async def activeReferal(self, referalID=None, isPremium=False,
                            tg: Telegram = None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if referalID is None:
                raise Exception("Переданы невалидные значения")

            # print( "--- " + ("None" if referalID is None else str(referalID)) )

            # Проверяем привёл ли кто-то пользователя
            result = await self.bd.query(
                "SELECT * FROM `referals` WHERE `referal_user_id` = " + str(
                    referalID) + " AND is_active = 0")

            if result is None:
                raise Exception(
                    "Ошибка поиска рефера у рефералла " + str(referalID))

            # Если рефера нет
            if len(result) != 1:
                # print( "Рефера нет " + "SELECT * FROM `referals` WHERE `referal_user_id` = " + str(referalID) + " AND is_active = 0" )

                return None

            # ID рефера
            refererID = int(result[0]["referer_user_id"])
            # username реферала
            referalUsername = await self.getUsername(userID=referalID)

            if referalUsername is None:
                raise Exception("Не получен юзернэйм реферала")

            settings = Settings(bd=self.bd)
            settingsCurr = await  settings.getCurrencySettings()

            # берём сумму вознаграждения реферу
            refPay = await self.getRefererPaySumForReferal(refererID=refererID,
                                                     isPremiumReferal=isPremium)

            # активируем реферала и добавляем сколько принёс он
            await self.bd.queryUpdate(
                "UPDATE `referals` SET is_active = 1, earn = earn + " + str(
                    refPay["money"]) + ", rockets = rockets + " + str(
                    refPay["rockets"]) + " WHERE `referal_user_id` = " + str(
                    referalID) + " AND is_active = 0")

            # print( "UPDATE `referals` SET is_active = 1, earn = earn + " + str( refPay[ "money" ] ) + ", rockets = rockets + " + str( refPay[ "rockets" ] ) + " WHERE `referal_user_id` = " + str(referalID) + " AND is_active = 0" )

            # начисляем реферу вознаграждение
            await self.bd.queryUpdate("UPDATE `users` "
                                       "SET balance = balance + " + str(
                refPay["money"]) + ", "
                                   "balance_rockets = balance_rockets + " + str(
                refPay["rockets"]) + " WHERE `id` = " + str(refererID))

            if tg is not None:
                user_id = await self.getUser_id(refererID)

                if user_id is None:
                    raise Exception("Не получен user_id при активации реферала")

                textData = {
                    "refUsername": referalUsername,
                    "sum": refPay["money"],
                    "currTokenName": settingsCurr["tokenName"]
                }

                text = await self.lang.getLangText(await self.getLangChar(userID=refererID),
                                             "active_referal_message", textData)

                print("Шлём реферу " + str(user_id) + " сообщение " + text)

                # шлём сообщение реферу
                await tg.sendMessage(chatID=user_id, text=text)

            return True
        except Exception as err:
            # print( "Ошибка " + str(err) )

            print(traceback.print_exc())

            return None

        # Получение данных о обязательных подписках юзера

    async def isAllSubscribe(self, userID=None, allSubscribers=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Переданы невалидные значения")

            currentSubscribers = await self.getCurrentMainSubscribers(
                userID=userID)

            if currentSubscribers is None:
                raise Exception(
                    "Не найдены обязательные текущие подписки " + str(userID))

            isAll = True

            if allSubscribers is None:
                settings = Settings(self.bd)

                allSubscribers = await  settings.getAllMainSubscribe()

                if allSubscribers is None:
                    raise Exception(
                        "Не получены все обязательные ресурсы для подписки")

            # Перебираем нужные ресурсы для подписки
            for needSubscribeID in allSubscribers:
                isSubscribe = False

                # Перебираем ресурсы, на которые уже подписан пользователь
                for currentSubscribe in currentSubscribers:
                    if str(currentSubscribe["chatID"]) == str(needSubscribeID):
                        isSubscribe = True

                        break

                if isSubscribe is False:
                    isAll = False

                    break

            # Если нет обязательных ресурсов для подписки
            if len(allSubscribers) == 0:
                isAll = True

            return isAll
        except Exception as err:
            print(traceback.print_exc())

            return False

        # Получение данных о текущих главных подписках юзера

    async def getCurrentMainSubscribers(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Переданы невалидные значения")

            result = await self.bd.query(
                "SELECT `chat_id` FROM `user_main_subsribe` WHERE `user_id` = " + str(
                    userID))

            if result is None:
                raise Exception(
                    "Не найдены обязательные текущие подписки " + str(userID))

            items = []

            # Перебираем нужные ресурсы для подписки
            for row in result:
                item = {
                    "chatID": row["chat_id"]
                }

                items.append(item)

            return items
        except Exception as err:
            print(traceback.print_exc())

            return None

        # Получение ИД телеграмма по ИД в системе

    async def getUser_id(self, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if userID is None:
                raise Exception("Переданы невалидные значения")

            result = await self.bd.query(
                "SELECT `user_id` FROM `users` WHERE `id` = " + str(userID))

            if result is None or len(result) != 1:
                raise Exception("Не найден пользователь " + str(userID))

            return int(result[0]["user_id"])
        except Exception as err:
            print(traceback.print_exc())

            return None

    # Получить ID юзера по UUID
    async def getUserIDByUUID(self, uuid=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if uuid is None:
                raise Exception("Переданы невалидные значения")

            result = await self.bd.queryPrepare(
                "SELECT `id`,`is_blocked` FROM `users` WHERE `uuid` = %s", [
                    uuid
                ])
            if result is None or len(result) != 1:
                raise Exception("Не найден пользователь " + str(uuid))

            if result[0]["is_blocked"] == 1:
                raise Exception(f"Пользователь заблокирован {str(uuid)}")
            return int(result[0]["id"])
        except Exception as err:
            return None

    # Получить ID юзера по ИД телеграмма
    async def getUserID(self, user_id=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if user_id is None:
                raise Exception("Переданы невалидные значения")

            result = await self.bd.query(
                "SELECT `id`,`is_blocked`  FROM `users` WHERE `user_id` = \"" + str(
                    user_id) + "\"")

            if result is None or len(result) != 1:
                raise Exception("Не найден пользователь " + str(user_id))

            if result[0]["is_blocked"] == 1:
                raise Exception(f"Пользователь заблокирован {str(user_id)}")

            return int(result[0]["id"])
        except Exception as err:
            return None

        # Получить ID юзера по Username телеграмма

    async def getUserIDByUsername(self, username=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if username is None:
                raise Exception("Переданы невалидные значения")

            result = await self.bd.queryPrepare(
                "SELECT `id` FROM `users` WHERE `username` = %s", [username])

            if result is None or len(result) != 1:
                raise Exception("Не найден пользоватеь " + str(username))

            return int(result[0]["id"])
        except Exception as err:
            print(traceback.print_exc())

            return None

        # Получить Username

    async def getUsername(self, user_id=None, userID=None):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            if user_id is None and userID is None:
                raise Exception("Переданы невалидные значения")

            if userID is None:
                userID = await self.getUserID(user_id=user_id)

                if userID is None:
                    raise Exception(
                        "Не удалось получить userID по user_id " + str(user_id))

            result = await self.bd.queryPrepare(
                "SELECT `username` FROM `users` WHERE `id` = %s", [userID])

            if result is None or len(result) != 1:
                raise Exception("Не найден пользователь " + str(userID))

            return str(result[0]["username"])
        except Exception as err:
            print(traceback.print_exc())

            return None

    '''АДМИНСКАЯ ЧАСТЬ'''

    # Проверка админ юзер или нет
    async def isAdmin(self, user_id=None):
        try:
            if user_id is None:
                raise Exception("Параметры невалидные")

            admins = ["1105392939", "241316555", "68685841", "443770521", "738492312"]

            for admin in admins:
                if str(user_id) == admin:
                    return True

            return False
        except Exception as err:
            print(str(err))

            traceback.print_exc()

            return False

    def __del__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()
