#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с БД

"""
import logging
import traceback
import asyncmy
from asyncmy.cursors import DictCursor

from configs import Configs
from asyncmy import connect


class BD:
    configs = Configs()
    settings = None
    #connect = None
    logger = logging.getLogger(__name__)
    def __init__(self):
        try:
            self.settings = self.configs.readConfig("bd.json")

            if self.settings is None:
                raise Exception("Не удалось прочитать настройки базы")

            # print("настройки базы: " + str(self.settings))
        except Exception as err:
            traceback.print_exc()

    # Получение настроек БД
    def getSettings(self):
        try:
            return self.settings
        except Exception as err:
            traceback.print_exc()

    # Выполнение запроса
    async def query(self, query=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            result = []

            try:
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query)
                    result = await cursor.fetchall()
                    conn.close()
            except Exception as e:
                try:
                    conn.close()
                except Exception as e:
                    pass
                conn = None
                # await self.openConnect()
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query)
                    result = await cursor.fetchall()
                    cursor.close()
                conn.close()
            return result
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение запроса обновления
    async def queryUpdate(self, query=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            try:
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)

                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query)
                try:
                    conn.close()
                except Exception as e:
                    pass
            except Exception as e:
                try:
                    conn.close()
                except Exception as e:
                    pass
                conn = None
                # await self.openConnect()
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query)
                conn.close()
            return True
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение подготовленного запроса
    async def queryPrepare(self, query=None, values=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            if values is None:
                raise Exception("Не переданы значения")

            result = []

            try:
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query, values)
                    result = await cursor.fetchall()
                    cursor.close()
                try:
                    conn.close()
                except Exception as e:
                    pass
            except Exception as e:
                print("queryPrepare -Запрос не выполнен")
                try:
                    conn.close()
                except Exception as e:
                    pass

                conn = None
                # await self.openConnect()
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query, values)
                    result = await cursor.fetchall()
                    cursor.close()
                conn.close()

            return result
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение подготовленного запроса без возвращения результата
    async def queryPrepareUpdate(self, query=None, values=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            if values is None:
                raise Exception("Не переданы значения")

            try:
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query, values)
                try:
                    conn.close()
                except Exception as e:
                    pass
            except Exception as e:
                try:
                    conn.close()
                except Exception as e:
                    pass
                conn = None
                # await self.openConnect()
                conn = await connect(
                    user=self.settings['login'],
                    password=self.settings['password'],
                    host=self.settings['host'],
                    port=self.settings['port'],
                    database=self.settings['database'],
                    autocommit=True)
                async with conn.cursor(cursor=DictCursor) as cursor:
                    await cursor.execute(query, values)
                    cursor.close()
                conn.close()

            return True
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Открытие коннекта
    async def openConnect(self):
        try:
            # if conn is None:
            # conn = await connect(
            #     user=self.settings['login'],
            #     password=self.settings['password'],
            #     host=self.settings['host'],
            #     port=self.settings['port'],
            #     database=self.settings['database'],
            #     autocommit=True)
            #
            # return conn
            return True
        except Exception as err:
            print(str(traceback.format_exc()))
            self.logger.error(traceback.format_exc())
            return False

    # Получение открытого коннекта
    # def getConnection(self):
    #     try:
    #         return conn
    #     except Exception as err:
    #         print(str(traceback.format_exc()))
    #         self.logger.error(traceback.format_exc())
    #         return None

    # Закрытие коннекта
    def closeConnect(self):
        try:
            # if conn is None:
            #     return True
            #
            # conn.close()

            return True
        except Exception as err:
            return False

