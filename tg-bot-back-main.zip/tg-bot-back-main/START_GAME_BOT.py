#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Главный бот

"""
import asyncio
import logging
import time
import traceback
import subprocess
import argparse

import sentry_sdk
from aiogram import Bot, Dispatcher, types
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import *
from aiogram.utils.keyboard import InlineKeyboardBuilder

from bd import BD
from configs import Configs
from lang import Lang
from settings import Settings
from telegram import Telegram
from users import Users

logger = logging.getLogger(__name__)

# Read script args
parser = argparse.ArgumentParser()
parser.add_argument("--sentry-dsn", help="Sentry DSN address")
args = parser.parse_args()
sentry_sdk.init(
    dsn=args.sentry_dsn,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)
# Read config file
conf = Configs().readConfig("bot.json")
bt = Bot(token=conf["token_game"])
dp = Dispatcher(bot=bt, storage=MemoryStorage())
lang = Lang()
users = Users(lang)
settings = Settings()
tg = Telegram(bt)
router = Router()

dp.include_router(router=router)




''''# Отправка информации о игре в инлайн режиме
@router.inline_query()
async def sendGame ( inlineQuery: InlineQuery ) :
    try:
        print( "INLINE ANSWER\n\n" )

        gameAnswer = InlineQueryResultGame( id=str( uuid4() ), game_short_name=conf[ "game_name" ] )

        # Отправляем список игр
        await bt.answer_inline_query( inline_query_id=inlineQuery.id, results=[ gameAnswer ] )
    except Exception as err:
        print( str(traceback.format_exc()) )

# Отправка игры
@router.callback_query ( F.game_short_name == conf[ "game_name" ] )
async def endGame( callback: CallbackQuery ):
    try:
        print(str(callback))

        print( "Message ----\n" + str(callback.message) + "\n----\n" )

        # Отправляем данные игры
        await bt.answer_callback_query( callback_query_id=callback.id, url=conf[ "game_url" ] )
    except Exception as err:
        print( str(traceback.format_exc()) )
'''


@dp.message(F.text, Command("start"))  # для команд /start
async def command_start_handler(message: types.Message, state: FSMContext):
    try:
        menu = InlineKeyboardBuilder()

        botData = await bt.get_me()

        uuid = await users.getUUID(user_id=message.chat.id)

        if uuid is None:
            return

        # print( str(message.from_user) )

        isPremium = message.from_user.is_premium is True

        # Ставим индикатор премиума
        await users.setIsPremium(uuid=uuid, isPremium=isPremium)

        url = conf["game_url"] + "?id=" + uuid

        # print( url )

        gameBtn = InlineKeyboardButton(text="Run game",
                                       web_app=WebAppInfo(url=url))

        menu.add(gameBtn)

        await message.answer(text="Run game", reply_markup=menu.as_markup())
        # await bt.send_game( chat_id=message.chat.id, game_short_name="url_crypt_name",  )
    except Exception as err:
        print("Ошибка STAR-conn_handl_men: " + str(traceback.format_exc()))
        logger.error(traceback.format_exc())


@dp.message(F.text)
@dp.edited_message(F.text)  # для отредактированных сообщений
async def normalMessage(message: types.Message, state: FSMContext):
    try:
        if message.chat.type != "private":
            return

        print("отлов сообщений " + str(message))

        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        await message.delete()
    except Exception as e:
        print(traceback.format_exc())
        logger.error(traceback.format_exc())


async def runMainBot():
    try:
        print("Действия после запуска бота")
        commands = [
            types.BotCommand(command="/start", description="Start bot")
        ]

        await bt.set_my_commands(commands=commands)

        print("Запускаем главный бот -Start Game Bot")

        await dp.start_polling(bt)
    except Exception as err:
        print(str(err))
        logger.error(traceback.format_exc())

# запускаем главного бота
asyncio.run(runMainBot())
