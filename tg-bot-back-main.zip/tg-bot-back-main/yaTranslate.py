#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с API Яндекс переводчика

"""

import traceback
import requests
from configs import Configs


class yaTranslate:
    conf = Configs().readConfig("bot.json")["yandexTranslate"]
    rootURL = "https://translate.api.cloud.yandex.net/translate/v2/"

    confGPT = Configs().readConfig("bot.json")["yandexTranslateGPT"]
    rootGPTURL = "https://llm.api.cloud.yandex.net/foundationModels/v1/"

    def __init__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()

    # Перевод текста
    def translate(self, fromText=None, toLang=None, glossary=None):
        try:
            if fromText is None or toLang is None:
                raise Exception("Неверные входные параметры")

            data = {
                "sourceLanguageCode": "ru",
                "targetLanguageCode": toLang,
                "texts": [
                    fromText
                ],
                "format": "HTML"
            }

            if glossary is not None:
                glossaryPairs = []

                for glossaryItem in glossary:
                    glossaryPairs.append({
                        "sourceText": glossaryItem["from"],
                        "translatedText": glossaryItem["to"]
                    })

                # Добавляем глоссарий в запрос
                data["glossaryConfig"] = {
                    "glossaryData": {
                        "glossaryPairs": glossaryPairs
                    }
                }

            print("Шлём данные " + str(data))

            responce = self.doRequest(method="translate", data=data)

            print(responce.status_code)
            print(responce.json())

            respJSON = responce.json()

            if responce.status_code != 200:
                raise Exception("Код ответа не 200")

            if "translations" not in respJSON or "text" not in \
                    respJSON["translations"][0]:
                raise Exception("Нет текста в ответе")

            return respJSON["translations"][0]["text"]
        except Exception as err:
            traceback.print_exc()

            return False

    # Выполнение запроса
    def doRequest(self, method=None, data=None, headers=None):
        try:
            if method is None:
                raise Exception("Неверные входные параметры")

            headersSend = {
                "Authorization": "Api-Key " + self.conf["secret"]
            }

            if headers is not None:
                for key, value in headers:
                    headersSend[key] = value

            responce = requests.post(url=self.rootURL + method,
                                     headers=headersSend, json=data)

            return responce
        except Exception as err:
            traceback.print_exc()

            return None

    # Перевод текста с помощью GPT
    def translateGPT(self, fromText=None, toLang=None):
        try:
            if fromText is None or toLang is None:
                raise Exception("Неверные входные параметры")

            text = "Переведи html текст ниже на " + toLang + " язык, но переводи английский текст, сохрани форматирование, сохрани html тэги\n\n" + fromText

            data = {
                "modelUri": "gpt://" + self.confGPT[
                    "keyID"] + "/yandexgpt/latest",
                "messages": [
                    {
                        "role": "system",
                        "text": "Ты — переводчик и веб разработчик."
                    },
                    {
                        "role": "assistant",
                        "text": text
                    }
                ],
                "completionOptions": {
                    "temperature": 0.5
                }
            }

            print("Шлём данные " + str(data))

            response = self.doRequestGPT(method="completion", data=data)

            print(response.status_code)
            print(response.json())

            respJSON = response.json()

            if response.status_code != 200:
                raise Exception("Код ответа не 200")

            if "result" not in respJSON or "alternatives" not in respJSON[
                "result"] or "message" not in \
                    respJSON["result"]["alternatives"][0]:
                raise Exception("Нет текста в ответе")

            return respJSON["result"]["alternatives"][0]["message"]["text"]
        except Exception as err:
            traceback.print_exc()

            return False

    # Выполнение запроса к GPT
    def doRequestGPT(self, method=None, data=None, headers=None):
        try:
            if method is None:
                raise Exception("Неверные входные параметры")

            headersSend = {
                "Authorization": "Api-Key " + self.confGPT["secret"]
            }

            if headers is not None:
                for key, value in headers:
                    headersSend[key] = value

            responce = requests.post(url=self.rootGPTURL + method,
                                     headers=headersSend, json=data)

            return responce
        except Exception as err:
            traceback.print_exc()

            return None

    def __del__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()
