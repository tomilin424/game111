#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Бот для админки

"""
import argparse
import asyncio
import logging
import traceback

import sentry_sdk
from aiogram import Bot, Dispatcher, types
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import *
from aiogram.utils.keyboard import InlineKeyboardBuilder

from configs import Configs
from lang import Lang
from settings import Settings
from telegram import Telegram
from users import Users

# Read script args
parser = argparse.ArgumentParser()
parser.add_argument("--sentry-dsn", help="Sentry DSN address")
args = parser.parse_args()
sentry_sdk.init(
    dsn=args.sentry_dsn,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)

logger = logging.getLogger(__name__)

conf = Configs().readConfig("bot.json")
bt = Bot(token=conf["token_admin"])
dp = Dispatcher(bot=bt, storage=MemoryStorage())
lang = Lang()
users = Users(lang)
settings = Settings()
tg = Telegram(bt)
router = Router()

dp.include_router(router=router)


# Вывод количество юзеров
@router.callback_query(F.data == "usersCount")
async def usersCount(callback: CallbackQuery):
    try:
        if callback.message.chat.type != "private":
            return

        isAdmin = await users.isAdmin(user_id=callback.message.chat.id)

        if isAdmin is not True:
            await tg.sendMessage(message=callback.message, text="Прав нет")

            return

        count = await users.getAllUsersCount()

        await tg.sendMessage(message=callback.message,
                             text="Пользователей - <b>" + str(count) + "</b>")

        # выводим приветственное сообщение
        await buildHello(message=callback.message)

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        print(str(traceback.format_exc()))
        logger.error(traceback.format_exc())


# Построение меню, но не вывод, а возвращение
def buildPinMenu(message=None, as_markup=True, markup_menu=None):
    try:
        if message is None:
            raise Exception("Не переданы валидные параметры")

        # меню
        if markup_menu is None:
            markup_menu = InlineKeyboardBuilder()

        btn = InlineKeyboardButton(
            text="Юзеров в боте", callback_data="usersCount")

        markup_menu.row(btn)

        return markup_menu.as_markup() if as_markup is True else markup_menu
    except Exception as err:
        print("Ошибка STAR-buiStaMen: " + traceback.format_exc())
        logger.error("Ошибка STAR-buiStaMen: " + traceback.format_exc())
        return None


# Построение приветственного сообщения
async def buildHello(message: Message = None):
    try:
        if message is None:
            raise Exception("Переданы невалидные параметры")

        text = "Выбирай нужное действие"

        menu = buildPinMenu(message=message)

        await tg.sendMessage(message=message, text=text, replyMarkup=menu)

        # Удаляем сообщение
        await message.delete()
    except Exception as err:
        print("Ошибка STAR-buiStaMen: " + str(traceback.format_exc()))
        logger.error("Ошибка STAR-buiStaMen: " + traceback.format_exc())


@dp.message(F.text, Command("start"))  # для команд /start
async def command_start_handler(message: types.Message, state: FSMContext):
    try:
        if message.chat.type != "private":
            return

        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        isAdmin = await users.isAdmin(user_id=message.chat.id)

        if isAdmin is not True:
            await tg.sendMessage(message=message, text="Прав нет")

            return

        # Выводим приветственное сообщение
        await buildHello(message=message)
    except Exception as err:
        traceback.print_exc()
        logger.error(traceback.format_exc())


@dp.message(F.text, Command("menu"))  # для команд /menu
async def command_menu_handler(message: types.Message, state: FSMContext):
    try:
        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        userData = await users.getUserData()

        await buildHello(userData=userData, message=message)
    except Exception as err:
        print("Ошибка STAR-conn_handl_men: " + str(traceback.format_exc()))
        logger.error("Ошибка STAR-conn_handl_men: " + str(traceback.format_exc()))


@dp.message(F.text)
@dp.edited_message(F.text)  # для отредактированных сообщений
async def normalMessage(message: types.Message, state: FSMContext):
    try:
        if message.chat.type != "private":
            return

        print("отлов сообщений " + str(message))

        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        # await message.delete()
    except Exception as e:
        print(traceback.format_exc())
        logger.error(traceback.format_exc())


async def runMainBot():
    try:
        commands = [
            types.BotCommand(command="/start", description="Start bot")
        ]

        await bt.set_my_commands(commands=commands)

        print("Запускаем Админского бота")
        await bt.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bt)
    except Exception as err:
        print(str(err))
        logger.error(traceback.format_exc())


# запускаем главного бота
asyncio.run(runMainBot())
