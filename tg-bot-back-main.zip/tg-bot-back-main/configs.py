#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с конфигами

"""

import os.path
import pathlib
import json
import traceback


class Configs:
    def readConfig(self, name=None):
        file = None

        try:
            if name is None:
                raise Exception("Не передано имя")

            if pathlib.Path("configs/" + name).is_file() is False:
                raise Exception("Файла нет")

            file = open("configs/" + name, 'r')
            data = json.loads(file.read())

            return data
        except Exception as err:
            traceback.print_exc()
            return None
        finally:
            if file is not None:
                file.close()
