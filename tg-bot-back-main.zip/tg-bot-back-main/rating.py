#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с рейтингом

"""

from bd import BD
import traceback


class Rating:
    bd = None

    def __init__(self, bd=None):
        try:
            if bd is None:
                self.bd = BD()
            else:
                self.bd = bd

        except Exception as err:
            traceback.print_exc()

    # Пересчёт рейтинга
    async def recalc(self):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")

            # Удаляем старые записи
            self.bd.queryUpdate("DELETE FROM `rating`")

            # Формируем таблицу рейтинга
            self.bd.queryUpdate(
                "INSERT INTO `rating` (`users_id`, `number`) SELECT `users_id`, ROW_NUMBER() OVER (ORDER BY intellect ASC) AS `number` FROM `game_users_data` ORDER BY `number` ASC")

            return True
        except Exception as err:
            traceback.print_exc()

            return False

    def __del__(self):
        try:
            # Если открыт создан экземпляр работы с базой
            if self.bd is not None:
                # Закрываем его
                self.bd.closeConnect()
        except Exception as err:
            traceback.print_exc()
