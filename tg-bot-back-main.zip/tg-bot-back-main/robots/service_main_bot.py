#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

ГЛАВНЫЙ сервисный бот

"""
import argparse
import asyncio
import base64
import datetime
import inspect
import json
import logging
import os
import re
import smtplib
import sys
import time
import traceback
import sentry_sdk

from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from aiogram.types import FSInputFile
from rating import Rating
from configs import Configs
from bd import BD
from users import Users
from lang import Lang
from yaTranslate import yaTranslate
from telegram import Telegram

from aiogram import Bot
from time import sleep

from py_w3c.validators.html.validator import HTMLValidator

currentdir = os.path.dirname(
    os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

# Read script args
parser = argparse.ArgumentParser()
# parser.add_argument("--sentry-dsn", help="Sentry DSN address")
# parser.add_argument("--translateAllFromRU", help="")
# args = parser.parse_args()
# if args.sentry_dsn is not None:
#     sentry_sdk.init(
#         dsn=args.sentry_dsn,
#         # Set traces_sample_rate to 1.0 to capture 100%
#         # of transactions for tracing.
#         traces_sample_rate=1.0,
#         # Set profiles_sample_rate to 1.0 to profile 100%
#         # of sampled transactions.
#         # We recommend adjusting this value in production.
#         profiles_sample_rate=1.0,
#     )

logger = logging.getLogger(__name__)

# Для работы с базой
bd = BD()
conf = Configs().readConfig("bot.json")
bt = Bot(token=conf["token"])
tg = Telegram(bt)

# аккаунт, с которого слать сообщения
botEmailAccount = {
    "host": "smtp.mail.ru",
    "port": 465,
    "login": "blacboy952@mail.ru",
    "password": "sp9GFmFUmQ0B155iifM3"
}
# аккаунты для рассылки сообщений в случае ошибки
errorsInfoAccrounts = [
    {
        "name": "Александр Васильевич",
        "login": "blacboy95@mail.ru",
    }
]

try:

    # элементы с ошибками
    '''
    {
      "target" : "цель ошибки",
      "error" : "описание ошибки"
    }
    '''
    errElems = []
    # данные выполняемой функции бота
    '''
      mode : "режим работы",
      text : "любой текст"
    '''
    botModeData = {
        "mode": "",
        "text": ""
    }

    # ПРОВЕРКА текста бота на валидность/ошибки
    '''
    [нужный язык | ru,en и т.д.] [режим проверки | tags (замкнутость тегов),]
    '''


    async def checkText(args):
        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")

        # нужный язык для проверки
        needLang = args[0]
        # режим проверки
        mode = args[1]

        botModeData["mode"] = "Проверка текста бота"
        botModeData["text"] = "Режим проверки текста: "

        if mode == "tags":
            botModeData["text"] += "замкнутость тегов"

        botModeData[
            "text"] += "<br/>Нужный язык: " + needLang + "<br/><br/><i>В описании ошибки надо искать слова \"Unclosed element\" и после них будет незакрытый элемент. Вот пример \"Unclosed element \\u201c<b>i</b>\\u201d.\", жирным выделил этот незакрытый элемент</i>"

        # выбираем строки таблицы
        rows = await bd.queryPrepare(
            "SELECT `id`, `text` FROM `text_lang_" + needLang + "`", [])

        # Если записей нет
        if len(rows) == 0:
            raise Exception(
                "Нет записей или отсутствует запрашиваемая таблица text_lang_" + needLang)

        # нормальное количество ошибок, так как текст не нормальная HTML страница
        normalErrCount = 2

        # перебираем строки
        for row in rows:
            try:
                # Если режим проверки замкнутости тегов
                if mode == "tags":
                    validator = HTMLValidator()
                    validator.validate_fragment(row["text"])

                    if len(validator.errors) > normalErrCount:
                        raise Exception(
                            "Ошибок (нормальное число ошибок " + str(
                                normalErrCount) + "): " + str(
                                len(validator.errors) - 2) + ".<br/>Ошибки: <br/>" + json.dumps(
                                validator.errors))
            except Exception as e:
                # Если это код ошибки
                if "HTTP Error " in str(e):
                    continue

                errElems.append({
                    "target": "ID: " + str(row["id"]),
                    "error": str(e)
                })


    # РАССЫЛКА СООБЩЕНИЙ УКАЗАННЫМ ЯЗЫКАМ
    '''
    0 - нужные языки в виде строки через запятую. ru,en,cn и т.д.
    1 - key нужного языкового текста из параметра 0. no_active_send_message_delete и т.д.
    2 - название картинки из папки images/send_messages. 0 если картинка не нужна
    3 - шаг паузы
    '''


    async def sendMessages(args):
        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")
        # нужные языки
        needLangs = str(args[0]).split(",")

        print("Нужные языки " + str(needLangs))

        lang = Lang()
        users = Users(bd=bd, lang=lang)

        # нужный ключ текста
        textKey = args[1]

        print("Нужный ключ текста " + str(textKey))

        # нужные текста
        needTexts = {}

        # перебираем языки для получения текста
        for needLang in needLangs:
            needText = await lang.getLangText(needLang, textKey)

            if needText is None:
                continue

            needTexts[needLang] = needText

        print("Нужные текста " + str(needTexts))

        img = str(args[2])

        if img == "0":
            img = None

        print("Картинка " + str(img))

        # выбираем пользователей с нужными языками
        rows = await bd.queryPrepare(
            "SELECT * FROM `users` WHERE   `langs_id` IN (SELECT `id` FROM `langs` WHERE `char` IN (\"" + "\",\"".join(
                needLangs) + "\"))", [])

        print(
            "SELECT * FROM `users` WHERE `langs_id` IN (SELECT `id` FROM `langs` WHERE `char` IN (\"" + "\",\"".join(
                needLangs) + "\"))")

        if len(rows) == 0:
            raise Exception("Пользователей нет с указанным языком")

        # шаг паузы
        step = int(args[3]) if 3 in args else 10000

        # Если записи есть
        if len(rows) > 0:
            # Перебираем юзеров
            for user in rows:
                langChar = (await lang.getLangs())[int(user["langs_id"])][
                    "char"]

                print("Юзер " + str(user["id"]) + " язык " + str(langChar))

                message = needTexts[langChar]
                try:
                    # добавляем запись на рассылку
                    await bd.queryPrepareUpdate(
                        "INSERT INTO `send_messages` (`user_id`, `chat_id`, `message`, `imgs`) VALUES(%s, %s, %s, %s)",
                        [user["id"], user["chat_id"], message,
                         "" if img is None else img])

                except Exception as e:
                    pass
        x = 0

        while x <= 2000:
            x += 1

            # выбираем сообщения на отправку
            rows = await bd.queryPrepare(
                "SELECT * FROM `send_messages` WHERE `is_send` = 0 ORDER BY `date_create` ASC LIMIT 100000",
                [])

            number = 0

            if len(rows) > 0:
                # asyncio.set_event_loop(asyncio.new_event_loop())

                # Перебираем сообщения на отправку
                for row in rows:
                    try:
                        print("Send user " + str(row["user_id"]))

                        number += 1

                        imgs = row["imgs"]

                        # Если нет картинок
                        if imgs == "":
                            # Отправляем сообщение
                            # asyncio.get_event_loop().run_until_complete(
                            #     tg.sendMessage(chatID=row["chat_id"],
                            #                    text=row["message"]))
                            await tg.sendMessage(chatID=row["chat_id"],
                                                text=row["message"])
                        else:
                            sendImg = FSInputFile(
                                "images/send_messages/" + imgs)

                            # Отправляем картинку с сообщением
                            await tg.sendPhoto(chatID=row["chat_id"],
                                             photo=sendImg,
                                             text=row["message"])

                        # обновляем статус обработки новой задачи
                        await bd.queryPrepareUpdate(
                            "UPDATE `send_messages` SET `is_send` = 1 WHERE `id` = %s",
                            [row["id"]])
                    except Exception as err:
                        traceback.print_exc()
                        logger.error(traceback.format_exc())

                        # обновляем статус обработки новой задачи
                        await bd.queryPrepareUpdate(
                            "UPDATE `send_messages` SET `is_send` = 1, `result_send` = %s WHERE `id` = %s",
                            ["Error send", row["id"]])

                    # пауза после отправки
                    sleep(0.03)

                    # Если кратный шаг
                    if number % step == 0:
                        # Делаем общую паузу
                        sleep(3.0)

                        # Сбрасываем номер
                        number = 0
            else:
                break


    # РАБОТА с оповещениями новых задач
    '''

    '''


    async def tasksNotification(args):
        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")

        # выбираем новые задачи
        rows = await bd.queryPrepare(
            "SELECT `id` FROM `tasks` WHERE `is_prepare_send` = 0", [])

        # нужный текст
        needText = args[0]

        print("Нужен текст " + str(needText))

        # шаг паузы
        step = int(args[1]) if 1 in args else 10000

        # Если записи есть
        if len(rows) > 0:
            lang = Lang(bd=bd)
            users = Users(bd=bd, lang=lang)

            # Перебираем задачи
            for row in rows:
                # данные задачи
                taskData = await users.getTask(taskID=row["id"])

                if taskData is None:
                    raise Exception("Не удалось найти задачу")

                # выбираем пользователей
                usersRow = await bd.queryPrepare(
                    "SELECT `id`, `chat_id` FROM `users`", [])

                print("Юзеров " + str(len(usersRow)))

                # перебираем юзеров
                for user in usersRow:
                    print("Юзер " + str(user["id"]) + " язык " + str(
                        await users.getLangChar(userID=user["id"])))

                    message = await lang.getLangText(
                        lang=await users.getLangChar(userID=user["id"]),
                        char=needText)

                    # добавляем запись на рассылку
                    await bd.queryPrepareUpdate(
                        "INSERT INTO `send_messages` (`user_id`, `chat_id`, `message`) VALUES(%s, %s, %s)",
                        [user["id"], user["chat_id"], message])

                # обновляем статус обработки новой задачи
                await bd.queryPrepareUpdate(
                    "UPDATE `tasks` SET `is_prepare_send` = 1 WHERE `id` = %s",
                    [row["id"]])

        x = 0

        while x <= 2000:
            x += 1

            # выбираем сообщения на отправку
            rows = await bd.queryPrepare(
                "SELECT * FROM `send_messages` WHERE `is_send` = 0 ORDER BY `date_create` ASC LIMIT 100000",
                [])

            number = 0

            if len(rows) > 0:
                asyncio.set_event_loop(asyncio.new_event_loop())

                # Перебираем сообщения на отправку
                for row in rows:
                    try:
                        print("Send user " + str(row["user_id"]))

                        number += 1

                        # Отправляем сообщение

                        await tg.sendMessage(chatID=row["chat_id"],
                                           text=row["message"])

                        # обновляем статус обработки новой задачи
                        await bd.queryPrepareUpdate(
                            "UPDATE `send_messages` SET `is_send` = 1 WHERE `id` = %s",
                            [row["id"]])
                    except Exception as err:
                        traceback.print_exc()
                        logger.error(traceback.format_exc())

                        # обновляем статус обработки новой задачи
                        await bd.queryPrepareUpdate(
                            "UPDATE `send_messages` SET `is_send` = 1, `result_send` = %s WHERE `id` = %s",
                            ["Error send", row["id"]])

                    # пауза после отправки
                    sleep(0.03)

                    # Если кратный шаг
                    if number % step == 0:
                        # Делаем общую паузу
                        sleep(3.0)

                        # Сбрасываем номер
                        number = 0
            else:
                break


    # ОТПРАВКА СТАТИСТИКИ СИСТЕМЫ
    '''

    '''


    async def sendStatistic(args):
        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")
        # ID юзеров для отправки сообщений в ТГ
        users = ["1105392939", "241316555"]
        # users = ["1105392939"]

        # выбираем статистику по пользователям
        rows = await bd.queryPrepare("SELECT "
                                     "(SELECT COUNT(*) FROM crypt.users) AS `all`, "
                                     "(SELECT COUNT(`id`) FROM crypt.users WHERE balance > 0) AS `balance_exist`",
                                     [])

        # Статистика по пользователям
        usersStats = {
            "all": int(rows[0]["all"]),
            "activated": 0,
            "no_activated": 0,
            "balance_exist": int(rows[0]["balance_exist"])
        }

        rows = await bd.queryPrepare("SELECT COUNT(`id`) as `count` "
                                     "FROM `users` AS `a` "
                                     "WHERE (SELECT COUNT(`id`) FROM `user_main_subsribe` as `b` WHERE `b`.`user_id` = `a`.`id`) = 2",
                                     [])

        usersStats["activated"] = int(rows[0]["count"])

        rows = await bd.queryPrepare("SELECT COUNT(`id`) as `count` "
                                     "FROM `users` AS `a` "
                                     "WHERE (SELECT COUNT(`id`) FROM `user_main_subsribe` as `b` WHERE `b`.`user_id` = `a`.`id`) <> 2",
                                     [])

        usersStats["no_activated"] = int(rows[0]["count"])

        # print( usersStats )

        usersStats["activated_percent"] = int(
            usersStats["activated"] / usersStats["all"] * 100)
        usersStats["no_activated_percent"] = 100 - usersStats[
            "activated_percent"]
        usersStats["balance_exist_percent"] = int(
            usersStats["balance_exist"] / usersStats["all"] * 100)

        # текст
        text = "Статистика <b>" + datetime.now().strftime('%d.%m.%Y') + (
                "</b>\n\n" +
                "👨‍🌾 Пользователи:\n\n" +
                "Всего - " + str(usersStats["all"]) + "\n" +
                "Активированных - " + str(
            usersStats["activated"]) + " (" + str(
            usersStats["activated_percent"]) + "%)\n" +
                "Неактивированных - " + str(
            usersStats["no_activated"]) + "(" + str(
            usersStats["no_activated_percent"]) + "%)\n" +
                "Баланс > 0 - " + str(
            usersStats["balance_exist"]) + "(" + str(
            usersStats["balance_exist_percent"]) + "%)\n")

        text += "\n🔠 Локализация:\n\n"

        lang = Lang()

        langs = await lang.getLangs()

        if langs is None:
            raise Exception("Не получены доступные языки системы")

        # статистика по языкам
        langsStats = {
            0: {
                "all": 0
            }
        }

        # выбираем статистику по языкам
        rows = await bd.queryPrepare(
            "SELECT COUNT( id ) AS `count`, `langs_id`  FROM `users` GROUP BY `langs_id`",
            [])

        for row in rows:
            langData = {
                "name": langs[int(row["langs_id"])]["name"],
                "flag": str(langs[int(row["langs_id"])]["flag"]),
                "count": int(row["count"])
            }

            # добавляем данные языка
            langsStats[int(row["langs_id"])] = langData

            langsStats[0]["all"] += langData["count"]

        allPercents = 0

        # print( langsStats )

        for langID in list(langsStats.keys()):
            if langID == 0:
                continue

            langStat = langsStats[langID]

            percent = int(round(langStat["count"] / langsStats[0]["all"] * 100))

            # Если последний элемент
            if langID == list(langsStats.keys())[-1]:
                # Пересчитываем количество процентов, чтобы было всё чётко
                percent = 100 - allPercents

            allPercents += percent

            text += langStat["flag"] + " " + langStat["name"] + " - " + str(
                langStat["count"]) + " (" + str(percent) + "%)\n"

        # РАСШИРЕННАЯ СТАТИСТИКА КЛЕЙМА ПО СТРАНАМ
        cleimText = ""
        langsStatsEx = {}

        # Перебираем языки
        for langID in list(langs.keys()):
            if langID == 0:
                continue

            # Статистика страны
            countryStat = {
                "cleimNow1": 0,  # клеймили один день
                "cleimNow2": 0,  # клеймили два дня подряд
                "cleimNow3": 0,  # клеймили три дня подряд и более
                "noCleimNow1": 0,  # не клеймят 1 день
                "noCleimNow2": 0,  # не клеймят 2 дня
                "noCleimNow3": 0,  # не клеймят 3 дня и более
                "cleim1": 0,  # клеймили хотя бы 1 раз
                "noCleim": 0,  # не клеймили ни разу
            }

            for number in range(0, 2):
                # клеймили N дней подряд
                row = await bd.queryPrepare(
                    "SELECT COUNT(*) AS `count` FROM (SELECT COUNT(*) as `count` FROM users_sum_wallet AS `a` WHERE a.user_id IN (SELECT id FROM users WHERE langs_id = %s) AND DATE(`date_create`) >= DATE_SUB(DATE(NOW()), INTERVAL %s DAY) GROUP BY `user_id`) AS `a`",
                    [
                        langID,
                        number
                    ])

                countryStat["cleimNow" + str(number + 1)] = int(row[0]["count"])

                # не клеймили N дней подряд
                row = await bd.queryPrepare(
                    "SELECT COUNT(*) AS `count` FROM `users` WHERE `langs_id` = %s AND `users`.`id` IN (SELECT `user_id` FROM `users_sum_wallet` WHERE DATE(`date_create`) >= DATE_SUB(DATE(NOW()), INTERVAL %s DAY))",
                    [
                        langID,
                        number
                    ])

                countryStat["noCleimNow1" + str(number + 1)] = int(
                    row[0]["count"])

            # клеймили хотя бы 1 раз
            row = await bd.queryPrepare(
                "SELECT COUNT(*) AS `count` FROM (SELECT COUNT(*) as `count` FROM users_sum_wallet AS `a` WHERE a.user_id IN (SELECT id FROM users WHERE langs_id = %s) GROUP BY `user_id`) AS `a`",
                [
                    langID
                ])

            countryStat["cleim1"] = int(row[0]["count"])

            # не клеймили ни разу
            row = await bd.queryPrepare(
                "SELECT COUNT(*) as `count` FROM users AS `a` WHERE `a`.`langs_id` = %s AND `a`.`id` NOT IN (SELECT `user_id` FROM users_sum_wallet);",
                [
                    langID
                ])

            countryStat["noCleim"] = int(row[0]["count"])

            # Добавляем статистику страны к имеющимся
            langsStatsEx[str(langID)] = countryStat

        cleimText += "💲 Расширенная статистика клейма по странам\n\n"

        # Перебираем языки в расширенной статистике
        for langID in list(langsStatsEx.keys()):
            countryStat = langsStatsEx[str(langID)]

            cleimText += langs[int(langID)]["flag"] + ":\n"

            for number in range(1, 3):
                cleimText += "Клеймили " + str(
                    number) + " дней подряд - " + str(
                    countryStat["cleimNow" + str(number)]) + "\n"

            for number in range(1, 3):
                cleimText += "Не клеймили " + str(
                    number) + " дней подряд - " + str(
                    countryStat["noCleimNow" + str(number)]) + "\n"

            cleimText += "Клеймили хотя бы 1 раз - " + str(
                countryStat["cleim1"]) + "\n"

            cleimText += "Не клеймили вообще - " + str(
                countryStat["noCleim"]) + "\n"

        # РАСШИРЕННАЯ СТАТИСТИКА ЗАДАЧ ПО СТРАНАМ
        tasksText = ""
        tasksStatsEx = {}

        # Перебираем языки
        for langID in list(langs.keys()):
            if langID == 0:
                continue

            # Статистика страны
            countryStat = {
                "do1": 0,  # выполнили 1 задание сегодня
                "do2": 0,  # выполнили 2 задания сегодня
                "do3": 0,  # выполнили 3 задания сегодня
                "do4": 0,  # выполнили 4 задания сегодня
                "do5": 0,  # выполнили 5 заданий сегодня
                "doNothing": 0  # ни одного задания
            }

            for count in range(1, 6):
                # выполнили >=N заданий сегодня
                row = await bd.queryPrepare(
                    "SELECT COUNT(`count`) AS `count` "
                    "FROM (SELECT COUNT(*) as `count` FROM user_end_tasks WHERE DATE(`date_create`) = DATE(NOW()) AND `user_id` IN (SELECT `id` FROM `users` WHERE `langs_id` = %s) GROUP BY `user_id`) AS `a` "
                    "WHERE `a`.`count` >= %s",
                    [
                        langID,
                        count
                    ])

                countryStat["do" + str(count)] = int(row[0]["count"])

            # не выполнили ни одного задания
            row = await bd.queryPrepare(
                "SELECT COUNT(*) AS `count` FROM `users` WHERE `langs_id` = %s AND `id` NOT IN (SELECT `user_id` FROM `user_end_tasks`)",
                [
                    langID
                ])

            countryStat["doNothing"] = int(row[0]["count"])

            # Добавляем статистику страны к имеющимся
            tasksStatsEx[str(langID)] = countryStat

        tasksText += "👨‍🌾 Расширенная статистика задач по странам\n\n"

        # Перебираем языки в расширенной статистике
        for langID in list(tasksStatsEx.keys()):
            countryStat = tasksStatsEx[str(langID)]

            tasksText += langs[int(langID)]["flag"] + ":\n"

            tasksText += "Выполнили >=1 задание - " + str(
                countryStat["do1"]) + "\n"
            tasksText += "Выполнили >=2 задания - " + str(
                countryStat["do2"]) + "\n"
            tasksText += "Выполнили >=3 задания - " + str(
                countryStat["do3"]) + "\n"
            tasksText += "Выполнили >=4 задания - " + str(
                countryStat["do4"]) + "\n"
            tasksText += "Выполнили >=5 заданий - " + str(
                countryStat["do5"]) + "\n"
            tasksText += "Не выполнили ни одного задания - " + str(
                countryStat["doNothing"]) + "\n"

        asyncio.set_event_loop(asyncio.new_event_loop())

        # Перебираем юзеров
        for user in users:
            try:
                # Отправляем сообщение

                await tg.sendMessage(chatID=user, text=text)

                await tg.sendMessage(chatID=user, text=cleimText)

                await tg.sendMessage(chatID=user, text=tasksText)
            except Exception as err:
                traceback.print_exc()
                logger.error(traceback.format_exc())

            sleep(3)


    # ПОДСЧЁТ ИГРОВОГО РЕЙТИНГА ЮЗЕРОВ
    '''

    '''


    async def calcRating(args):
        try:
            rating = Rating()

            if await rating.recalc() is not True:
                raise Exception("Не удалось пересчитать рейтинг")

            print("Рейтинг пересчитан")
        except Exception as err:
            traceback.print_exc()
            logger.error(traceback.format_exc())


    # ПЕРЕВОД ВСЕГО ТЕКСТА С РУССКОГО НА НУЖНЫЙ
    '''
    Аргументы : 
    0 - нужный язык в нескольких символах, типа ru, en. Используется в таблице lang_[нужный язык]
    1 - язык для перевода, типа cn, uz
    '''


    async def translateAllFromRU(args):
        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")
        try:
            # нужный язык
            lang2words = str(args[0]).lower()

            print("Нужен язык " + str(lang2words))

            langWordsTranslate = str(args[1])

            print("Язык для переводчика " + langWordsTranslate)

            langTable = "lang_" + lang2words

            print("Языковая таблица " + str(langTable))

            # Выбираем все русские записи
            rows = await bd.queryPrepare("SELECT * FROM `lang_ru`", [])

            print("Удаляем языковую таблицу")

            # Удаляем языковую таблицу
            await bd.queryUpdate("DROP TABLE IF EXISTS `" + langTable + "`")

            print("Создаём языковую таблицу")
            print("CREATE TABLE `" + langTable + "` LIKE `lang_ru`")

            # Создаём языковую таблицу - копия таблицы с русским языком
            await bd.queryUpdate(
                "CREATE TABLE `" + langTable + "` LIKE `lang_ru`")

            # Меняем комментарий
            await bd.queryUpdate(
                "ALTER TABLE `" + langTable + "` COMMENT = \"Языковая таблица - " + lang2words + " (создана скриптом)\"")

            # для работы с переводчиком яндекса
            translate = yaTranslate()

            # успешно переведено
            goodCount = 0

            # Перебираем языковые строки
            for row in rows:
                origignalText = row["text"]

                replaceKeys = {}
                replaceItems = []
                replaceNumber = 1

                items = re.findall(r'(::\w*::)', origignalText)

                # Если есть вставки
                if len(items) > 0:
                    for item in items:
                        if item in replaceKeys:
                            continue

                        replaceItems.append({
                            "number": replaceNumber,
                            "originalText": item,
                            "newText": "<div>" + str(replaceNumber) + "</div>"
                        })
                        replaceKeys[item] = None

                        replaceNumber += 1

                    # перебираем замены вставок
                    for replaceItem in replaceItems:
                        # заменяем вставку
                        origignalText = origignalText.replace(
                            replaceItem["originalText"], replaceItem["newText"])

                translateText = translate.translate(fromText=origignalText,
                                                    toLang=langWordsTranslate)

                if translateText is False:
                    raise Exception("Ошибка при переводе")

                # Если есть замены вставок
                if len(replaceItems) > 0:
                    for replaceItem in replaceItems:
                        # Если замены вставки нет в переведённом тексте
                        if translateText.find(replaceItem["newText"]) < 0:
                            raise Exception(
                                "Не найдена замена вставки " + replaceItem[
                                    "newText"] + " в переведённом тексте " + translateText)

                        # заменяем вставку обратно
                        translateText = translateText.replace(
                            replaceItem["newText"], replaceItem["originalText"])

                print("Переведённый текст:\n" + translateText)

                # Добавляем запись в базу
                await bd.queryPrepareUpdate(
                    "INSERT INTO `" + langTable + "` (`key`, `text`) VALUES ( %s, %s )",
                    [
                        row["key"],
                        translateText
                    ])

                goodCount += 1

                time.sleep(0.2)

            # Выбираем все записи нужного языка
            rowsNew = await bd.queryPrepare("SELECT * FROM `" + langTable + "`",
                                            [])

            if len(rowsNew) != len(rows):
                raise Exception("Количество строк не равны " + str(
                    len(rows)) + " != " + str(len(rowsNew)) + "\r\n")

            print("Всего для перевода " + str(
                len(rows)) + "\r\nУспешно переведено " + str(
                goodCount) + "\r\n")
        except Exception as err:
            traceback.print_exc()
            logger.error(traceback.format_exc())

            print(str(err))


    # ПЕРЕВОД ОДНОЙ ТЕКСТОВОЙ ЗАПИСИ С РУССКОГО НА ВСЕ ЯЗЫКИ
    '''
    Аргументы : 
    0 - key записи
    '''


    async def translateOneFromRU(args):
        try:
            if await bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            # нужная запись текста
            textKey = str(args[0]).lower()

            print("Нужна запись " + str(textKey))

            # Выбираем нужную запись
            targetText = await bd.queryPrepare(
                "SELECT * FROM `lang_ru` WHERE `key` = %s", [textKey])

            if len(targetText) != 1:
                raise Exception("Текстовая запись не найдена")

            targetText = targetText[0]["text"]

            print("Будем переводить текст:\r\n" + targetText)

            # данные сокращений языков (если сокращение не совпадает) для яндекса
            yaCountryCode = {
                "cn": "zh",
                "in": "hi",
                "ge": "ka",
                "kz": "kk",
                "br": "pt-BR",
                "kg": "ky",
                "jp": "ja",
                "tj": "tg"
            }

            langs = await Lang().getLangs()

            if langs is None:
                raise Exception("Нет языков")

            translate = yaTranslate()

            # Выбираем ищем ключ в языковой таблице
            rows = await bd.queryPrepare(
                "SELECT * FROM `lang_ru` WHERE `key` = %s",
                [textKey])

            if rows is None or len(rows) != 1:
                raise Exception("Нет текстовой записи")

            targetTextRow = rows[0]
            origignalText = targetTextRow["text"]

            # Перебираем язык
            for langID in langs:
                if langs[langID]["char"] == "ru":
                    continue

                langTable = "lang_" + langs[langID]["char"]

                # Выбираем ищем ключ в языковой таблице
                rows = await bd.queryPrepare(
                    "SELECT * FROM `" + langTable + "` WHERE `key` = %s",
                    [textKey])

                if rows is None:
                    raise Exception("Таблица нет или возникла ошибка")

                isAdd = False

                # Если записи нет
                if len(rows) != 1:
                    # Ставим индикатор добавления новой записи
                    isAdd = True

                replaceKeys = {}
                replaceItems = []
                replaceNumber = 1

                items = re.findall(r'(::\w*::)', origignalText)

                # Если есть вставки
                if len(items) > 0:
                    for item in items:
                        if item in replaceKeys:
                            continue

                        replaceItems.append({
                            "number": replaceNumber,
                            "originalText": item,
                            "newText": "<div>" + str(replaceNumber) + "</div>"
                        })
                        replaceKeys[item] = None

                        replaceNumber += 1

                    # перебираем замены вставок
                    for replaceItem in replaceItems:
                        # заменяем вставку
                        origignalText = origignalText.replace(
                            replaceItem["originalText"], replaceItem["newText"])

                langWordsTranslate = langs[langID]["char"]

                # Если есть особое буквенное обозначение у яндекса
                if langWordsTranslate in yaCountryCode:
                    langWordsTranslate = yaCountryCode[langWordsTranslate]

                translateText = translate.translate(fromText=origignalText,
                                                    toLang=langWordsTranslate)

                if translateText is False:
                    raise Exception("Ошибка при переводе")

                # Если есть замены вставок
                if len(replaceItems) > 0:
                    for replaceItem in replaceItems:
                        # Если замены вставки нет в переведённом тексте
                        if translateText.find(replaceItem["newText"]) < 0:
                            raise Exception(
                                "Не найдена замена вставки " + replaceItem[
                                    "newText"] + " в переведённом тексте " + translateText)

                        # заменяем вставку обратно
                        translateText = translateText.replace(
                            replaceItem["newText"], replaceItem["originalText"])

                print("Переведённый текст:\n" + translateText)

                print("Добавляем" if isAdd is True else "Изменяем")

                # Если добавляем запись
                if isAdd is True:
                    # Добавляем запись в базу
                    await bd.queryPrepareUpdate(
                        "INSERT INTO `" + langTable + "` (`key`, `text`) VALUES ( %s, %s )",
                        [
                            textKey,
                            translateText
                        ])
                else:
                    # Меняем запись в базу
                    await bd.queryPrepareUpdate(
                        "UPDATE `" + langTable + "` SET `text` = %s, `date_change` = NOW() WHERE `key` = %s",
                        [
                            translateText,
                            textKey
                        ])

                # Выбираем ключ в языковой таблице
                rows = await bd.queryPrepare(
                    "SELECT * FROM `" + langTable + "` WHERE `key` =%s AND `text` = %s",
                    [
                        textKey,
                        translateText
                    ])

                if rows is None:
                    raise Exception("Ошибка при поиске переведённой записи")

                # Если записи нет
                if len(rows) != 1:
                    raise Exception("Не найдена переведённая запись")

                time.sleep(0.2)
        except Exception as err:
            traceback.print_exc()
            logger.error(traceback.format_exc())
            print(str(err))


    # ПЕРЕВОД ВСЕГО ТЕКСТА С РУССКОГО НА НУЖНЫЙ С ПОМОЩЬЮ GPT
    '''
    Аргументы : 
    0 - нужный язык в нескольких символах, типа ru, en. Используется в таблице lang_[нужный язык]
    1 - язык для перевода, типа "китайский", "узбекский". Используется в формировании запроса к GPT
    '''


    async def translateAllFromRUByGPT(args):
        try:
            if await bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            # нужный язык
            lang2words = str(args[0]).lower()

            print("Нужен язык - " + str(lang2words))

            # нужно писать полностью, типа - китайский
            langWordsTranslate = str(args[1]).lower()

            print("Язык для переводчика - " + langWordsTranslate)

            langTable = "lang_" + lang2words

            print("Языковая таблица " + str(langTable))

            # Выбираем все русские записи
            rows = await bd.queryPrepare("SELECT * FROM `lang_ru`", [])

            print("Удаляем языковую таблицу")

            # Удаляем языковую таблицу
            await bd.queryUpdate("DROP TABLE IF EXISTS `" + langTable + "`")

            print("Создаём языковую таблицу")
            print("CREATE TABLE `" + langTable + "` LIKE `lang_ru`")

            # Создаём языковую таблицу - копия таблицы с русским языком
            await bd.queryUpdate(
                "CREATE TABLE `" + langTable + "` LIKE `lang_ru`")

            # Меняем комментарий
            await bd.queryUpdate(
                "ALTER TABLE `" + langTable + "` COMMENT = \"Языковая таблица - " + lang2words + " (создана скриптом)\"")

            # для работы с переводчиком яндекса
            translate = yaTranslate()

            # успешно переведено
            goodCount = 0

            # Перебираем языковые строки
            for row in rows:
                translateText = translate.translateGPT(fromText=row["text"],
                                                       toLang=langWordsTranslate)

                if translateText is False:
                    raise Exception("Ошибка при переводе")

                print("Переведённый текст ---\n" + translateText + "\n---\n")

                # Добавляем запись в базу
                await bd.queryPrepareUpdate(
                    "INSERT INTO `" + langTable + "` (`key`, `text`) VALUES ( %s, %s )",
                    [
                        row["key"],
                        translateText
                    ])

                goodCount += 1

                time.sleep(3)

            print("Всего для перевода " + str(
                len(rows)) + "\r\nУспешно переведено " + str(
                goodCount) + "\r\n")
        except Exception as err:
            traceback.print_exc()
            logger.error(traceback.format_exc())


    # СОЗДАНИЕ ПАРТИЦИЙ
    '''

    0 - нужная дата в формате [год 2 цифры с нулём]-[месяц 2 цифры с 0]-[день 2 цифры с 0]-[год 4 цифры]. 24-07-16-2024
    '''


    async def createPartitions(args):
        try:
            if await bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")
            now = datetime.today()

            # текущая дата (для неё создаваться будут партиции)
            currDate = now.strftime('%y-%m-%d-%Y').split("-")

            # Если задана дата
            if len(args) > 0:
                currDate = str(args[0]).split("-")

                print("Задана дата " + args[0])

            # Формируем массив с текущей датой
            currDate = {
                "year": currDate[0],
                "fullYear": currDate[3],
                "month": currDate[1],
                "day": currDate[2]
            }
            # Формируем массив с датой следующего месяца
            nextDate = {
                "fullYear": currDate["fullYear"],
                "year": currDate["year"],
                "month": currDate["month"],
                "day": "01"
            }

            # Если текущий месяц 12
            if int(currDate["month"]) == 12:
                nextDate["fullYear"] = str(int(nextDate["fullYear"]) + 1)
                nextDate["year"] = nextDate["fullYear"][2:]
                nextDate["month"] = "01"
            else:
                nextDate["month"] = str(int(nextDate["month"]) + 1) if int(
                    nextDate["month"]) + 1 > 9 else "0" + str(
                    int(nextDate["month"]) + 1)

            # СОЗДАНИЕ ПАРТИЦИИ ДЕЙСТВИЙ
            print("\nПАРТИЦИЯ actions")

            tableName = "actions"
            partitionName = "actions_" + currDate["month"] + "_" + currDate[
                "year"]
            partitionExpression = "to_days( '" + nextDate["fullYear"] + "-" + \
                                  nextDate["month"] + "-" + nextDate[
                                      "day"] + "' )"

            print(tableName + "\n" + partitionName + "\n" + partitionExpression)

            rows = await bd.queryPrepare(
                "SELECT * FROM actions PARTITION (" + partitionName + ")", [])

            if rows is None:
                print(
                    "ALTER TABLE `" + tableName + "` ADD PARTITION ( PARTITION `" + partitionName + "` VALUES LESS THAN ( " + partitionExpression + " ) )")

                # Добавляем партицию
                await bd.queryPrepareUpdate(
                    "ALTER TABLE `" + tableName + "` ADD PARTITION ( PARTITION `" + partitionName + "` VALUES LESS THAN ( " + partitionExpression + " ) )",
                    [])

                rows = await bd.queryPrepare(
                    "SELECT * FROM actions PARTITION (" + partitionName + ")",
                    [])

                if rows is None:
                    raise Exception("Не удалось создать партицию")

                print("УСПЕШНО")
            else:
                print("партиция уже есть в базе")

            print("конец обработки партиции\n")
        except Exception as err:
            traceback.print_exc()


    workFuncs = {
        "checkText": {
            "func": checkText
        },
        "tasksNotif": {  # Оповещения о новых задачах в боте
            "func": tasksNotification
        },
        "sendStatistic": {  # Отправка статистики системы
            "func": sendStatistic
        },
        "calcRating": {  # Подсчёт игрового рейтинга юзеров
            "func": calcRating
        },
        "translateAllFromRU": {
            # Перевод всего текста с русского на нужный язык
            "func": translateAllFromRU
        },
        "translateAllFromRUByGPT": {
            # Перевод всего текста с русского на нужный язык с помощью GPT
            "func": translateAllFromRUByGPT
        },
        "translateOneFromRU": {
            "func": translateOneFromRU
            # Перевод одной записи с русского на все языки (добавляется или обновляется запись)
        },
        "sendMessages": {
            "func": sendMessages
            # Рассылка писем нужным языковым группам с указанным текстом по ключу
        },
        "createPartitions": {
            "func": createPartitions  # Создание партиций
        }
    }

    # РАССЫЛКА ПИСЕМ
    '''

    '''


    def sendMail(emails, elems):
        theme = "=?utf-8?B?" + base64.b64encode(
            str.encode("Ошибки при запуске сервисного бота Montinik")).decode(
            "utf-8") + "?="
        body = "<html><body>Режим бота: <b>" + str(
            botModeData["mode"]) + "</b><br/>" + str(
            botModeData["text"]) + "<br/><br/>Таблица ошибок:<br/>" \
                                   "<table border=\"2\" bordercolor=\"#000000\" cellspacing=\"0\" cellpadding=\"5\">" \
                                   "<tr><td><b>Элемент</b></td><td><b>Описание ошибки</b></td></tr>" \
 \
            # перебираем ошибочные элементы
        for elem in elems:
            # формируем строку элемента
            body += "<tr><td>" + str(elem["target"]) + "</td><td>" + str(
                elem["error"]) + "</td></tr>"

        body += "</table></body></html>"

        # элемент для работы с SMTP
        smtp = smtplib.SMTP_SSL(host=botEmailAccount["host"],
                                port=botEmailAccount["port"])
        # авторизуемся
        smtp.login(user=botEmailAccount["login"],
                   password=botEmailAccount["password"])
        smtp.set_debuglevel(False)

        # перебираем получателей
        for reciev in emails:
            msg = MIMEMultipart()
            msg["Subject"] = theme
            msg["From"] = "=?utf-8?B?" + base64.b64encode(
                str.encode("Сервисный бот Montinik")).decode(
                "utf-8") + "?=" " <" + botEmailAccount["login"] + ">"
            msg["To"] = "=?utf-8?B?" + base64.b64encode(
                str.encode(reciev["name"])).decode("utf-8") + "?=" + " <" + \
                        reciev["login"] + ">"

            msg.attach(MIMEText(_text=body, _subtype="html", _charset="utf-8"))

            # msg.add_header("")
            msg.add_header("Content-Transfer-Encoding", "base64")

            print("Шлём адресату " + str(msg["To"]) + " От " + str(msg["From"]))

            # отсылаем сообщение
            smtp.sendmail(from_addr=botEmailAccount["login"],
                          to_addrs=reciev["login"], msg=msg.as_string())


    # введённая команда
    command = sys.argv[1]

    if command not in workFuncs:
        raise Exception("Команда неизвестна")

    # аргументы в виде массива
    args = sys.argv[2:]

    # выполняем нужную функцию
    asyncio.run(workFuncs[command]["func"](args))

    print("Ошибочных элементов: " + str(len(errElems)) + "\n")
    print(json.dumps(errElems))

    # Если есть ошибочные элементы
    if len(errElems) > 0:
        # отсылаем сообщения
        sendMail(errorsInfoAccrounts, errElems)

    print(json.dumps(errElems))
except Exception as err:
    traceback.print_exc()
finally:
    try:
        bd.closeConnect()
    except Exception as e:
        print()
