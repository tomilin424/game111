import asyncio
from datetime import datetime

import paramiko
import pymysql
from aiogram.types import Message, User, Chat
from paramiko import RSAKey

from bd import BD
from lang import Lang
from robots.bd_local import BDLocal
from users import Users

ssh_passprase = ''
ssh_key_path = 'C:\\Users\\kuskov-aa\\musk'
private_key = RSAKey.from_private_key_file(ssh_key_path, password=ssh_passprase)
ssh_host = '135.181.225.28'
ssh_username = 'akuskov'
ssh_port = 22

sql_hostname = 'localhost'
sql_port = 3306
sql_username = 'game'
sql_password = 'DysNype24XYeyxJVFhY3Lqn9fmQtk4Md'
sql_main_database = 'crypt'


file = open("errors1.log", 'r')
lines = file.readlines()
filtered = [x for x in lines if 'Exception: Не удалось зарегистрировать юзера' in x ]
#username='anfisiaosa'
#text='/start 1703424242'
#language_code='ru'
#id=560266534
#from_user=User(id=560266534
bd = BDLocal()
lang = Lang(bd)
users = Users(lang, bd)
i=0
for item in filtered:
    i= i + 1
    try:
        try:
            name = item[item.index("username="):item.index("username=") + 20:1].split(
                ",")[0].split("'")[1]
        except:
            name = item[item.index("username="):item.index("username=")+20:1].split(",")[0].split('=')[1]

        try:
            text = item[item.index("/start "):item.index("/start")+20:1].split("'")[0]
        except:
            text = "/start"

        message = Message(
            message_id=1,
            date=datetime.now(),
            chat=Chat(id=item[item.index("=Chat(id="):item.index("=Chat(id=")+20:1].split("'")[0].split(",")[0].split("=")[2]
                      , type='private'),
            text=text,
            from_user=User(
                language_code=item[item.index("language_code="):item.index("language_code=")+23:1].split(",")[0].split("=")[1].split("'")[1],
                is_bot=False,
                id=item[item.index("User(id="):item.index("User(id=")+20:1].split(",")[0].split("=")[1],
                username=name,
                first_name=item[item.index("first_name="):item.index("first_name=")+20:1].split(",")[0].split("'")[1]
                ,is_premium="is_premium=True" in item
            )
        )
        asyncio.get_event_loop().run_until_complete(users.regUser(message, tg=None))
        print(name)
    except Exception as err:
        pass
# client = paramiko.SSHClient()
# client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
# client.connect(hostname=ssh_host, username=ssh_username, port=ssh_port, look_for_keys=False, allow_agent=False, pkey=private_key,
#                password=None, disabled_algorithms=dict(pubkeys=["ssh-rsa", "ssh-rsa"]))
# transport = client.get_transport()
# channel = transport.open_channel("direct-tcpip", ('127.0.0.1', sql_port), (sql_hostname, sql_port))
# c=pymysql.connect(database=sql_main_database, user=sql_username, password=sql_password, defer_connect=True)
# c.connect(channel)
#
# with c.cursor() as cursor:
#     cursor.execute('SELECT VERSION()')
#     print(cursor.fetchone())