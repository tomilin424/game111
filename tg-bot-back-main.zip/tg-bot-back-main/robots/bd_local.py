#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с БД

"""
import logging
import traceback
import paramiko
import pymysql
from paramiko import RSAKey
from pymysql.cursors import DictCursor

from configs import Configs


class BDLocal:
    configs = Configs()
    settings = None

    ssh_passprase = ''
    ssh_key_path = 'C:\\Users\\kuskov-aa\\musk'
    private_key = RSAKey.from_private_key_file(ssh_key_path,
                                               password=ssh_passprase)
    ssh_host = '135.181.225.28'
    ssh_username = 'akuskov'
    ssh_port = 22

    sql_hostname = 'localhost'
    sql_port = 3306
    sql_username = 'game'
    sql_password = 'DysNype24XYeyxJVFhY3Lqn9fmQtk4Md'
    sql_main_database = 'crypt'
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=ssh_host, username=ssh_username,
                   port=ssh_port, look_for_keys=False,
                   allow_agent=False, pkey=private_key,
                   password=None, disabled_algorithms=dict(
            pubkeys=["ssh-rsa", "ssh-rsa"]))
    transport = client.get_transport()
    channel = transport.open_channel("direct-tcpip",
                                     ('127.0.0.1', sql_port),
                                     (sql_hostname, sql_port))
    c = pymysql.connect(database=sql_main_database,
                        user=sql_username, password=sql_password,
                        defer_connect=True, autocommit=True)
    c.connect(channel)
    logger = logging.getLogger(__name__)
    def __init__(self):
        try:
            a=1
        except Exception as err:
            traceback.print_exc()

    # Получение настроек БД
    def getSettings(self):
        try:
            return self.settings
        except Exception as err:
            traceback.print_exc()

    # Выполнение запроса
    async def query(self, query=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            result = []

            try:

                with self.c.cursor(cursor=DictCursor) as cursor:
                    cursor.execute(query)
                    result = cursor.fetchall()
            except Exception as e:
               pass
            return result
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение запроса обновления
    async def queryUpdate(self, query=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            try:
                with self.c.cursor(cursor=DictCursor) as cursor:
                    cursor.execute(query)
                self.c.commit()
            except Exception as e:
                pass
            return True
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение подготовленного запроса
    async def queryPrepare(self, query=None, values=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            if values is None:
                raise Exception("Не переданы значения")

            result = []

            try:
                with self.c.cursor(cursor=DictCursor) as cursor:
                    cursor.execute(query, values)
                    result = cursor.fetchall()
                self.c.commit()
            except Exception as e:
                print("queryPrepare -Запрос не выполнен")
            return result
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Выполнение подготовленного запроса без возвращения результата
    async def queryPrepareUpdate(self, query=None, values=None):
        try:
            # if conn is None:
            #     raise Exception("Нужно выполнить коннект к базе")

            if query is None:
                raise Exception("Не передан запрос")

            if values is None:
                raise Exception("Не переданы значения")

            try:
                with self.c.cursor(cursor=DictCursor) as cursor:
                    cursor.execute(query, values)
                self.c.commit()
            except Exception as e:
                pass

            return True
        except Exception as err:
            traceback.print_exc()
            # self.logger.error(traceback.format_exc())
            return None

    # Открытие коннекта
    async def openConnect(self):
        try:
            # if conn is None:
            # conn = await connect(
            #     user=self.settings['login'],
            #     password=self.settings['password'],
            #     host=self.settings['host'],
            #     port=self.settings['port'],
            #     database=self.settings['database'],
            #     autocommit=True)
            #
            # return conn
            return True
        except Exception as err:
            print(str(traceback.format_exc()))
            self.logger.error(traceback.format_exc())
            return False

    # Получение открытого коннекта
    # def getConnection(self):
    #     try:
    #         return conn
    #     except Exception as err:
    #         print(str(traceback.format_exc()))
    #         self.logger.error(traceback.format_exc())
    #         return None

    # Закрытие коннекта
    def closeConnect(self):
        try:
            # if conn is None:
            #     return True
            #
            # conn.close()

            return True
        except Exception as err:
            return False

