#!/bin/bash

USER="root"
PASSWORD="Cfif@flvby"
OUTPUT="/opt/mysql_backups"

# Удаляем файлы, старше 30 дней
find $OUTPUT -type f -mtime +30 -delete

databases=`mysql -u $USER -p$PASSWORD -e "SHOW DATABASES;" | tr -d "| " | grep -v Database`

for db in $databases; do
    if [[ "$db" != "information_schema" ]] && [[ "$db" != "performance_schema" ]] && [[ "$db" != "sys" ]] && [[ "$db" != _* ]] ; then
        echo "Бэкап базы: $db"

        path=$OUTPUT/`date +%Y%m%d`.$db.sql

        # Бэкапим
        mysqldump -u $USER -p$PASSWORD --databases $db > $path

        # Сжимаем бэкап
        gzip $path

        # Удаляем несжатый файл бэкапа
        rm -rf $path
    fi
done