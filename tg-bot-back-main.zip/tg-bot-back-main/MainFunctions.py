#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс с общими функциями

"""
import random

import traceback


class MainFunctions:
    def __init__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()

    # Генерация цифро-буквенной последовательности
    def createKey(self, needLength=10):
        try:
            string = ""
            # алфавит доступных символов
            words = "^P)qE1QMDB?p6wA9Z@oeNi=ruF0(tyalskGd72R~!VjfYS4hgLTKUCz3ImW5O-x,H8nc.XbJ_v"

            # выполняем пока длина строки не будет равна нужной
            while len(string) != needLength:
                # наш новый символ
                word = words[random.randrange(start=0, stop=len(words))]

                # добавляем символ к строке
                string += word

            return string if len(string) == needLength else None
        except Exception as err:
            traceback.print_exc()

            return None

    # Парсинг URL строки
    def urlParse(self, url=None):
        try:
            data = {}

            arr = url.split("&")

            for item in arr:
                pair = item.split("=")

                data[pair[0]] = pair[1]

            return data
        except Exception as err:
            traceback.print_exc()

            return None

    def __del__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()
