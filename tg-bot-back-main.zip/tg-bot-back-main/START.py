#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Главный бот

"""
import argparse
import asyncio
import datetime
import logging
import traceback
import sentry_sdk
import validators

from bd import BD
from aiogram import Bot, Dispatcher, types
from aiogram import F, Router
from aiogram.enums.chat_member_status import ChatMemberStatus
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import *
from aiogram.utils.keyboard import InlineKeyboardBuilder
from requests.utils import quote

from configs import Configs
from lang import Lang
from settings import Settings
from telegram import Telegram
from users import Users

# Read script args
parser = argparse.ArgumentParser()
parser.add_argument("--sentry-dsn", help="Sentry DSN address")
args = parser.parse_args()
sentry_sdk.init(
    dsn=args.sentry_dsn,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)

logger = logging.getLogger(__name__)

conf = Configs().readConfig("bot.json")
bt = Bot(token=conf["token"])
dp = Dispatcher(bot=bt, storage=MemoryStorage())
bd = BD()
lang = Lang(bd)

settings = Settings()
tg = Telegram(bt)
router = Router()

dp.include_router(router=router)

users = Users(lang, bd)


# Одобрение платежей (звёзды)
@router.pre_checkout_query(lambda query: True)
async def pre_checkout_query(query: types.PreCheckoutQuery):
    try:
        # uuid заказа
        orderUUID = str(query.invoice_payload).split("|")[1]
        # Тип товара
        itemType = int(str(query.invoice_payload).split("|")[0])

        print("UUID заказа " + str(orderUUID))

        isOk = False

        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")

        # Если товар это покупка ракет
        if itemType == 1:
            # Ищем заказ
            result = await bd.queryPrepare(
                "SELECT `item_id`, `users_id`, `sum` "
                "FROM `game_rockets_orders` "
                "WHERE `uuid` = %s AND `is_pay` = 0",
                [orderUUID])

            if result is not None and len(result) == 1:
                userID = int(result[0]["users_id"])
                itemID = int(result[0]["item_id"])
                sum = float(result[0]["sum"])

                # Ищем данные купленного товара
                result = await bd.queryPrepare("SELECT `earn` "
                                               "FROM `game_shop_items` "
                                               "WHERE `id` = %s", [itemID])

                if result is not None and len(result) == 1:
                    addValue = int(result[0]["earn"])

                    # Добавляем ракеты юзеру
                    await bd.queryPrepareUpdate("UPDATE `users` "
                                                "SET `balance_rockets` = `balance_rockets` + " + str(
                        addValue) + " "
                                    "WHERE `id` = %s",
                                                [userID])

                    # Ставим статус оплаты заказа
                    await bd.queryPrepareUpdate(
                        "UPDATE `game_rockets_orders` SET `is_pay` = 1 "
                        "WHERE `uuid` = %s AND `is_pay` = 0", [orderUUID])

                    # Обновляем стату реф. ссылки, если она была
                    await bd.queryPrepareUpdate(
                        "UPDATE `users_ref_links` SET `stars` = `stars` + " + str(
                            sum) + " "
                                   "WHERE `id` IN ( SELECT `ref_link_id` FROM `referals` WHERE `referal_user_id` = %s )",
                        [userID])

                    # Обновляем данные реферала
                    await bd.queryPrepareUpdate(
                        "UPDATE `referals` SET `is_pay` = 1 WHERE `referal_user_id` = %s",
                        [userID])

                    isOk = True

        # Если товар это покупка ассистента
        if itemType == 2:
            # Ищем заказ
            result = await bd.queryPrepare(
                "SELECT `item_id`, `users_id`, `sum` "
                "FROM `game_assistents_orders` "
                "WHERE `uuid` = %s AND `is_pay` = 0",
                [orderUUID])

            if result is not None and len(result) == 1:
                userID = int(result[0]["users_id"])
                itemID = int(result[0]["item_id"])
                sum = float(result[0]["sum"])

                # Ищем данные купленного товара
                result = await bd.queryPrepare("SELECT `id` "
                                               "FROM `game_shop_assistents` "
                                               "WHERE `id` = %s", [itemID])

                if result is not None and len(result) == 1:
                    # Ставим индикатор покупки юзеру
                    await bd.queryPrepareUpdate("UPDATE `users` "
                                                "SET `is_by_assistent` = 1 "
                                                "WHERE `id` = %s",
                                                [userID])

                    # Ставим статус оплаты заказа
                    await bd.queryPrepareUpdate(
                        "UPDATE `game_assistents_orders` SET `is_pay` = 1 "
                        "WHERE `uuid` = %s AND `is_pay` = 0", [orderUUID])

                    # Обновляем стату реф. ссылки, если она была
                    await bd.queryPrepareUpdate(
                        "UPDATE `users_ref_links` SET `stars` = `stars` + " + str(
                            sum) + " "
                                   "WHERE `id` IN ( SELECT `ref_link_id` FROM `referals` WHERE `referal_user_id` = %s )",
                        [userID])

                    # Обновляем данные реферала
                    await bd.queryPrepareUpdate(
                        "UPDATE `referals` SET `is_pay` = 1 WHERE `referal_user_id` = %s",
                        [userID])

                    isOk = True

        # Если товар это донат для замены вопроса (звёзды)
        if itemType == 3:
            # Ищем заказ
            result = await bd.queryPrepare(
                "SELECT `quiz_id`, `users_id`, `sum` "
                "FROM `game_daily_quiz_donats` "
                "WHERE `uuid` = %s AND `is_pay` = 0",
                [orderUUID])

            if result is not None and len(result) == 1:
                userID = int(result[0]["users_id"])
                itemID = int(result[0]["quiz_id"])
                sum = float(result[0]["sum"])

                # Ищем данные купленного товара
                result = await bd.queryPrepare("SELECT `id` "
                                               "FROM `game_daily_quiz_users` "
                                               "WHERE `id` = %s", [itemID])

                if result is not None and len(result) == 1:
                    # Ставим статус оплаты заказа
                    await bd.queryPrepareUpdate(
                        "UPDATE `game_daily_quiz_donats` SET `is_pay` = 1, `date_change` = NOW() "
                        "WHERE `uuid` = %s AND `is_pay` = 0", [orderUUID])

                    # Обновляем стату реф. ссылки, если она была
                    await bd.queryPrepareUpdate(
                        "UPDATE `users_ref_links` SET `stars` = `stars` + " + str(
                            sum) + " "
                                   "WHERE `id` IN ( SELECT `ref_link_id` FROM `referals` WHERE `referal_user_id` = %s )",
                        [userID])

                    # Обновляем данные реферала
                    await bd.queryPrepareUpdate(
                        "UPDATE `referals` SET `is_pay` = 1 WHERE `referal_user_id` = %s",
                        [userID])

                    isOk = True

        await query.answer(ok=isOk)
    except Exception as err:
        print('pre_checkout_query:' + str(err))
        logger.error(traceback.format_exc())
        traceback.print_exc()
        await query.answer(ok=False)


# Клейм крипты
@router.callback_query(F.data == "pinMenu|cleim")
async def cleim(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception(f"Ошибка получения userID: {callback.from_user.id}")

        result = await users.claim(userID=userID)

        if result is None:
            raise Exception(f"Ошибка клейма крипты userId={userID}")

        menu = await buildPinMenu(callback.message, False)

        cleimSettings = await settings.getCleimSettings()

        if cleimSettings is None:
            raise Exception("Ошибка при получении настроек клейма")

        text = ""
        lang_char = await users.getLangChar(userID=userID)
        # Если успешно заклеймлено
        if result["status"] == "ok":
            textData = {
                'sum': "{:_}".format(result["addBalance"]).replace("_", " "),
                "currTokenName": (await settings.getCurrencySettings())[
                    "tokenName"],
                "newSum": result["addBalance"],
                "hour": result["interval"]
            }

            text = await lang.getLangText(
                lang_char,
                "cleim_success", textData)
        else:
            textData = {
                'hour': cleimSettings["interval"],
                "returnTime": datetime.timedelta(seconds=int(result["date"])),
            }

            sum = cleimSettings["sum"]

            textRefSum = ""

            for refNumber in sum:
                if str(refNumber) == "0":
                    continue

                refText = await lang.getLangText(
                    lang_char,
                    "cleim_ref")

                if int(refNumber) >= 10:
                    refText = await lang.getLangText(
                        lang_char,
                        "cleim_refs")

                if int(refNumber) >= 100:
                    refText += await lang.getLangText(
                        lang_char,
                        "cleim_and_more")

                textRefSum += "\n" + str(
                    refNumber) + " " + refText + ": " + "{:_}".format(
                    sum[refNumber]).replace("_", " ") + " " + \
                              (await settings.getCurrencySettings())["name"]

            textData["cleimRefSum"] = textRefSum

            text = await lang.getLangText(
                lang_char,
                "cleim_return", textData)

        img = FSInputFile("images/cleim/main.jpg")

        await tg.sendPhoto(message=callback.message, photo=img, text=text,
                           replyMarkup=menu.as_markup())

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'cleim': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Страница заданий
@router.callback_query(F.data == "pinMenu|tasks")
async def showTasks(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception(
                f"Ошибка получения userID [user] ={callback.from_user.id}")

        currSett = await settings.getCurrencySettings()

        textData = {
            "currTokenName": currSett["tokenName"]
        }
        lang_char = await users.getLangChar(userID=userID)
        text = await lang.getLangText(lang_char,
                                      "tasks_page",
                                      textData)

        menu = InlineKeyboardBuilder()

        tasks = await users.getTasks(userID=userID)

        if tasks is None:
            raise Exception("Ошибка при получении задач")

        for task in tasks:
            actionText = await lang.getLangText(
                lang_char,
                "tast_type_" + str(
                    task["type"]) + "_action")

            actionSmile = ""

            if task["type"] == 1:
                actionSmile = "💟"

                actionText += " " + task["data"]["name"] + " в ник"

            if task["type"] == 2 or task["type"] == 3:
                actionSmile = "🗒"

                chatData = await bt.get_chat(chat_id=task["data"]["chatID"])

                actionText += " " + str(chatData.title)

            if task["type"] == 4:
                actionText += " " + str(task["data"]["name"])

            if task["type"] == 5:
                actionText += " " + str(task["data"]["name"])

            btn = InlineKeyboardButton(text=actionSmile + " " + actionText,
                                       callback_data="taskDo|" + str(
                                           task["id"]))

            menu.row(btn)

        btn = InlineKeyboardButton(
            text="⬅️ " + await lang.getLangText(
                lang_char,
                "back"), callback_data="taskDo|0")

        menu.row(btn)

        img = FSInputFile("images/tasks/main.jpg")

        await tg.sendPhoto(message=callback.message, text=text, photo=img,
                           replyMarkup=menu.as_markup())

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showTasks': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Выбор задания
@router.callback_query(F.data.startswith("taskDo|"))
async def changeTask(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        taskID = int(callback.data.split("|")[-1])

        if taskID == 0:
            await buildHello(userData={
                "id": userID
            }, message=callback.message)

            return

        allTasks = await users.getTasks(userID=userID)

        taskData = None

        for task in allTasks:
            if taskID == task["id"]:
                taskData = task

                break
        lang_char = await users.getLangChar(userID)
        if taskData is None:
            await tg.sendNotification(queryID=callback["id"],
                                      text=await lang.getLangText(lang_char,
                                                                  "task_no_exist"))

            return

        text = ""
        currSett = await settings.getCurrencySettings()

        if taskData["type"] == 1:
            textData = {
                "name": taskData["data"]["name"],
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text += await lang.getLangText(lang_char,
                                           "task_1_page",
                                           textData)

        if taskData["type"] == 2 or taskData["type"] == 3:
            chatData = await bt.get_chat(chat_id=taskData["data"]["chatID"])

            textData = {
                "link": chatData.invite_link if "link" not in taskData[
                    "data"] or taskData["data"]["link"] is None else
                taskData["data"]["link"],
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text += await lang.getLangText(lang_char,
                                           "task_" + str(
                                               taskData["type"]) + "_page",
                                           textData)

        if taskData["type"] == 4:
            textData = {
                "link": taskData["data"]["link"],
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text += await lang.getLangText(lang_char,
                                           "task_4_page",
                                           textData)

        if taskData["type"] == 5:
            textData = {
                "link": taskData["data"]["link"],
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text += await lang.getLangText(lang_char,
                                           "task_5_page",
                                           textData)

        markup_menu = InlineKeyboardBuilder()

        btn = InlineKeyboardButton(
            text=await lang.getLangText(lang_char,
                                        "check"),
            callback_data="taskCheck|" + str(taskData["id"]))
        btn2 = InlineKeyboardButton(
            text="⬅️ " + await lang.getLangText(
                lang_char,
                "back"),
            callback_data="taskCheck|0")

        markup_menu.row(btn).row(btn2)

        await tg.sendMessage(message=callback.message, text=text,
                             replyMarkup=markup_menu.as_markup())

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'changeTask': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Проверка задания
@router.callback_query(F.data.startswith("taskCheck|"))
async def taskCheck(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        taskID = int(callback.data.split("|")[-1])

        # Если кнопка Назад
        if taskID == 0:
            await showTasks(callback=callback)

            return

        taskData = await users.getTask(taskID=taskID)

        if taskData is None:
            return

        # Если задача уже была выполнена или ошибка
        if await users.isEndTask(userID=userID, taskID=taskID) is True:
            return

        currSett = await settings.getCurrencySettings()
        lang_char = await users.getLangChar(userID=userID)
        # Если добавление в юзернэйм текста
        if taskData["type"] == 1:
            needName = taskData["data"]["name"]
            username = callback.message.chat.username

            if needName not in username:
                textData = {
                    "name": taskData["data"]["name"],
                    "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                    "currName": currSett["name"]
                }

                text = await lang.getLangText(
                    lang_char,
                    "task_bad_name", textData)

                await tg.sendNotification(queryID=callback.id, text=text,
                                          isALert=True)

                return
            try:
                if validators.url(username) or 'http:/' in username or '<script' in username:
                    username = quote(username, safe='')
            except Exception as err:
                pass
            addTaskData = {
                "username": username,
                "sum": taskData["sum"]
            }

            result = await users.addEndTask(userID=userID, taskID=taskID,
                                            data=addTaskData)

            if result is not True:
                textData = {
                    "name": taskData["data"]["name"],
                    "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                    "currName": currSett["name"]
                }

                text = await lang.getLangText(
                    lang_char,
                    "task_bad_name", textData)

                await tg.sendNotification(queryID=callback.id, text=text,
                                          isALert=True)

                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(
                lang_char,
                "task_success_name", textData)

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            await showTasks(callback=callback)

        # Если подписка на канал/группу
        if taskData["type"] == 2 or taskData["type"] == 3:
            needChatID = taskData["data"]["chatID"]
            status = await bt.get_chat_member(chat_id=needChatID,
                                              user_id=callback.from_user.id)
            chatData = await bt.get_chat(chat_id=needChatID)

            if status.status == ChatMemberStatus.LEFT or status.status == ChatMemberStatus.KICKED:
                textData = {
                    "link": chatData.invite_link if "link" not in taskData[
                        "data"] or taskData["data"]["link"] is None else
                    taskData["data"]["link"]
                }

                text = await lang.getLangText(
                    lang_char,
                    "tasks_bad_subscribe", textData)

                await tg.sendNotification(queryID=callback.id, text=text,
                                          isALert=True)

                return

            addTaskData = {
                "status": status.status,
                "sum": taskData["sum"]
            }

            result = await users.addEndTask(userID=userID, taskID=taskID,
                                            data=addTaskData)

            if result is not True:
                textData = {
                    "link": chatData.invite_link
                }

                text = await lang.getLangText(
                    lang_char,
                    "tasks_bad_subscribe", textData)

                await tg.sendNotification(queryID=callback.id, text=text,
                                          isALert=True)

                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(
                lang_char,
                "task_success_subscribe", textData)

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            await showTasks(callback=callback)

        # Если переход по ссылке
        if taskData["type"] == 4:
            username = callback.message.chat.username

            addTaskData = {
                "username": username,
                "sum": taskData["sum"]
            }

            result = await users.addEndTask(userID=userID, taskID=taskID,
                                            data=addTaskData)

            if result is not True:
                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(
                lang_char,
                "task_success_name", textData)

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            await showTasks(callback=callback)

        lang_char = await users.getLangChar(userID=userID)
        # Если ретвитт
        if taskData["type"] == 5:
            username = callback.message.chat.username

            addTaskData = {
                "username": username,
                "sum": taskData["sum"]
            }

            result = await users.addEndTask(userID=userID, taskID=taskID,
                                            data=addTaskData)

            if result is not True:
                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(
                lang_char,
                "task_success_name", textData)

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            await showTasks(callback=callback)

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'taskCheck': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Страница текущего языка
@router.callback_query(F.data == "pinMenu|lang")
async def showLang(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        # данные языка пользователя
        lang_id = await users.getLangID(userID=userID)
        langData = (await lang.getLangs())[lang_id]
        lang_char = await users.getLangChar(userID=userID)
        textData = {
            "currLang": langData["flag"] + " " + langData["name"]
        }

        text = await lang.getLangText(lang_char,
                                      "lang_page",
                                      textData)

        menu = InlineKeyboardBuilder()

        btn = InlineKeyboardButton(
            text="🔄 " + await lang.getLangText(
                lang_char,
                "change_lang"),
            callback_data="changeLang")

        menu.row(btn)

        await buildPinMenu(callback.message, as_markup=False, markup_menu=menu)

        img = FSInputFile("images/lang/main.jpg")

        await tg.sendPhoto(message=callback.message, text=text, photo=img,
                           replyMarkup=menu.as_markup())

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showLang': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Страница выбора языка
@router.callback_query(F.data == "changeLang")
async def showLangs(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        # Текущий ИД языка пользователя
        currUserLangID = await users.getLangID(userID=userID)
        # Все доступные языки
        allLangs = await lang.getLangs()

        menu = InlineKeyboardBuilder()

        btns = []
        number = 1

        for langID in allLangs:
            if str(currUserLangID) == str(langID) or allLangs[langID][
                "isActive"] is not True:
                continue

            btnText = allLangs[langID]["flag"] + " " + allLangs[langID]["name"]

            btn = InlineKeyboardButton(text=btnText,
                                       callback_data="changeLang|" + str(
                                           langID))

            btns.append(btn)

            if number % 2 == 0:
                menu.row(btns[0], btns[1])

                btns = []

            number += 1

        if len(btns) > 0:
            menu.row(btns[0])
        lang_char = await users.getLangChar(userID=userID)
        btn = InlineKeyboardButton(
            text="⬅️ " + await lang.getLangText(
                lang_char,
                "back"), callback_data="changeLang|0")

        menu.row(btn)

        text = await lang.getLangText(lang_char,
                                      "langs_page ")

        await tg.sendMessage(message=callback.message, text=text,
                             replyMarkup=menu.as_markup())

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showLangs': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Выбор языка
@router.callback_query(F.data.startswith("changeLang|"))
async def changeLang(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        newLangID = int(callback.data.split("|")[-1])

        # Если кнопка Назад
        if newLangID == 0:
            await showLang(callback=callback)

            return

        # индикатор того, что был выбран язык при старте
        isStart = True if callback.data.split("|")[-2] == "start" else False

        result = await users.changeLang(userID=userID, langID=newLangID)
        lang_char = await users.getLangChar(userID=userID)
        if result is True:
            text = await lang.getLangText(
                lang_char,
                "success_change_lang")

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            if isStart is False:
                await showLang(callback=callback)
            else:
                await buildHello({
                    "id": userID
                }, message=callback.message)
        else:
            text = await lang.getLangText(
                lang_char,
                "error_change_lang")

            await tg.sendNotification(queryID=callback.id, text=text,
                                      isALert=True)

            return

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'changeLangs': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Вывод баланса
@router.callback_query(F.data == "pinMenu|balance")
async def showBalance(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        balance = await users.getBalance(userID=userID)

        if balance is None:
            raise Exception(f"Ошибка получения баланса userid={userID}")

        referalsCount = await users.getReferralsStatistic(userID=userID)

        if referalsCount is None:
            raise Exception("Ошибка получения статистики по рефералам")

        menu = await buildPinMenu(callback.message)

        currSett = await  settings.getCurrencySettings()

        textData = {
            "balance": balance,
            "refAll": referalsCount["all"],
            "currTokenName": currSett["tokenName"]
        }
        lang_char = await users.getLangChar(userID=userID)
        text = await lang.getLangText(lang_char,
                                      "balance_page", textData)

        img = FSInputFile("images/balance/main.jpg")

        await tg.sendPhoto(message=callback.message, text=text, photo=img,
                           replyMarkup=menu)

        '''try :
            ga = GA()

            await ga.send( client_id=callback.message.from_user.id, events=[{
                "name" : "command",
                "params" : {
                    #"page_location" : "https://game.ton-musk.com",
                    #"page_title" : "ТГ бот",
                    "chat_id" : str( callback.message.chat.id ),
                    "session_id": callback.message.chat.id,
                    "message" : str( callback.message.text ),
                    "language" : callback.message.from_user.language_code,
                    "engagement_time_msec": "1"
                }
            }] )
        except Exception as er :
            print( str(traceback.format_exc()) )'''

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showBalance': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Вывод ссылки на игру
@router.callback_query(F.data == "pinMenu|play")
async def showPlay(callback: CallbackQuery):
    try:
        try:
            userID = await users.getUserID(user_id=callback.from_user.id)

            if userID is None:
                raise Exception("Ошибка получения userID")

            menu = await buildPinMenu(callback.message)

            await tg.sendMessage(message=callback.message,
                                 text="Текст с кнопкой",
                                 replyMarkup=menu)

            try:
                # Удаляем сообщение
                await callback.message.delete()
            except Exception as err:
                pass  # ignore this exception without logging
        except Exception as err:
            error = f"Ошибка в методе 'showRules': {str(traceback.format_exc())} "
            print(error)
            logger.error(error)
    except Exception as err:
        error = f"Ошибка в методе 'showPlay': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Вывод описания правил
@router.callback_query(F.data == "pinMenu|rules")
async def showRules(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        menu = await buildPinMenu(callback.message)
        lang_char = await users.getLangChar(userID=userID)
        text = await lang.getLangText(lang_char,
                                      "rules_description")

        img = FSInputFile("images/balance/main.jpg")

        await tg.sendPhoto(message=callback.message, text=text, photo=img,
                           replyMarkup=menu)

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showRules': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Вывод реф ссылки
@router.callback_query(F.data == "pinMenu|ref")
async def showRefLink(callback: CallbackQuery):
    try:
        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка получения userID")

        refLink = await users.getRefLink(userID=userID,
                                         botUsername=(
                                             await bt.get_me()).username)

        if refLink is None:
            raise Exception(f"Ошибка построения реф. ссылки {userID}")

        menu = await buildPinMenu(callback.message)

        currSett = await settings.getCurrencySettings()

        textData = {
            "refLink": refLink,
            "currName": currSett["name"],
            "currTokenName": currSett["tokenName"]
        }

        text = await lang.getLangText(await users.getLangChar(userID=userID),
                                      "ref_page",
                                      textData)

        img = FSInputFile("images/ref/main.jpg")

        await tg.sendPhoto(message=callback.message, text=text, photo=img,
                           replyMarkup=menu)

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'showRefLink': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Проверка подписан ли клиент на обязательные ресурсы
@router.callback_query(F.data == "start|check")
async def checkMainSubscribe(callback: CallbackQuery):
    try:
        needAllSubscribers = await  settings.getAllMainSubscribe()

        if needAllSubscribers is None:
            raise Exception("Ошибка при получении списка всех нужных подписок")

        userID = await users.getUserID(user_id=callback.from_user.id)

        if userID is None:
            raise Exception("Ошибка при получении ID юзера")

        isAllSubscribe = await users.isAllSubscribe(userID=userID,
                                                    allSubscribers=needAllSubscribers)

        # Если нет подписки на все ресурсы
        if isAllSubscribe is False:
            isAllSubscribe = True

            for needChatID in needAllSubscribers:
                status = await bt.get_chat_member(chat_id=needChatID,
                                                  user_id=callback.from_user.id)

                print("Статус по факту " + status.status)

                if status.status == ChatMemberStatus.LEFT or status.status == ChatMemberStatus.KICKED:
                    print("Нет в чате " + str(needChatID))

                    isAllSubscribe = False

                    break

            # Если нет подписки на все ресурсы
            if isAllSubscribe is False:
                await tg.sendNotification(queryID=callback.id,
                                          text="Необходимо подписаться на все ресурсы",
                                          isALert=True)

                return

        # Ставим подписку на все ресурсы
        await users.addMainSubscribers(userID=userID,
                                       subscribers=needAllSubscribers)

        # Активируем реферала (даём ему деньги и т.д. за привлечение пользователя) по ИД реферала, если он был разумеется
        # await users.activeReferal( referalID=userID, tg=tg )

        # Показываем приветствие
        await buildHello(userData={
            "id": userID
        }, message=callback.message)

        try:
            # Удаляем сообщение
            await callback.message.delete()
        except Exception as err:
            pass  # ignore this exception without logging
    except Exception as err:
        error = f"Ошибка в методе 'checkMainSubscribe': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# Построение меню, но не вывод, а возвращение
async def buildPinMenu(message=None, as_markup=True, markup_menu=None):
    try:
        if message is None:
            raise Exception("Не переданы валидные параметры")

        # меню
        if markup_menu is None:
            markup_menu = InlineKeyboardBuilder()

        lang_char = await users.getLangChar(user_id=message.chat.id)
        # await lang.getLangText(lang_char, "play")
        btn_play = InlineKeyboardButton(text="🚀 " + "Play",
                                        web_app=types.WebAppInfo(
                                            url='https://game.ton-musk.com/'))

        btn_ref = InlineKeyboardButton(
            text="🤝 " + await lang.getLangText(lang_char, "ref"),
            callback_data="pinMenu|ref")

        btn5_rules = InlineKeyboardButton(
            text="👨‍🌾 " + await lang.getLangText(lang_char
                                                 , "rules"),
            callback_data="pinMenu|rules")

        markup_menu.row(btn_play).row(btn_ref).row(btn5_rules)

        return markup_menu.as_markup() if as_markup is True else markup_menu
    except Exception as err:
        error = f"Ошибка в методе 'buildPinMenu' user={message.chat.id} : {str(traceback.format_exc())}"
        print(error)
        logger.error(error)

        return None


# Построение приветственного сообщения
async def buildHello(userData, message: Message = None):
    try:
        if message is None or "id" not in userData:
            raise Exception("Переданы невалидные параметры")

        # Индикатор того, что юзер подписан на все нужные источники
        isSubscribeAll = await users.isAllSubscribe(userID=userData["id"])

        markup_menu = InlineKeyboardBuilder()
        lang_char = await users.getLangChar(userID=userData["id"])
        # Если не на все источники подписка
        if isSubscribeAll is not True:
            currSett = await settings.getCurrencySettings()

            textData = {
                "currName": currSett["name"],
                "currTokenName": currSett["tokenName"]
            }

            text = await lang.getLangText(
                lang_char,
                "main", dataContent=textData)

            needChats = await  settings.getAllMainSubscribe()

            for chatID in needChats:
                print(chatID)

                chatData = await bt.get_chat(chat_id=int(chatID))

                print(chatData.type)

                btn = InlineKeyboardButton(
                    text=await lang.getLangText(
                        lang_char,
                        "join_to_channel" if chatData.type == "channel" else "subscribe_to_group"),
                    url=chatData.invite_link)

                markup_menu.row(btn)

            btn2 = InlineKeyboardButton(
                text="🔄 Проверить",
                callback_data="start|check")

            markup_menu.row(btn2)

            await tg.sendMessage(message=message, text=text,
                                 replyMarkup=markup_menu.as_markup())
        else:
            # refLink1 = await users.getRefLink(userID=userData["id"],
            #                                   botUsername=(
            #                                       await bt.get_me()).username)
            #
            # if refLink is None:
            #     raise Exception("Ошибка построения реф. ссылки")

            currSett = await settings.getCurrencySettings()

            textData = {
                "currName": currSett["name"]
            }

            text = await lang.getLangText(
                lang_char,
                "start", dataContent=textData)

            menu = await buildPinMenu(message=message)

            img = FSInputFile("images/main/main.jpg")

            await tg.sendPhoto(message=message, text=text, photo=img,
                               replyMarkup=menu)

        # Удаляем сообщение
        try:
            await message.delete()
        except Exception as err:
            pass
    except Exception as err:
        error = f"Ошибка в методе 'buildHello': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


@dp.message(F.text, Command("start"))  # для команд /start
async def command_start_handler(message: types.Message, state: FSMContext):
    try:
        if message.chat.type != "private":
            return

        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        result = await users.regUser(message, tg=tg)

        if result is None:
            raise Exception("Не удалось зарегистрировать юзера " + str(message))

        if "isNew" not in result or result["isNew"] is not True:
            # Выводим приветственное сообщение
            await buildHello(userData=result, message=message)
        else:
            # Все доступные языки
            allLangs = await lang.getLangs()

            menu = InlineKeyboardBuilder()

            btns = []
            number = 1

            for langID in allLangs:
                if allLangs[langID]["isActive"] is not True:
                    continue

                btnText = allLangs[langID]["flag"] + " " + allLangs[langID][
                    "name"]

                btn = InlineKeyboardButton(text=btnText,
                                           callback_data="changeLang|start|" + str(
                                               langID))

                btns.append(btn)

                if number % 2 == 0:
                    menu.row(btns[0], btns[1])

                    btns = []

                number += 1

            if len(btns) > 0:
                menu.row(btns[0])

            text = "Language"

            await tg.sendMessage(message=message, text=text,
                                 replyMarkup=menu.as_markup())

        '''try :
            ga = GA()

            await ga.send( client_id=message.from_user.id, events=[{
                "name" : "command",
                "params" : {
                    #"page_location" : "https://game.ton-musk.com",
                    #"page_title" : "ТГ бот",
                    "chat_id" : str( message.chat.id ),
                    "session_id": str( message.chat.id ),
                    "message" : str( message.text ),
                    "language" : message.from_user.language_code,
                    "engagement_time_msec": "1"
                }
            }] )
        except Exception as er :
            print( str(traceback.format_exc()) )'''
    except Exception as err:
        error = f"Ошибка в команде 'start': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


@dp.message(F.text, Command("menu"))  # для команд /menu
async def command_menu_handler(message: types.Message, state: FSMContext):
    try:
        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        userData = await users.getUserData()

        await buildHello(userData=userData, message=message)
    except Exception as err:
        error = f"Ошибка в команде 'menu': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


@dp.message(F.text)
@dp.edited_message(F.text)  # для отредактированных сообщений
async def normalMessage(message: types.Message, state: FSMContext):
    try:
        if message.chat.type != "private":
            return

        print("отлов сообщений " + str(message))

        # На всякий случай завершаем текущее состояние если оно было
        await state.clear()

        # await message.delete()
    except Exception as e:
        error = f"Ошибка в методе 'normalMessage': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


async def runMainBot():
    try:
        print("Действия после запуска бота")
        commands = [
            # types.BotCommand(command="/menu", description="Show menu bot"),
            types.BotCommand(command="/start", description="Start bot")
        ]

        await bt.set_my_commands(commands=commands)

        print("Запускаем главный бот - START")
        await bt.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bt)
    except Exception as err:
        error = f"Ошибка в методе 'runMainBot': {str(traceback.format_exc())} "
        print(error)
        logger.error(error)


# запускаем главного бота
asyncio.run(runMainBot())
