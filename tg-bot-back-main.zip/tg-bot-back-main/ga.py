#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с Гугл аналитикой

"""
import json
import traceback
import re
import uuid

import requests
from aiogram import Bot
from aiogram.types import *

from configs import Configs


class GA:
    urlRoot = "https://www.google-analytics.com/mp/collect"  # Для отладки https://www.google-analytics.com/debug/mp/collec
    conf = Configs().readConfig("bot.json")["ga"]

    def __init__(self):
        try:
            print()
        except Exception as err:
            traceback.print_exc()

    # Отправка события
    async def send(self, client_id=None, events=[]):
        try:
            if client_id is None or len(events) == 0:
                raise Exception("Невалидные параметры ga")

            url = self.urlRoot + "?measurement_id=" + self.conf[
                "measurementID"] + "&api_secret=" + self.conf["secretKey"]

            sendData = {
                "client_id": str("663231416.1721364310"),
                # мой client_id 663231416.1721364310
                "user_id": str(client_id),
                "events": events
            }

            headers = {'content-type': 'application/json'}

            print(url)
            print(str(sendData))
            response = requests.post(url, data=json.dumps(sendData),
                                     headers=headers)

            print(str(response.content))
            print(str(response.status_code))

            if response.status_code != 200:
                raise Exception("Код ответа не 200")

            print(str(response.json()))

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False
