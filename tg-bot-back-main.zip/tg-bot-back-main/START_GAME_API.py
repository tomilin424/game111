#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

API для игры

"""
import json
import argparse
import logging
import sentry_sdk
import validators
from requests.utils import quote
from aiogram import Bot
from aiogram.enums import ChatMemberStatus

from MainFunctions import MainFunctions
from configs import Configs
import traceback
from lang import Lang
from users import Users
from telegram import Telegram
from settings import Settings
from bd import BD

from quart import Quart, request

logger = logging.getLogger(__name__)

# Read script args
parser = argparse.ArgumentParser()
parser.add_argument("--listen-port", help="Listen port")
parser.add_argument("--sentry-dsn", help="Sentry DSN address")
args = parser.parse_args()

sentry_sdk.init(
    dsn=args.sentry_dsn,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)

conf = Configs().readConfig("bot.json")
bt = Bot(token=conf["token"])
bd = BD()
lang = Lang(bd)

settings = Settings()
tg = Telegram(bt)

app = Quart(__name__)
host = "127.0.0.1"
port = args.listen_port
isDebug = True

users = Users(lang, bd)

# Выполнение задания юзером
@app.route("/users/set_end_task", methods=["POST"])
async def usersSetEndTask():
    try:
        input = MainFunctions().urlParse(
            url=await request.get_data(as_text=True, parse_form_data=True))

        print("input " + str(input))

        uuid = input["id"]
        taskID = int(input["taskID"])

        if uuid is None or taskID is None:
            raise Exception("Невалидные параметры")

        # Данные задачи
        taskData = await users.getTask(taskID=taskID)

        if taskData is None:
            raise Exception(f"Задача не найдена {taskID}")

        currSett = await settings.getCurrencySettings()

        userID = await users.getUserIDByUUID(uuid=uuid)

        if userID is None:
            raise Exception("ID пользователя не найден")

        # Если задача уже была выполнена или ошибка
        if await users.isEndTask(userID=userID, taskID=taskID) is True:
            raise Exception("Task bad check is end")

        user_id = await users.getUser_id(userID=userID)

        if user_id is None:
            raise Exception("TG ID пользователя не найден")

        # asyncio.set_event_loop(asyncio.new_event_loop())

        # Если подписка на канал/группу
        if taskData["type"] == 2 or taskData["type"] == 3:
            needChatID = taskData["data"]["chatID"]
            status = await bt.get_chat_member(chat_id=needChatID,
                                              user_id=user_id)
            chatData = await bt.get_chat(chat_id=needChatID)

            print(str(status))

            if status.status == ChatMemberStatus.LEFT or status.status == ChatMemberStatus.KICKED:
                textData = {
                    "link": chatData.invite_link if "link" not in taskData[
                        "data"] or taskData["data"][
                                                        "link"] is None else
                    taskData["data"]["link"]
                }

                text = await lang.getLangText(await users.getLangChar(userID=userID),
                                        "tasks_bad_subscribe", textData)

                return ({
                    "status": "error",
                    "text": text
                })

            addTaskData = {
                "fromGame": True,
                "status": status.status,
                "sum": taskData["sum"]
            }

            result = await users.addEndTaskRockets(userID=userID, taskID=taskID,
                                             data=addTaskData)

            if result is not True:
                textData = {
                    "link": chatData.invite_link
                }

                text = await lang.getLangText(await users.getLangChar(userID=userID),
                                        "tasks_bad_subscribe", textData)

                return ({
                    "status": "error",
                    "text": text
                })

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(await users.getLangChar(userID=userID),
                                    "task_success_subscribe", textData)

            return ({
                "status": "ok",
                "text": text
            })

        # Если переход по ссылке
        if taskData["type"] == 4:
            username = await users.getUsername(userID=userID)

            if username is None:
                raise Exception("username не получен")

            try:
                if validators.url(username) or 'http:/' in username or '<script' in username:
                    username = quote(username, safe='')
            except Exception as err:
                pass

            addTaskData = {
                "fromGame": True,
                "username": username,
                "sum": taskData["sum"]
            }

            result = await users.addEndTaskRockets(userID=userID, taskID=taskID,
                                             data=addTaskData)

            if result is not True:
                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(await users.getLangChar(userID=userID),
                                    "task_success_name", textData)

            return ({
                "status": "ok",
                "text": text
            })

        # Если ретвитт
        if taskData["type"] == 5:
            username = await users.getUsername(userID=userID)

            if username is None:
                raise Exception("username не получен")

            try:
                if validators.url(username) or 'http:/' in username or '<script' in username:
                    username = quote(username, safe='')
            except Exception as err:
                pass

            addTaskData = {
                "fromGame": True,
                "username": username,
                "sum": taskData["sum"]
            }

            result = await users.addEndTaskRockets(userID=userID, taskID=taskID,
                                             data=addTaskData)

            if result is not True:
                return

            textData = {
                "sum": "{:_}".format(taskData["sum"]).replace("_", " "),
                "currName": currSett["name"]
            }

            text = await lang.getLangText(await users.getLangChar(userID=userID),
                                    "task_success_name", textData)

            return ({
                "status": "ok",
                "text": text
            })

        return ({
            "status": "ok"
        })
    except Exception as err:
        print(traceback.format_exc())
        logger.error(traceback.format_exc())

        return ({
            "status": "error",
            "text": str(err)
        })


# Получение userID по uuid
@app.route("/users/get_user_id_by_uuid", methods=["POST"])
async def getUserIDByUUID():
    try:
        input = MainFunctions().urlParse(
            url=await request.get_data(as_text=True, parse_form_data=True))

        print("input " + str(input))

        uuid = input["id"]

        if uuid is None:
            raise Exception("Невалидные параметры")

        userID = await users.getUserIDByUUID(uuid=uuid)

        if userID is None:
            raise Exception("ID пользователя не найден")

        return ({
            "status": "ok",
            "data": userID
        })
    except Exception as err:
        print(traceback.format_exc())
        logger.error(traceback.format_exc())

        return ({
            "status": "error",
            "text": str(err)
        })


# Оплата товаров магазина
@app.route("/crpt", methods=["POST"])
async def shopBy():
    try:
        print(await request.get_data(as_text=True, parse_form_data=True))

        input = json.loads(
            await request.get_data(as_text=True, parse_form_data=True))

        # print( "dd" + str( urlparse( await request.get_data( as_text=True, parse_form_data=True ) ) ) )
        print("input " + str(input))

        if "payload" not in input or "payload" not in input["payload"]:
            raise Exception("Error payload, bad order data")

        orderUUID = input["payload"]["payload"].split("|")[1]
        itemType = int(input["payload"]["payload"].split("|")[0])


        if await bd.openConnect() is False:
            raise Exception("Не удалось открыть коннект к БД")

        # Если товар это покупка ракет
        if itemType == 1:
            # Ищем заказ
            result = await bd.queryPrepare("SELECT `item_id`, `users_id` "
                                     "FROM `game_rockets_orders` "
                                     "WHERE `uuid` = %s AND `is_pay` = 0",
                                     [orderUUID])

            if result is not None and len(result) == 1:
                userID = int(result[0]["users_id"])
                itemID = int(result[0]["item_id"])

                # Ищем данные купленного товара
                result = await bd.queryPrepare("SELECT `earn` "
                                         "FROM `game_shop_items` "
                                         "WHERE `id` = %s", [itemID])

                if result is not None and len(result) == 1:
                    addValue = int(result[0]["earn"])

                    # Добавляем ракеты юзеру
                    await bd.queryPrepareUpdate("UPDATE `users` "
                                          "SET `balance_rockets` = `balance_rockets` + " + str(
                        addValue) + " "
                                    "WHERE `id` = %s",
                                          [userID])

                    # Ставим статус оплаты заказа
                    await  bd.queryPrepareUpdate(
                        "UPDATE `game_rockets_orders` SET `is_pay` = 1 "
                        "WHERE `uuid` = %s AND `is_pay` = 0", [orderUUID])

                    isOk = True

        # Если товар это покупка ассистента
        if itemType == 2:
            # Ищем заказ
            result = await bd.queryPrepare("SELECT `item_id`, `users_id` "
                                     "FROM `game_assistents_orders` "
                                     "WHERE `uuid` = %s AND `is_pay` = 0",
                                     [orderUUID])

            if result is not None and len(result) == 1:
                userID = int(result[0]["users_id"])
                itemID = int(result[0]["item_id"])

                # Ищем данные купленного товара
                result = await bd.queryPrepare("SELECT `id` "
                                         "FROM `game_shop_assistents` "
                                         "WHERE `id` = %s", [itemID])

                if result is not None and len(result) == 1:
                    # Ставим индикатор покупки юзеру
                    await bd.queryPrepareUpdate("UPDATE `users` "
                                          "SET `is_by_assistent` = 1 "
                                          "WHERE `id` = %s",
                                          [userID])

                    # Ставим статус оплаты заказа
                    await bd.queryPrepareUpdate(
                        "UPDATE `game_assistents_orders` SET `is_pay` = 1 "
                        "WHERE `uuid` = %s AND `is_pay` = 0", [orderUUID])

                    isOk = True

        return ({
            "status": "ok"
        })
    except Exception as err:
        print(traceback.format_exc())
        logger.error(traceback.format_exc())

        return ({
            "status": "error",
            "text": str(err)
        })
    finally:
        if bd is not None:
            bd.closeConnect()

# Запускаем АПИ
if __name__ == "__main__":
    app.run(host=host, port=port, debug=isDebug)
