#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с общими настройками системы

"""
import asyncio
import json

from bd import BD
import traceback


class Settings:
    settings = {}

    def __init__(self, bd=None):
        try:
            if bd is None:
                self.bd = BD()
            else:
                self.bd = bd

        except Exception as err:
            traceback.print_exc()
    # Получение списка всех обязательных подписок
    async  def getAllMainSubscribe(self):
        try:
            if(self.settings == {}):
                await self.loadInitData()
            return self.settings["mainSubscribe"]["items"]

        except Exception as err:
            traceback.print_exc()

            return None

    # Получение конфигор рефералов
    async def getReferalsSettings(self):
        try:
            if (self.settings == {}):
                await self.loadInitData()
            return self.settings["referals"]
        except Exception as err:
            traceback.print_exc()

            return None

    # Получение валюты
    async def getCurrencySettings(self):
        try:
            if (self.settings == {}):
                await self.loadInitData()
            return self.settings["currency"]
        except Exception as err:
            traceback.print_exc()

            return None

    # Получение данных для клейма
    async def getCleimSettings(self):
        try:
            if (self.settings == {}):
                await self.loadInitData()
            return self.settings["cleim"]
        except Exception as err:
            traceback.print_exc()

            return None

    # загрузка из базы стартовых данных
    async def loadInitData(self):
        try:
            await self.bd.openConnect()
            result = await self.bd.query("SELECT * FROM `settings`")

            if result is None:
                raise Exception("Не удалось получить данные настроек")

            for razdel in result:
                value = json.loads(razdel["data"])

                self.settings[razdel["name"]] = value

            return True
        except Exception as err:
            traceback.print_exc()

            return False

    # Получение всех настроек
    def getSettings(self):
        try:
            return self.settings
        except Exception as err:
            traceback.print_exc()

            return None

    def __del__(self):
        try:
            print()
            # Если открыт создан экземпляр работы с базой
            if self.bd is not None:
                # Закрываем его
                self.bd.closeConnect()
        except Exception as err:
            traceback.print_exc()
