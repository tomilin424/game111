#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с языком

"""
import asyncio

from asyncmy import connect

from bd import BD
import traceback


class Lang:
    bd = None
    base_settings = None
    settings = {
        "default": {
            "lang": 1
        },
        "langs": {}
    }
    langText_all = {}
    def __init__(self, bd=None):
        try:
            if bd is None:
                self.bd = BD()
            else:
                self.bd = bd

            asyncio.get_event_loop().run_until_complete(self.loadInitData())
            b = 1
        except Exception as err:
            traceback.print_exc()

    # загрузка из базы стартовых данных
    async def loadInitData(self):
        try:
            if await self.bd.openConnect() is False:
                raise Exception("Не удалось открыть коннект к БД")

            result = await self.bd.query(
                "SELECT `id`, `name`, `is_active`, `flag`, `char` FROM `langs` ORDER BY number ASC")

            if result is None:
                raise Exception("Не удалось получить данные языка")

            for row in result:
                langData = {
                    "id": int(row["id"]),
                    "name": str(row["name"]),
                    "flag": str(row["flag"]),
                    "char": str(row["char"]),
                    "isActive": True if int(row["is_active"]) == 1 else False
                }
                langText = await self.bd.query(
                    "SELECT `key`, `text` FROM `lang_" + row['char'].lower() + "`")
                self.langText_all[row['char'].lower()] = langText
                self.base_settings = langData
                # Добавляем язык к другим
                self.settings["langs"][langData["id"]] = langData

            return True
        except Exception as err:
            traceback.print_exc()

            return False

    # Получение текста нужного языка
    async def getLangText(self, lang="ru", char=None, dataContent=None):
        try:
            if self.base_settings is None:
                await self.loadInitData()

            if char is None:
                raise Exception("Не передан буквенный ID")

            try:
                result = next((x for x in self.langText_all[lang] if x['key'] == char))['text']
            except Exception as err:
                result = await self.bd.query(
                    "SELECT `text` FROM `lang_" + lang.lower() + "` WHERE `key` = \"" + char.lower() + "\"")

                if result is None:
                    raise Exception(f"Не удалось получить текст языка lang={lang}, char ={char}")

                result = result[0]["text"]

            # Если переданы данные для заполнения контента (вставок)
            if dataContent is not None:
                for key in dataContent:
                    # заменяем вставку
                        result = result.replace("::" + key + "::",
                                            str(dataContent[key]))

            result = result.replace("\r", chr(10)).replace("\n", chr(10))
            if result is None:
                raise Exception(f"Не удалось получить текст языка lang={lang}, char ={char}")
            return result
        except Exception as err:
            traceback.print_exc()

            return None

    # Получение языка по дефолту
    def getDefaultLang(self, isOnlyID=False):
        try:
            langData = self.settings["langs"][self.settings["default"]["lang"]]

            return langData["id"] if isOnlyID is True else langData
        except Exception as err:
            traceback.print_exc()

            return self.settings["default"]["lang"]

    # Получение списка всех языков
    async def getLangs(self):
        try:
            if self.base_settings is None:
                await self.loadInitData()

            return self.settings["langs"]
        except Exception as err:
            traceback.print_exc()

            return self.settings["default"]["lang"]

    def __del__(self):
        try:
            # Если открыт создан экземпляр работы с базой
            if self.bd is not None:
                # Закрываем его
                self.bd.closeConnect()
        except Exception as err:
            traceback.print_exc()
