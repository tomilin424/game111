#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Класс для работы с Телеграмом

"""

import traceback
import re

from aiogram import Bot
from aiogram.types import *


class Telegram:
    bot: Bot = None

    def __init__(self, bot):
        try:
            self.bot = bot
        except Exception as err:
            traceback.print_exc()

    # Отправка медиа
    async def sendMedia(self, message=None, chatID=None, media=None):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or media is None:
                raise Exception("Переданы невалидные параметры")

            result = await self.bot.send_media_group(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                media=media, disable_notification=True)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Редактирование клавиатуры сообщения
    async def editMessageReplay(self, message=None, chatID=None, messageID=None,
                                newReplay=None):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or messageID is None:
                raise Exception("Переданы невалидные параметры")

            await self.bot.edit_message_reply_markup(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                message_id=messageID,
                reply_markup=newReplay)

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Редактирование медиа
    async def editMessageMedia(self, message=None, chatID=None, messageID=None,
                               newMedia=None, parseMode="HTML",
                               replyMarkup=None):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or newMedia is None or messageID is None:
                raise Exception("Переданы невалидные параметры")

            await self.bot.edit_message_media(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                message_id=messageID,
                reply_markup=replyMarkup, media=newMedia)

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка картинки
    async def sendPhoto(self, message=None, chatID=None, text="", photoID=None,
                        photo=None, parseMode="HTML", replyMarkup=None,
                        isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or (
                    photoID is None and photo is None):
                raise Exception("Переданы невалидные параметры")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            result = await self.bot.send_photo(
                chat_id=chatID if chatID is not None else message.chat.id,
                caption=text if text != "" else None,
                photo=photoID if photoID is not None else photo,
                reply_markup=replyMarkup, parse_mode=parseMode,
                disable_notification=isDisableNotif)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка документа
    async def sendDocument(self, message=None, chatID=None, text="",
                           documentID=None, parseMode="HTML", replyMarkup=None,
                           isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or documentID is None:
                raise Exception("Переданы невалидные параметры")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            result = await self.bot.send_document(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                caption=text if text != "" else None, document=documentID,
                reply_markup=replyMarkup, parse_mode=parseMode,
                disable_notification=isDisableNotif)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка аудио
    async def sendAudio(self, message=None, chatID=None, text="", audioID=None,
                        parseMode="HTML",
                        replyMarkup=None, isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or audioID is None:
                raise Exception("Переданы невалидные параметры")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            result = await self.bot.send_audio(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                caption=text if text != "" else None, audio=audioID,
                reply_markup=replyMarkup, parse_mode=parseMode,
                disable_notification=isDisableNotif)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка видео
    async def sendVideo(self, message=None, chatID=None, text="", videoID=None,
                        parseMode="HTML",
                        replyMarkup=None,
                        isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or videoID is None:
                raise Exception("Переданы невалидные параметры")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            result = await self.bot.send_video(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                caption=text if text != "" else None, video=videoID,
                reply_markup=replyMarkup, parse_mode=parseMode,
                disable_notification=isDisableNotif)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка стикера
    async def sendSticker(self, message=None, chatID=None, stickerID=None,
                          replyMarkup=None, isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None or stickerID is None:
                raise Exception("Переданы невалидные параметры")

            result = await self.bot.send_sticker(
                chat_id=chatID if chatID is not None else message["chat"]["id"],
                sticker=stickerID, reply_markup=replyMarkup,
                disable_notification=isDisableNotif)

            return result
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Отправка сообщения
    async def sendMessage(self, message: Message = None, chatID=None, text="",
                          parseMode="HTML", replyMarkup=None,
                          disableWebPagePreview=None, isDisableNotif=True):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if message is None and chatID is None:
                raise Exception("Переданы невалидные параметры")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            result = await self.bot.send_message(
                chat_id=chatID if chatID is not None else message.chat.id,
                text=text, reply_markup=replyMarkup, parse_mode=parseMode,
                disable_web_page_preview=disableWebPagePreview,
                disable_notification=isDisableNotif)

            # print(str(result))

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Удаление сообщения
    async def deleteMessge(self, chatID=None, messageID=None):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if messageID is None and chatID is None:
                raise Exception("Переданы невалидные параметры")

            await self.bot.delete_message(chat_id=chatID, message_id=messageID)

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False

    # Ответ на сообщение
    async def answerMessage(self, message, text="", parseMode="HTML",
                            replyMarkup=None):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if parseMode == "MarkdownV2":
                text = re.sub(r"([_*\[\]()~`>#+\-=|{}.!])", r"\\\1", text)

            await message.answer(text=text, parse_mode=parseMode,
                                 reply_markup=replyMarkup,
                                 disable_notification=True)

            return True
        except Exception as err:
            print(traceback.format_exc())

            return False

    async def sendNotification(self, queryID=None, text=None, isALert=False):
        try:
            if self.bot is None:
                raise Exception("Бот не передан")

            if queryID is None and text is None:
                raise Exception("Переданы невалидные параметры")

            return await self.bot.answer_callback_query(
                callback_query_id=queryID, text=text, show_alert=isALert)
        except Exception as err:
            print(traceback.format_exc())

            return False
