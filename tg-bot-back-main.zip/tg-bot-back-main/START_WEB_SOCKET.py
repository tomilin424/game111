#!/usr/bin/python
# -*- coding: UTF-8 -*-

"""

Веб-сокет для игры

"""
import logging

import socketio
import uvicorn
from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

from configs import Configs
from lang import Lang
from users import Users
from settings import Settings

conf = Configs().readConfig("bot.json")

lang = Lang()
users = Users(lang)
settings = Settings()

server = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins='*')
socketApp = socketio.ASGIApp(server, static_files={
    '/': {'content_type': 'text/html', 'filename': 'start.html'}
})
fastApp = FastAPI()

fastApp.mount("/", socketApp)

logger = logging.getLogger('uvicorn.error')
logger.setLevel(logging.DEBUG)


@fastApp.get("/")
async def root():
    logger.debug('this is a debug message')

    return {"message": "Hello World"}


@server.event
def connect_error(message):
    print("The connection failed! ", message)


@server.event
def connect(sid, environ):
    print("\r\nconnect " + str(sid) + " | " + str(environ["QUERY_STRING"]))

    server.emit("OK")


@server.on("message")
def my_message(sid, data):
    print("\r\nmessage " + str(sid) + " | " + str(data))


@server.event
def disconnect(sid):
    print("\r\ndisconnect " + str(sid))


if __name__ == '__main__':
    fastApp = CORSMiddleware(app=fastApp,
                             allow_origins=["*"],
                             allow_credentials=True,
                             allow_methods=["*"],
                             allow_headers=["*"])

    uvicorn.run("START_WEB_SOCKET:fastApp", host="127.0.0.1", port=9486,
                lifespan="on", reload=False, log_level="debug", workers=2)
